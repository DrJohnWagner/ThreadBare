/* harness.c — timeout driver for sensor_log_ingest_pipeline (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <omp.h>

// Forward declarations (must match the real implementations).
void sensor_log_ingest_pipeline_serial(
    uint64_t seed0,
    uint32_t M,
    uint32_t R,
    uint32_t S,
    uint32_t T,
    uint32_t Q,
    uint64_t* out_checksum,
    uint64_t* out_totalRows,
    uint64_t* out_distinctSensorsPerFileSum);

void sensor_log_ingest_pipeline_omp(
    uint64_t seed0,
    uint32_t M,
    uint32_t R,
    uint32_t S,
    uint32_t T,
    uint32_t Q,
    uint64_t* out_checksum,
    uint64_t* out_totalRows,
    uint64_t* out_distinctSensorsPerFileSum);

static volatile sig_atomic_t g_timed_out = 0;

static void alarm_handler(int sig) {
    (void)sig;
    g_timed_out = 1;
}

static uint64_t splitmix64(uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

int main(int argc, char** argv) {
    uint64_t seed0 = 0x123456789abcdef0ULL;
    uint32_t M = 200;
    uint32_t R = 23000;
    uint32_t S = 64;
    uint32_t T = 86400;
    uint32_t Q = 256;
    unsigned timeout_sec = 2;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--seed") && i + 1 < argc) {
            seed0 = (uint64_t)strtoull(argv[++i], NULL, 0);
        } else if (!strcmp(argv[i], "--timeout") && i + 1 < argc) {
            timeout_sec = (unsigned)strtoul(argv[++i], NULL, 0);
        } else if (!strcmp(argv[i], "--n") && i + 1 < argc) {
            // Allow overriding M if desired; harness default uses largest spec size.
            M = (uint32_t)strtoul(argv[++i], NULL, 10);
        } else {
            fprintf(stderr, "usage: %s [--seed <u64>] [--timeout <sec>] [--n <M>]\n", argv[0]);
            return 2;
        }
    }

    // Touch PRNG path deterministically to avoid any compiler-driven dead-code.
    volatile uint64_t sink = 0;
    for (uint32_t f = 0; f < 3; f++) {
        sink ^= splitmix64(seed0 ^ (uint64_t)(f + 1));
    }
    (void)sink;

    // Run serial once (should return) to ensure harness env is sane.
    uint64_t cs = 0, tr = 0, ds = 0;
    sensor_log_ingest_pipeline_serial(seed0, M, R, S, T, Q, &cs, &tr, &ds);

    // Now run parallel under hard timeout.
    g_timed_out = 0;
    uint64_t cs2 = 0, tr2 = 0, ds2 = 0;

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = alarm_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGALRM, &sa, NULL);

    alarm(timeout_sec);

    // Call the parallel kernel; if it deadlocks, we should time out.
    sensor_log_ingest_pipeline_omp(seed0, M, R, S, T, Q, &cs2, &tr2, &ds2);

    // Cancel alarm if finished.
    alarm(0);

    int failures = g_timed_out ? 1 : 0;
    if (failures) {
        printf("[check] timeout reached (likely liveness failure)\n");
    } else {
        // Lightweight confirmation that outputs look plausible (not a full correctness check).
        if (tr2 == 0) {
            printf("[check] parallel returned but produced totalRows=0 (unexpected)\n");
            failures = 1;
        }
    }

    if (failures) {
        printf("[verdict] LIVE-01 exposed\n");
        return 1;
    }

    printf("[verdict] LIVE-01 not triggered\n");
    return 0;
}
