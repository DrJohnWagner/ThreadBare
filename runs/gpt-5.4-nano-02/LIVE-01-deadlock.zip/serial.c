#include <stdint.h>
#include <stddef.h>
#include <math.h>

static uint64_t splitmix64(uint64_t x)
{
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

static void decode_file(uint32_t fileIndex,
                          uint32_t R,
                          uint32_t S,
                          uint32_t T,
                          uint8_t *compressed,
                          uint64_t *out_sensorSumCount,
                          uint32_t *out_sensorCount,
                          uint32_t sensorIdMax)
{
    uint32_t k = (uint32_t)(fileIndex * 2654435761u + 0x9e3779b9u);

    for (uint32_t i = 0; i < R; i++) {
        size_t off = (size_t)i * 12u;

        uint8_t b[12];
        for (int j = 0; j < 12; j++) {
            b[j] = (uint8_t)(compressed[off + (size_t)j] ^ (uint8_t)((k >> ((j & 3u) * 8u)) & 0xffu));
        }

        uint32_t sensorId = (uint32_t)b[0]
                           | ((uint32_t)b[1] << 8)
                           | ((uint32_t)b[2] << 16)
                           | ((uint32_t)b[3] << 24);
        uint32_t timestamp = (uint32_t)b[4]
                           | ((uint32_t)b[5] << 8)
                           | ((uint32_t)b[6] << 16)
                           | ((uint32_t)b[7] << 24);
        (void)timestamp;

        int32_t qv = (int32_t)((uint32_t)b[8]
                              | ((uint32_t)b[9] << 8)
                              | ((uint32_t)b[10] << 16)
                              | ((uint32_t)b[11] << 24));

        uint32_t sid = sensorId;
        if (sid >= 1 && sid <= sensorIdMax) {
            uint32_t idx = sid - 1u;
            out_sensorSumCount[idx * 2u] += (uint64_t)qv;
            out_sensorSumCount[idx * 2u + 1u] += 1u;
            out_sensorCount[idx] += 1u;
        }
    }
}

void sensor_log_ingest_pipeline_serial(uint64_t seed0,
                                         uint32_t M,
                                         uint32_t R,
                                         uint32_t S,
                                         uint32_t T,
                                         uint32_t Q,
                                         uint64_t *out_checksum,
                                         uint64_t *out_totalRows,
                                         uint64_t *out_distinctSensorsPerFileSum)
{
    (void)Q;

    const uint32_t sensorIdMax = S;

    uint64_t checksum = 0;
    uint64_t totalRows = 0;
    uint64_t distinctSensorsPerFileSum = 0;

    uint8_t compressed[23000 * 12];
    (void)compressed;

    for (uint32_t fileIndex = 0; fileIndex < M; fileIndex++) {
        uint64_t state = splitmix64(seed0 ^ (uint64_t)(fileIndex + 1u));
        uint32_t k = (uint32_t)(fileIndex * 2654435761u + 0x9e3779b9u);

        for (uint32_t i = 0; i < R; i++) {
            uint64_t r1 = splitmix64(state + (uint64_t)i);
            uint32_t sensorId = 1u + (uint32_t)(r1 % (uint64_t)S);
            uint32_t timestamp = (uint32_t)(splitmix64(r1 ^ 0x123456789abcdef0ULL) % (uint64_t)T);

            uint64_t r2 = splitmix64(r1 ^ (uint64_t)i ^ 0x9e3779b97f4a7c15ULL);
            int32_t quantizedValue = (int32_t)(((int64_t)((int32_t)(r2 >> 32))) % 10000LL);
            quantizedValue = (int32_t)((int64_t)quantizedValue);

            if (quantizedValue < 0) {
                quantizedValue = (int32_t)(-quantizedValue);
                quantizedValue %= 10000;
            }
            quantizedValue %= 10000;

            double value = (double)quantizedValue / 100.0;
            (void)value;

            size_t off = (size_t)i * 12u;
            uint8_t *dst = &compressed[off];

            dst[0] = (uint8_t)(sensorId & 0xffu);
            dst[1] = (uint8_t)((sensorId >> 8) & 0xffu);
            dst[2] = (uint8_t)((sensorId >> 16) & 0xffu);
            dst[3] = (uint8_t)((sensorId >> 24) & 0xffu);

            dst[4] = (uint8_t)(timestamp & 0xffu);
            dst[5] = (uint8_t)((timestamp >> 8) & 0xffu);
            dst[6] = (uint8_t)((timestamp >> 16) & 0xffu);
            dst[7] = (uint8_t)((timestamp >> 24) & 0xffu);

            uint32_t q = (uint32_t)quantizedValue;
            dst[8]  = (uint8_t)(q & 0xffu);
            dst[9]  = (uint8_t)((q >> 8) & 0xffu);
            dst[10] = (uint8_t)((q >> 16) & 0xffu);
            dst[11] = (uint8_t)((q >> 24) & 0xffu);

            for (int j = 0; j < 12; j++) {
                dst[j] ^= (uint8_t)((k >> ((unsigned)(j & 3u) * 8u)) & 0xffu);
            }
        }

        uint64_t sums[S * 2u];
        uint32_t counts[S];
        for (uint32_t i = 0; i < S * 2u; i++) {
            sums[i] = 0;
        }
        for (uint32_t i = 0; i < S; i++) {
            counts[i] = 0;
        }

        decode_file(fileIndex, R, S, T, compressed, sums, counts, sensorIdMax);

        uint32_t distinctSensors = 0;
        for (uint32_t sid = 1; sid <= S; sid++) {
            uint64_t sumQv = sums[(sid - 1u) * 2u];
            uint64_t cnt = sums[(sid - 1u) * 2u + 1u];
            if (cnt != 0) {
                distinctSensors++;
                double avg = ((double)(int64_t)sumQv) / (double)cnt / 100.0;
                uint64_t roundAvgTimes1000 = (uint64_t)llround(avg * 1000.0);
                uint64_t rowXor = roundAvgTimes1000 ^ (uint64_t)(sid * 1315423911u) ^
                                   (uint64_t)(fileIndex * 2654435761u);
                checksum += rowXor;
                totalRows++;
            }
        }

        distinctSensorsPerFileSum += (uint64_t)distinctSensors;
    }

    if (out_checksum) {
        *out_checksum = checksum;
    }
    if (out_totalRows) {
        *out_totalRows = totalRows;
    }
    if (out_distinctSensorsPerFileSum) {
        *out_distinctSensorsPerFileSum = distinctSensorsPerFileSum;
    }
}
