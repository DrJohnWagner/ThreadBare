#include <stdint.h>
#include <stdlib.h>
#include <stddef.h>
#include <math.h>

static uint64_t xorshift64star(uint64_t *state) {
    uint64_t x = *state;
    x ^= x >> 12;
    x ^= x << 25;
    x ^= x >> 27;
    *state = x;
    return x * UINT64_C(2685821657736338717);
}

static double rand_uniform_open01(uint64_t *state) {
    /* Map to (0,1) open interval by discarding 0 and using 53 bits */
    uint64_t r;
    do {
        r = xorshift64star(state);
    } while (r == 0);
    const uint64_t top = r >> 11; /* 53 bits */
    return ((double)top + 1.0) / 9007199254740992.0; /* /2^53 */
}

static int sample_powerlaw_vertex(uint64_t *state, int nVertices, double invZ) {
    /* Draw x = floor(nVertices * r^(−1.3) / Z), using invZ=1/Z */
    const double a = 1.3;
    while (1) {
        double r1 = rand_uniform_open01(state);
        double t = pow(r1, -a) * invZ;
        long long x = (long long)floor((double)nVertices * t);
        if (x >= 0 && x < (long long)nVertices) {
            return (int)x;
        }
    }
}

static int cmp_int(const void *a, const void *b) {
    int ia = *(const int *)a;
    int ib = *(const int *)b;
    return (ia > ib) - (ia < ib);
}

/* Build deterministic graph per specification */
static void build_graph(int nVertices, int nEdges, uint64_t seed,
                          int **out_head, int **out_next, int **out_to,
                          int **out_edge_count_per_u) {
    int *head = (int *)malloc((size_t)nVertices * sizeof(int));
    int *next = (int *)malloc((size_t)nEdges * sizeof(int));
    int *to = (int *)malloc((size_t)nEdges * sizeof(int));
    int *edge_count_per_u = (int *)calloc((size_t)nVertices, sizeof(int));
    if (!head || !next || !to || !edge_count_per_u) {
        free(head);
        free(next);
        free(to);
        free(edge_count_per_u);
        *out_head = NULL;
        *out_next = NULL;
        *out_to = NULL;
        *out_edge_count_per_u = NULL;
        return;
    }

    for (int i = 0; i < nVertices; i++) head[i] = -1;

    /* Compute Z = sum_{k=0..nVertices-1} 1/(k+1)^1.3 in a way that avoids overflow */
    const double a = 1.3;
    double Z = 0.0;
    for (int k = 0; k < nVertices; k++) {
        double denom = pow((double)(k + 1), a);
        Z += 1.0 / denom;
    }
    double invZ = 1.0 / Z;

    uint64_t state = seed;

    for (int e = 0; e < nEdges; e++) {
        int u = sample_powerlaw_vertex(&state, nVertices, invZ);
        int v;
        while (1) {
            v = sample_powerlaw_vertex(&state, nVertices, invZ);
            double r = rand_uniform_open01(&state);
            if (v != u && r >= 0.5) break;
            if (v != u) {
                /* With probability 1/2, accept; otherwise resample */
                if (r >= 0.5) break;
            }
            /* If v==u, reject and resample */
        }

        to[e] = v;
        next[e] = head[u];
        head[u] = e;
        edge_count_per_u[u]++;
    }

    *out_head = head;
    *out_next = next;
    *out_to = to;
    *out_edge_count_per_u = edge_count_per_u;
}

/* Select 20 distinct deterministic sources from PRNG stream */
static void select_sources(int nVertices, int nSources, uint64_t seed, int *sources_out) {
    uint64_t state = seed;
    int count = 0;

    /* Use a small temporary array for membership checks (nSources <= 20). */
    while (count < nSources) {
        double U = rand_uniform_open01(&state);
        int s = (int)floor((double)nVertices * U);
        if (s < 0) s = 0;
        if (s >= nVertices) s = nVertices - 1;

        int exists = 0;
        for (int i = 0; i < count; i++) {
            if (sources_out[i] == s) {
                exists = 1;
                break;
            }
        }
        if (!exists) {
            sources_out[count++] = s;
        }
    }
}

/* BFS for a single source on the given forward-star adjacency */
static void bfs_one_source(int nVertices, const int *head, const int *next, const int *to,
                             int source, int *hops_out, int *parent_out) {
    int *queue = (int *)malloc((size_t)nVertices * sizeof(int));
    if (!queue) return;

    for (int i = 0; i < nVertices; i++) {
        hops_out[i] = -1;
        parent_out[i] = -1;
    }

    int qh = 0, qt = 0;
    hops_out[source] = 0;
    parent_out[source] = -1;
    queue[qt++] = source;

    while (qh < qt) {
        int u = queue[qh++];
        int du = hops_out[u];
        for (int e = head[u]; e != -1; e = next[e]) {
            int v = to[e];
            if (hops_out[v] == -1) {
                hops_out[v] = du + 1;
                parent_out[v] = u;
                queue[qt++] = v;
            }
        }
    }

    free(queue);
}

/*
  Primary entry: build graph and run BFS from 20 sources.
  Output layout:
  - hops[s* nVertices + i], parent[s* nVertices + i]
*/
int bfs_parent_hops_serial(int nVertices, int nEdges, uint64_t seed,
                            int nSources, int *sources_out,
                            int *hops_out, int *parent_out) {
    int *head = NULL;
    int *next = NULL;
    int *to = NULL;
    int *edge_count_per_u = NULL;

    build_graph(nVertices, nEdges, seed, &head, &next, &to, &edge_count_per_u);

    if (!head || !next || !to || !edge_count_per_u) {
        free(head);
        free(next);
        free(to);
        free(edge_count_per_u);
        return -1;
    }

    int *sources = sources_out;
    if (!sources) {
        sources = (int *)malloc((size_t)nSources * sizeof(int));
        if (!sources) {
            free(head);
            free(next);
            free(to);
            free(edge_count_per_u);
            return -1;
        }
        select_sources(nVertices, nSources, seed, sources);
    } else {
        select_sources(nVertices, nSources, seed, sources);
    }

    int *hops_tmp = (int *)malloc((size_t)nVertices * sizeof(int));
    int *parent_tmp = (int *)malloc((size_t)nVertices * sizeof(int));
    if (!hops_tmp || !parent_tmp) {
        free(hops_tmp);
        free(parent_tmp);
        free(head);
        free(next);
        free(to);
        free(edge_count_per_u);
        if (!sources_out) free(sources);
        return -1;
    }

    for (int si = 0; si < nSources; si++) {
        int src = sources[si];
        bfs_one_source(nVertices, head, next, to, src, hops_tmp, parent_tmp);
        for (int i = 0; i < nVertices; i++) {
            hops_out[si * nVertices + i] = hops_tmp[i];
            parent_out[si * nVertices + i] = parent_tmp[i];
        }
    }

    free(hops_tmp);
    free(parent_tmp);
    free(head);
    free(next);
    free(to);
    free(edge_count_per_u);
    if (!sources_out) free(sources);

    return 0;
}
