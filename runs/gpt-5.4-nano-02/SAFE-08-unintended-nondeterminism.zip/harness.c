/* harness.c — differential driver for bfs_parent_hops (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <inttypes.h>
#include <omp.h>

// Forward declarations matching the real signatures exactly.
int bfs_parent_hops_serial(int nVertices, int nEdges, uint64_t seed, int nSources,
                           int *sources_out, int *hops_out, int *parent_out);
int bfs_parent_hops_omp(int nVertices, int nEdges, uint64_t seed, int nSources,
                      int *sources_out, int *hops_out, int *parent_out);

static void xorshift64star_init(uint64_t *state, uint64_t seed) {
    if (seed == 0) seed = 88172645463325252ull;
    *state = seed;
}

static uint64_t xorshift64star_next(uint64_t *state) {
    uint64_t x = *state;
    x ^= x >> 12;
    x ^= x << 25;
    x ^= x >> 27;
    *state = x;
    return x * 2685821657736338717ull;
}

static inline double u01(uint64_t *state) {
    // Convert to double in (0,1)
    // Use top 53 bits.
    uint64_t r = xorshift64star_next(state);
    uint64_t top = r >> 11; // 53 bits
    return (top + 1.0) / 9007199254740992.0;
}

int main(int argc, char **argv) {
    int nVertices = 310000;
    int nEdges = 5000000;
    int nSources = 20;
    uint64_t seed = 12345ull;
    int reps = 20;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--reps") && i + 1 < argc) {
            reps = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--n") && i + 1 < argc) {
            nVertices = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--seed") && i + 1 < argc) {
            seed = (uint64_t)strtoull(argv[++i], NULL, 10);
        } else {
            fprintf(stderr, "Unknown/invalid arg: %s\n", argv[i]);
            return 1;
        }
    }

    int *src_serial = (int*)malloc((size_t)nSources * sizeof(int));
    int *src_par = (int*)malloc((size_t)nSources * sizeof(int));
    int *hops_serial = (int*)malloc((size_t)nVertices * sizeof(int));
    int *hops_par = (int*)malloc((size_t)nVertices * sizeof(int));
    int *parent_serial = (int*)malloc((size_t)nVertices * sizeof(int));
    int *parent_par = (int*)malloc((size_t)nVertices * sizeof(int));
    if (!src_serial || !src_par || !hops_serial || !hops_par || !parent_serial || !parent_par) {
        fprintf(stderr, "Allocation failed\n");
        return 1;
    }

    // Ground truth from serial reference.
    memset(src_serial, 0, (size_t)nSources * sizeof(int));
    memset(hops_serial, 0, (size_t)nVertices * sizeof(int));
    memset(parent_serial, 0, (size_t)nVertices * sizeof(int));

    int ok = bfs_parent_hops_serial(nVertices, nEdges, seed, nSources,
                                    src_serial, hops_serial, parent_serial);
    if (ok != 0) {
        fprintf(stderr, "Serial reference returned non-zero: %d\n", ok);
        free(src_serial); free(src_par);
        free(hops_serial); free(hops_par);
        free(parent_serial); free(parent_par);
        return 1;
    }

    int failures = 0;
    for (int rep = 0; rep < reps; rep++) {
        memset(src_par, 0, (size_t)nSources * sizeof(int));
        memset(hops_par, 0, (size_t)nVertices * sizeof(int));
        memset(parent_par, 0, (size_t)nVertices * sizeof(int));

        int threads = omp_get_max_threads();
        (void)threads;

        int ok2 = bfs_parent_hops_omp(nVertices, nEdges, seed, nSources,
                                     src_par, hops_par, parent_par);
        if (ok2 != 0) {
            fprintf(stderr, "Parallel returned non-zero at rep %d: %d\n", rep, ok2);
            failures = 1;
            break;
        }

        // Strict hops equality.
        for (int i = 0; i < nVertices; i++) {
            if (hops_par[i] != hops_serial[i]) {
                printf("[check] rep=%d mismatch at vertex=%d: hops_parallel=%d hops_serial=%d\n",
                       rep, i, hops_par[i], hops_serial[i]);
                failures = 1;
                goto done;
            }
        }

        // Parent is not required to match exactly; no further checks.
    }

done:
    printf("[verdict] %s\n", failures ? "SAFE-01 exposed" : "SAFE-01 not triggered");

    free(src_serial); free(src_par);
    free(hops_serial); free(hops_par);
    free(parent_serial); free(parent_par);
    return failures ? 1 : 0;
}
