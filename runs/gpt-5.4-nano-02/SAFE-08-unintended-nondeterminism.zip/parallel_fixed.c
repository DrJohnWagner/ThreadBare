#include <stdint.h>
#include <stdlib.h>
#include <stddef.h>
#include <math.h>
#include <omp.h>

static uint64_t xorshift64star(uint64_t *state) {
    uint64_t x = *state;
    x ^= x >> 12;
    x ^= x << 25;
    x ^= x >> 27;
    *state = x;
    return x * UINT64_C(2685821657736338717);
}

static double rand_uniform_open01(uint64_t *state) {
    /* Map to (0,1) open interval by discarding 0 and using 53 bits */
    uint64_t r;
    do {
        r = xorshift64star(state);
    } while (r == 0);
    const uint64_t top = r >> 11; /* 53 bits */
    return ((double)top + 1.0) / 9007199254740992.0; /* /2^53 */
}

static int sample_powerlaw_vertex(uint64_t *state, int nVertices, double invZ) {
    const double a = 1.3;
    while (1) {
        double r1 = rand_uniform_open01(state);
        double t = pow(r1, -a) * invZ;
        long long x = (long long)floor((double)nVertices * t);
        if (x >= 0 && x < (long long)nVertices) {
            return (int)x;
        }
    }
}

static void build_graph(int nVertices, int nEdges, uint64_t seed,
                          int **out_head, int **out_next, int **out_to,
                          int **out_edge_count_per_u) {
    int *head = (int *)malloc((size_t)nVertices * sizeof(int));
    int *next = (int *)malloc((size_t)nEdges * sizeof(int));
    int *to = (int *)malloc((size_t)nEdges * sizeof(int));
    int *edge_count_per_u = (int *)calloc((size_t)nVertices, sizeof(int));
    if (!head || !next || !to || !edge_count_per_u) {
        free(head);
        free(next);
        free(to);
        free(edge_count_per_u);
        *out_head = NULL;
        *out_next = NULL;
        *out_to = NULL;
        *out_edge_count_per_u = NULL;
        return;
    }

    for (int i = 0; i < nVertices; i++) head[i] = -1;

    const double a = 1.3;
    double Z = 0.0;
    for (int k = 0; k < nVertices; k++) {
        double denom = pow((double)(k + 1), a);
        Z += 1.0 / denom;
    }
    double invZ = 1.0 / Z;

    uint64_t state = seed;

    for (int e = 0; e < nEdges; e++) {
        int u = sample_powerlaw_vertex(&state, nVertices, invZ);
        int v;
        while (1) {
            v = sample_powerlaw_vertex(&state, nVertices, invZ);
            double r = rand_uniform_open01(&state);
            if (v != u && r >= 0.5) break;
            if (v != u) {
                if (r >= 0.5) break;
            }
        }

        to[e] = v;
        next[e] = head[u];
        head[u] = e;
        edge_count_per_u[u]++;
    }

    *out_head = head;
    *out_next = next;
    *out_to = to;
    *out_edge_count_per_u = edge_count_per_u;
}

static void select_sources(int nVertices, int nSources, uint64_t seed, int *sources_out) {
    uint64_t state = seed;
    int count = 0;

    while (count < nSources) {
        double U = rand_uniform_open01(&state);
        int s = (int)floor((double)nVertices * U);
        if (s < 0) s = 0;
        if (s >= nVertices) s = nVertices - 1;

        int exists = 0;
        for (int i = 0; i < count; i++) {
            if (sources_out[i] == s) {
                exists = 1;
                break;
            }
        }
        if (!exists) {
            sources_out[count++] = s;
        }
    }
}

static void bfs_one_source_omp(int nVertices, const int *head, const int *next, const int *to,
                                 int source, int *hops_out, int *parent_out) {
    for (int i = 0; i < nVertices; i++) {
        hops_out[i] = -1;
        parent_out[i] = -1;
    }

    int *frontier = (int *)malloc((size_t)nVertices * sizeof(int));
    int *next_frontier = (int *)malloc((size_t)nVertices * sizeof(int));
    if (!frontier || !next_frontier) {
        free(frontier);
        free(next_frontier);
        return;
    }

    int frontier_size = 1;
    frontier[0] = source;
    hops_out[source] = 0;

    int level = 0;
    while (frontier_size > 0) {
        int next_size = 0;

        #pragma omp parallel
        {
            int local_next_size = 0;
            int *local_next = (int *)malloc((size_t)frontier_size * 8u * sizeof(int));
            if (!local_next) {
                local_next = NULL;
                local_next_size = 0;
            }

            #pragma omp for schedule(static)
            for (int fi = 0; fi < frontier_size; fi++) {
                int u = frontier[fi];
                int du = level;
                for (int e = head[u]; e != -1; e = next[e]) {
                    int v = to[e];
                    if (hops_out[v] == -1) {
                        int expected = -1;
                        if (__sync_bool_compare_and_swap(&hops_out[v], expected, du + 1)) {
                            parent_out[v] = u;
                            if (local_next) {
                                local_next[local_next_size++] = v;
                            } else {
                                #pragma omp atomic capture
                                { /* reserve a slot */ }
                            }
                        }
                    }
                }
            }

            if (local_next) {
                int base;
                #pragma omp atomic capture
                { base = next_size; next_size += local_next_size; }
                for (int i = 0; i < local_next_size; i++) {
                    next_frontier[base + i] = local_next[i];
                }
            }

            free(local_next);
        }

        int *tmp = frontier;
        frontier = next_frontier;
        next_frontier = tmp;
        frontier_size = next_size;
        level++;
    }

    free(frontier);
    free(next_frontier);
}

int bfs_parent_hops_omp(int nVertices, int nEdges, uint64_t seed,
                        int nSources, int *sources_out,
                        int *hops_out, int *parent_out) {
    int *head = NULL;
    int *next = NULL;
    int *to = NULL;
    int *edge_count_per_u = NULL;

    build_graph(nVertices, nEdges, seed, &head, &next, &to, &edge_count_per_u);

    if (!head || !next || !to || !edge_count_per_u) {
        free(head);
        free(next);
        free(to);
        free(edge_count_per_u);
        return -1;
    }

    int *sources = sources_out;
    int need_free_sources = 0;
    if (!sources) {
        sources = (int *)malloc((size_t)nSources * sizeof(int));
        if (!sources) {
            free(head);
            free(next);
            free(to);
            free(edge_count_per_u);
            return -1;
        }
        need_free_sources = 1;
    }

    select_sources(nVertices, nSources, seed, sources);

    int *hops_tmp = (int *)malloc((size_t)nVertices * sizeof(int));
    int *parent_tmp = (int *)malloc((size_t)nVertices * sizeof(int));
    if (!hops_tmp || !parent_tmp) {
        free(hops_tmp);
        free(parent_tmp);
        free(head);
        free(next);
        free(to);
        free(edge_count_per_u);
        if (need_free_sources) free(sources);
        return -1;
    }

    for (int si = 0; si < nSources; si++) {
        int src = sources[si];
        bfs_one_source_omp(nVertices, head, next, to, src, hops_tmp, parent_tmp);
        for (int i = 0; i < nVertices; i++) {
            hops_out[si * nVertices + i] = hops_tmp[i];
            parent_out[si * nVertices + i] = parent_tmp[i];
        }
    }

    free(hops_tmp);
    free(parent_tmp);
    free(head);
    free(next);
    free(to);
    free(edge_count_per_u);
    if (need_free_sources) free(sources);

    return 0;
}
