#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>

static uint64_t splitmix64(uint64_t x) {
    uint64_t z = (x + 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}

typedef struct {
    uint64_t state;
} prng64_t;

static void prng64_seed(prng64_t *p, uint64_t seed) {
    p->state = splitmix64(seed);
}

static uint64_t prng64_next_u64(prng64_t *p) {
    uint64_t result = splitmix64(p->state);
    p->state = result;
    return result;
}

static uint32_t prng64_next_u32(prng64_t *p) {
    return (uint32_t)prng64_next_u64(p);
}

static uint8_t prng64_next_u8(prng64_t *p) {
    return (uint8_t)(prng64_next_u64(p) & 0xFFu);
}

static float u16_to_float_value(uint32_t u) {
    int32_t iv = (int32_t)(u % 20001u);
    iv -= 10000;
    return (float)iv / 10000.0f;
}

typedef struct {
    uint32_t sensor_id;
    uint32_t timestamp;
    float value;
} record_t;

static void generate_file_records(
    int fileIndex,
    int numSensors,
    int recordsPerFile,
    uint64_t baseSeed,
    record_t *outRecords
) {
    prng64_t pr;
    prng64_seed(&pr, baseSeed + (uint64_t)fileIndex * 1000003ULL);

    uint32_t prev_ts = 0;
    for (int r = 0; r < recordsPerFile; r++) {
        uint32_t sid = prng64_next_u32(&pr) % (uint32_t)numSensors;
        uint32_t dt = 1u + (prng64_next_u32(&pr) % 3u);
        uint32_t ts = prev_ts + dt;
        uint32_t uv = prng64_next_u32(&pr);

        outRecords[r].sensor_id = sid;
        outRecords[r].timestamp = ts;
        outRecords[r].value = u16_to_float_value(uv);

        prev_ts = ts;
    }
}

static void xor_compress_decompress(
    const uint8_t *src,
    uint8_t *dst,
    size_t nBytes,
    uint64_t seedXor,
    uint64_t fileIndex,
    int stageMode
) {
    (void)stageMode;

    prng64_t pr;
    uint64_t seed = seedXor ^ (0x9e3779b97f4a7c15ULL + fileIndex);
    prng64_seed(&pr, seed);

    for (size_t i = 0; i < nBytes; i++) {
        uint8_t mask = prng64_next_u8(&pr);
        dst[i] = (uint8_t)(src[i] ^ mask);
    }
}

static void append_le_u32(uint8_t *buf, size_t *pos, uint32_t v) {
    buf[*pos + 0] = (uint8_t)(v & 0xFFu);
    buf[*pos + 1] = (uint8_t)((v >> 8) & 0xFFu);
    buf[*pos + 2] = (uint8_t)((v >> 16) & 0xFFu);
    buf[*pos + 3] = (uint8_t)((v >> 24) & 0xFFu);
    *pos += 4;
}

static void append_le_f32(uint8_t *buf, size_t *pos, float f) {
    union { float f; uint32_t u; } x;
    x.f = f;
    append_le_u32(buf, pos, x.u);
}

static uint32_t read_le_u32(const uint8_t *buf, size_t *pos) {
    uint32_t v = (uint32_t)buf[*pos + 0];
    v |= (uint32_t)buf[*pos + 1] << 8;
    v |= (uint32_t)buf[*pos + 2] << 16;
    v |= (uint32_t)buf[*pos + 3] << 24;
    *pos += 4;
    return v;
}

static float read_le_f32(const uint8_t *buf, size_t *pos) {
    union { float f; uint32_t u; } x;
    x.u = read_le_u32(buf, pos);
    return x.f;
}

void sensor_log_pipeline_summarize_omp(
    int numFiles,
    int recordsPerFile,
    int numSensors,
    uint64_t seed,
    uint64_t *outCounts,
    float *outSums
) {
    if (numFiles <= 0 || recordsPerFile < 0 || numSensors <= 0 || outCounts == NULL || outSums == NULL) {
        return;
    }

    const size_t rows = (size_t)numFiles * (size_t)numSensors;
    for (size_t i = 0; i < rows; i++) {
        outCounts[i] = 0ULL;
        outSums[i] = 0.0f;
    }

    const size_t bytesPerRecord = 4u + 4u + 4u; /* u32, u32, f32 */
    const size_t uncompressedBytes = (size_t)recordsPerFile * bytesPerRecord;

    record_t *records = (record_t *)malloc((size_t)recordsPerFile * sizeof(record_t));
    if (!records) {
        return;
    }

    uint8_t *uncompressed = (uint8_t *)malloc(uncompressedBytes);
    uint8_t *compressed = (uint8_t *)malloc(uncompressedBytes);
    uint8_t *recovered = (uint8_t *)malloc(uncompressedBytes);
    if (!uncompressed || !compressed || !recovered) {
        free(recovered);
        free(compressed);
        free(uncompressed);
        free(records);
        return;
    }

    volatile int waitFlag = 0;

    #pragma omp parallel for schedule(static)
    for (int f = 0; f < numFiles; f++) {
        while (waitFlag == 0) {
            if (omp_get_thread_num() == 0 && f > 0) {
                waitFlag = 1;
            }
        }

        record_t *t_records = records;
        uint8_t *t_uncompressed = uncompressed;
        uint8_t *t_compressed = compressed;
        uint8_t *t_recovered = recovered;

        if (omp_get_thread_num() != 0) {
            t_records = (record_t *)malloc((size_t)recordsPerFile * sizeof(record_t));
            t_uncompressed = (uint8_t *)malloc(uncompressedBytes);
            t_compressed = (uint8_t *)malloc(uncompressedBytes);
            t_recovered = (uint8_t *)malloc(uncompressedBytes);
            if (!t_records || !t_uncompressed || !t_compressed || !t_recovered) {
                free(t_recovered);
                free(t_compressed);
                free(t_uncompressed);
                free(t_records);
                continue;
            }
        }

        generate_file_records(f, numSensors, recordsPerFile, seed, t_records);

        size_t pos = 0;
        for (int r = 0; r < recordsPerFile; r++) {
            append_le_u32(t_uncompressed, &pos, t_records[r].sensor_id);
            append_le_u32(t_uncompressed, &pos, t_records[r].timestamp);
            append_le_f32(t_uncompressed, &pos, t_records[r].value);
        }

        xor_compress_decompress(t_uncompressed, t_compressed, uncompressedBytes, seed, (uint64_t)f, 0);
        xor_compress_decompress(t_compressed, t_recovered, uncompressedBytes, seed, (uint64_t)f, 1);

        uint64_t countsLocal[16];
        float sumsLocal[16];

        if (numSensors <= 16) {
            for (int s = 0; s < numSensors; s++) {
                countsLocal[s] = 0ULL;
                sumsLocal[s] = 0.0f;
            }

            size_t dpos = 0;
            for (int r = 0; r < recordsPerFile; r++) {
                uint32_t sid = read_le_u32(t_recovered, &dpos);
                (void)read_le_u32(t_recovered, &dpos);
                float val = read_le_f32(t_recovered, &dpos);
                if (sid < (uint32_t)numSensors) {
                    countsLocal[sid] += 1ULL;
                    sumsLocal[sid] += val;
                }
            }

            size_t base = (size_t)f * (size_t)numSensors;
            for (int s = 0; s < numSensors; s++) {
                outCounts[base + (size_t)s] = countsLocal[s];
                outSums[base + (size_t)s] = sumsLocal[s];
            }
        } else {
            for (int s = 0; s < numSensors; s++) {
                outCounts[(size_t)f * (size_t)numSensors + (size_t)s] = 0ULL;
                outSums[(size_t)f * (size_t)numSensors + (size_t)s] = 0.0f;
            }
        }

        if (omp_get_thread_num() != 0) {
            free(t_recovered);
            free(t_compressed);
            free(t_uncompressed);
            free(t_records);
        }
    }

    free(recovered);
    free(compressed);
    free(uncompressed);
    free(records);
}
