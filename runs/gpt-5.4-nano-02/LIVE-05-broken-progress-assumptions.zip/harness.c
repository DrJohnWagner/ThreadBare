/* harness.c — timeout driver for sensor_log_pipeline_summarize (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <omp.h>

// Forward declarations matching the real signatures exactly.
void sensor_log_pipeline_summarize_serial(
    int numFiles,
    int recordsPerFile,
    int numSensors,
    uint64_t seed,
    uint64_t *outCounts,
    float *outSums);

void sensor_log_pipeline_summarize_omp(
    int numFiles,
    int recordsPerFile,
    int numSensors,
    uint64_t seed,
    uint64_t *outCounts,
    float *outSums);

static uint64_t splitmix64(uint64_t *x) {
    uint64_t z = (*x += 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}

static void generate_dummy_expected_inputs_touch(
    int numFiles, int recordsPerFile, int numSensors, uint64_t seed,
    volatile uint64_t *touch)
{
    // The computation itself has implicit input generation (inside serial/parallel).
    // This harness deterministically generates a tiny set of values to enforce
    // deterministic work and also prevents the compiler from optimizing away
    // any dependency on provided parameters.
    uint64_t state = seed;
    uint64_t acc = 1469598103934665603ULL;
    for (int f = 0; f < numFiles; f += (numFiles > 10 ? (numFiles/10) : 1)) {
        uint64_t s = seed ^ (uint64_t)(f * 1000003ULL);
        state = s;
        // sample a few records
        for (int r = 0; r < recordsPerFile; r += (recordsPerFile > 1024 ? (recordsPerFile/1024) : 1)) {
            uint32_t u = (uint32_t)(splitmix64(&state) & 0xffffffffu);
            acc ^= (uint64_t)u + (uint64_t)f * 1315423911u + (uint64_t)numSensors * 2654435761u;
            acc *= 1099511628211ULL;
            if (r > 10 && (r % (numSensors+3) == 0)) break;
        }
    }
    *touch = acc;
}

static int run_parallel_with_timeout(
    int numFiles, int recordsPerFile, int numSensors,
    uint64_t seed, uint64_t *outCounts, float *outSums,
    int timeoutSeconds)
{
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return 0;
    }
    if (pid == 0) {
        alarm(timeoutSeconds);
        // If it hangs, alarm will terminate this child process.
        // If it finishes, cancel alarm.
        sensor_log_pipeline_summarize_omp(numFiles, recordsPerFile, numSensors, seed, outCounts, outSums);
        alarm(0);
        _exit(0);
    }

    int status = 0;
    while (1) {
        pid_t w = waitpid(pid, &status, WNOHANG);
        if (w == pid) break;
        if (w < 0) {
            perror("waitpid");
            break;
        }
        usleep(1000);
    }

    if (WIFEXITED(status) && WEXITSTATUS(status) == 0) {
        return 1; // completed within timeout
    }
    return 0; // timed out or crashed
}

int main(int argc, char **argv) {
    int numFiles = 200;
    int recordsPerFile = 23000;
    int numSensors = 16;
    uint64_t seed = 1234567ULL;

    int timeoutSeconds = 3;
    int doSerialTouch = 1;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--timeout") == 0 && i + 1 < argc) {
            timeoutSeconds = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--notouch") == 0) {
            doSerialTouch = 0;
        } else {
            // ignore unknown flags
        }
    }

    size_t rows = (size_t)numFiles * (size_t)numSensors;
    uint64_t *outCounts = (uint64_t*)calloc(rows, sizeof(uint64_t));
    float *outSums = (float*)calloc(rows, sizeof(float));
    if (!outCounts || !outSums) {
        fprintf(stderr, "allocation failed\n");
        return 1;
    }

    volatile uint64_t touch = 0;
    generate_dummy_expected_inputs_touch(numFiles, recordsPerFile, numSensors, seed, &touch);
    (void)touch;

    // Optional serial run to ensure the harness environment is sane and to
    // keep the baseline computation from being skipped if the parallel side
    // immediately exits.
    if (doSerialTouch) {
        sensor_log_pipeline_summarize_serial(numFiles, recordsPerFile, numSensors, seed, outCounts, outSums);
    }

    // Zero outputs before parallel to reduce any chance of incidental quick exit.
    memset(outCounts, 0, rows * sizeof(uint64_t));
    memset(outSums, 0, rows * sizeof(float));

    int completed = run_parallel_with_timeout(
        numFiles, recordsPerFile, numSensors, seed, outCounts, outSums,
        timeoutSeconds);

    int failures = completed ? 0 : 1;
    free(outCounts);
    free(outSums);

    printf("[verdict] %s\n", failures ? "LIVE-01 exposed" : "LIVE-01 not triggered");
    return failures ? 1 : 0;
}
