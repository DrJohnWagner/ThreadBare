#include <stdint.h>
#include <stdlib.h>
#include <omp.h>

typedef struct {
    int32_t cnt;
    int64_t sum_val_milli;
} sensor_summary_t;

void sensor_ingest_pipeline_omp(
    int F,
    int S,
    int R,
    uint32_t seed,
    sensor_summary_t *out_table /* size F*S */,
    int64_t *out_total_cnt,
    int64_t *out_total_sum_val_milli)
{
    (void)seed;

    const size_t FS = (size_t)F * (size_t)S;
    for (size_t idx = 0; idx < FS; idx++) {
        out_table[idx].cnt = 0;
        out_table[idx].sum_val_milli = 0;
    }

    /* Parallelize over files; each thread accumulates into its own file slice. */
    #pragma omp parallel for schedule(static)
    for (int f = 0; f < F; f++) {
        for (int i = 0; i < R; i++) {
            uint32_t uf = (uint32_t)f;
            uint32_t ui = (uint32_t)i;

            uint32_t sensor_id = (1103515245u * (uf + 1u) + 12345u * (ui + 1u)) % (uint32_t)S;

            int64_t num = (int64_t)(uf + 1u) * 1000LL + (int64_t)ui * 13LL + (int64_t)sensor_id * 37LL;
            int32_t val_milli = (int32_t)(num % 100000LL);
            if (val_milli < 0) val_milli = -val_milli;

            sensor_summary_t *cell = &out_table[(size_t)f * (size_t)S + (size_t)sensor_id];
            cell->cnt += 1;
            cell->sum_val_milli += (int64_t)val_milli;
        }
    }

    int64_t total_cnt = 0;
    int64_t total_sum = 0;

    #pragma omp parallel for reduction(+:total_cnt,total_sum) schedule(static)
    for (int f = 0; f < F; f++) {
        for (int s = 0; s < S; s++) {
            const sensor_summary_t *cell = &out_table[(size_t)f * (size_t)S + (size_t)s];
            total_cnt += (int64_t)cell->cnt;
            total_sum += cell->sum_val_milli;
        }
    }

    if (out_total_cnt) *out_total_cnt = total_cnt;
    if (out_total_sum_val_milli) *out_total_sum_val_milli = total_sum;
}
