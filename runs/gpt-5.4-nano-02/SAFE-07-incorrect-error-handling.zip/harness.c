/* harness.c — differential driver for sensor_ingest_pipeline (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <omp.h>

// Forward declarations matching the real signatures.
// The harness assumes the real sensor_summary_t has at least these fields.
typedef struct {
    int64_t cnt;
    int64_t sum_val_milli;
    double mean_val;
} sensor_summary_t;

void sensor_ingest_pipeline_serial(int F, int S, int R, uint32_t seed,
                                   sensor_summary_t *out_table,
                                   int64_t *out_total_cnt,
                                   int64_t *out_total_sum_val_milli);

void sensor_ingest_pipeline_omp(int F, int S, int R, uint32_t seed,
                                sensor_summary_t *out_table,
                                int64_t *out_total_cnt,
                                int64_t *out_total_sum_val_milli);

static uint32_t rng_u32(uint32_t *state) {
    // Deterministic LCG; must match the computation spec.
    *state = (*state) * 1103515245u + 12345u;
    return *state;
}

static void usage(const char *prog) {
    fprintf(stderr,
            "Usage: %s [--n F] [--reps N] [--seed SEED] [--threads N]\n",
            prog);
}

int main(int argc, char **argv) {
    int F = 200;              // default: largest specified size for observability
    int S = 8;
    int R = 23000;
    uint32_t seed = 1337u;
    int reps = 25;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--n") && i + 1 < argc) {
            F = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--reps") && i + 1 < argc) {
            reps = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--seed") && i + 1 < argc) {
            unsigned long v = strtoul(argv[++i], NULL, 10);
            seed = (uint32_t)v;
        } else if (!strcmp(argv[i], "--threads") && i + 1 < argc) {
            int t = atoi(argv[++i]);
            if (t > 0) omp_set_num_threads(t);
        } else {
            usage(argv[0]);
            return 0;
        }
    }

    if (F <= 0) {
        fprintf(stderr, "Invalid --n\n");
        return 0;
    }

    size_t table_elems = (size_t)F * (size_t)S;
    sensor_summary_t *ref_table = (sensor_summary_t *)malloc(table_elems * sizeof(sensor_summary_t));
    sensor_summary_t *par_table = (sensor_summary_t *)malloc(table_elems * sizeof(sensor_summary_t));
    if (!ref_table || !par_table) {
        fprintf(stderr, "Allocation failed\n");
        free(ref_table);
        free(par_table);
        return 0;
    }

    int64_t ref_total_cnt = 0;
    int64_t ref_total_sum = 0;

    // Ground truth.
    memset(ref_table, 0, table_elems * sizeof(sensor_summary_t));
    sensor_ingest_pipeline_serial(F, S, R, seed, ref_table, &ref_total_cnt, &ref_total_sum);

    int failures = 0;

    // Differential checks across repetitions.
    for (int rep = 0; rep < reps && !failures; rep++) {
        int64_t par_total_cnt = 0;
        int64_t par_total_sum = 0;
        memset(par_table, 0, table_elems * sizeof(sensor_summary_t));

        sensor_ingest_pipeline_omp(F, S, R, seed, par_table, &par_total_cnt, &par_total_sum);

        // Compare totals first: the planted bug targets out_total_sum_val_milli.
        if (par_total_cnt != ref_total_cnt) {
            printf("[check] rep=%d mismatch: out_total_cnt ref=%lld par=%lld\n",
                   rep, (long long)ref_total_cnt, (long long)par_total_cnt);
            failures = 1;
            break;
        }
        if (par_total_sum != ref_total_sum) {
            printf("[check] rep=%d mismatch: out_total_sum_val_milli ref=%lld par=%lld\n",
                   rep, (long long)ref_total_sum, (long long)par_total_sum);
            failures = 1;
            break;
        }

        // Compare full table: cnt and sum must match exactly; mean within tolerance.
        const double tol = 1e-9;
        for (int f = 0; f < F && !failures; f++) {
            for (int s = 0; s < S; s++) {
                size_t idx = (size_t)f * (size_t)S + (size_t)s;
                if (par_table[idx].cnt != ref_table[idx].cnt ||
                    par_table[idx].sum_val_milli != ref_table[idx].sum_val_milli) {
                    printf("[check] rep=%d mismatch: (f=%d,s=%d) cnt/ref=%lld par=%lld sum/ref=%lld par=%lld\n",
                           rep, f, s,
                           (long long)ref_table[idx].cnt, (long long)par_table[idx].cnt,
                           (long long)ref_table[idx].sum_val_milli, (long long)par_table[idx].sum_val_milli);
                    failures = 1;
                    break;
                }
                double d = fabs(par_table[idx].mean_val - ref_table[idx].mean_val);
                if (d > tol) {
                    printf("[check] rep=%d mismatch: (f=%d,s=%d) mean ref=%.17g par=%.17g |diff|=%.3g\n",
                           rep, f, s, ref_table[idx].mean_val, par_table[idx].mean_val, d);
                    failures = 1;
                    break;
                }
            }
        }
    }

    free(ref_table);
    free(par_table);

    if (failures) {
        printf("[verdict] SAFE-01 exposed\n");
        return 1;
    } else {
        printf("[verdict] SAFE-01 not triggered\n");
        return 0;
    }
}
