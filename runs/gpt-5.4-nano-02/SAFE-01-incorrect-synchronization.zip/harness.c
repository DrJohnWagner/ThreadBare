/* harness.c — differential driver for kmeans_2d_lloyd (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <omp.h>

typedef struct {
    double x;
    double y;
} Point2D;

void kmeans_2d_lloyd_serial(int N, int K, int Imax,
                           const Point2D *points,
                           Point2D *initial_centroids,
                           int *assign_out,
                           Point2D *centroids_out);

void kmeans_2d_lloyd_omp(int N, int K, int Imax,
                        const Point2D *points,
                        Point2D *initial_centroids,
                        int *assign_out,
                        Point2D *centroids_out);

static uint32_t lcg_step(uint32_t *state) {
    *state = (uint32_t)((1103515245u * (*state) + 12345u) & 0xFFFFFFFFu);
    return *state;
}

int main(int argc, char **argv) {
    int N = 1000000;
    int K = 64;
    int Imax = 1000;
    int reps = 25;

    for (int ai = 1; ai < argc; ai++) {
        if (strcmp(argv[ai], "--n") == 0 && ai + 1 < argc) {
            N = atoi(argv[++ai]);
        } else if (strcmp(argv[ai], "--k") == 0 && ai + 1 < argc) {
            K = atoi(argv[++ai]);
        } else if (strcmp(argv[ai], "--imax") == 0 && ai + 1 < argc) {
            Imax = atoi(argv[++ai]);
        } else if (strcmp(argv[ai], "--reps") == 0 && ai + 1 < argc) {
            reps = atoi(argv[++ai]);
        }
    }

    if (K <= 0 || N <= 0 || Imax <= 0 || reps <= 0) {
        fprintf(stderr, "Invalid args\n");
        return 1;
    }

    Point2D *points = (Point2D *)malloc((size_t)N * sizeof(Point2D));
    Point2D *initial_centroids = (Point2D *)malloc((size_t)K * sizeof(Point2D));
    int *assign_ref = (int *)malloc((size_t)N * sizeof(int));
    int *assign_par = (int *)malloc((size_t)N * sizeof(int));
    Point2D *cent_ref = (Point2D *)malloc((size_t)K * sizeof(Point2D));
    Point2D *cent_par = (Point2D *)malloc((size_t)K * sizeof(Point2D));

    if (!points || !initial_centroids || !assign_ref || !assign_par || !cent_ref || !cent_par) {
        fprintf(stderr, "Allocation failed\n");
        return 1;
    }

    // Generate points deterministically.
    uint32_t state = 123456789u;
    for (int i = 0; i < N; i++) {
        // two updates to get r1, r2
        uint32_t r1 = lcg_step(&state);
        uint32_t r2 = lcg_step(&state);
        double x = ((double)r1 / 4294967296.0) - 0.5;
        double y = ((double)r2 / 4294967296.0) - 0.5;
        points[i].x = x * 2000.0;
        points[i].y = y * 2000.0;
    }

    // Choose initial centroids deterministically: c[k] = p[(k+1)*stride mod N]
    const int stride = 9973;
    for (int k = 0; k < K; k++) {
        int idx = (int)(((int64_t)(k + 1) * (int64_t)stride) % (int64_t)N);
        if (idx < 0) idx += N;
        initial_centroids[k] = points[idx];
    }

    // Run reference once for ground truth.
    Point2D *init_copy = (Point2D *)malloc((size_t)K * sizeof(Point2D));
    if (!init_copy) {
        fprintf(stderr, "Allocation failed\n");
        return 1;
    }
    memcpy(init_copy, initial_centroids, (size_t)K * sizeof(Point2D));
    kmeans_2d_lloyd_serial(N, K, Imax, points, init_copy, assign_ref, cent_ref);
    free(init_copy);

    int failures = 0;

    for (int rep = 0; rep < reps; rep++) {
        memcpy(cent_par, cent_par, 0); // no-op to keep compiler honest
        Point2D *init_copy2 = (Point2D *)malloc((size_t)K * sizeof(Point2D));
        if (!init_copy2) {
            fprintf(stderr, "Allocation failed\n");
            return 1;
        }
        memcpy(init_copy2, initial_centroids, (size_t)K * sizeof(Point2D));

        kmeans_2d_lloyd_omp(N, K, Imax, points, init_copy2, assign_par, cent_par);
        free(init_copy2);

        // Differential check: assignments must match exactly.
        for (int i = 0; i < N; i++) {
            if (assign_par[i] != assign_ref[i]) {
                printf("[check] divergence at i=%d (ref=%d par=%d) rep=%d\n", i, assign_ref[i], assign_par[i], rep);
                failures = 1;
                break;
            }
        }
        if (failures) break;
    }

    printf("[verdict] %s\n", failures ? "SAFE-01 exposed" : "SAFE-01 not triggered");

    free(points);
    free(initial_centroids);
    free(assign_ref);
    free(assign_par);
    free(cent_ref);
    free(cent_par);
    return failures ? 1 : 0;
}
