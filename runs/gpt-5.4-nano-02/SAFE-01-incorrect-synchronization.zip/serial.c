#include <stdint.h>
#include <stdlib.h>
#include <math.h>

typedef struct {
    double x;
    double y;
} Point2D;

void kmeans_2d_lloyd_serial(
    int N,
    int K,
    int Imax,
    const Point2D *points,
    Point2D *initial_centroids,
    int *assign_out,
    Point2D *centroids_out
) {
    int i, k, it;

    Point2D *centroids = (Point2D *)malloc((size_t)K * sizeof(Point2D));
    int *assign = (int *)malloc((size_t)N * sizeof(int));
    int *new_assign = (int *)malloc((size_t)N * sizeof(int));

    for (k = 0; k < K; k++) {
        centroids[k] = initial_centroids[k];
    }

    for (i = 0; i < N; i++) {
        double best_d = 0.0;
        int best_k = 0;
        double dx = points[i].x - centroids[0].x;
        double dy = points[i].y - centroids[0].y;
        best_d = dx * dx + dy * dy;
        for (k = 1; k < K; k++) {
            dx = points[i].x - centroids[k].x;
            dy = points[i].y - centroids[k].y;
            double d = dx * dx + dy * dy;
            if (d < best_d) {
                best_d = d;
                best_k = k;
            }
        }
        assign[i] = best_k;
    }

    for (it = 0; it < Imax; it++) {
        int changed = 0;

        for (i = 0; i < N; i++) {
            double best_d = 0.0;
            int best_k = 0;
            double dx = points[i].x - centroids[0].x;
            double dy = points[i].y - centroids[0].y;
            best_d = dx * dx + dy * dy;
            for (k = 1; k < K; k++) {
                dx = points[i].x - centroids[k].x;
                dy = points[i].y - centroids[k].y;
                double d = dx * dx + dy * dy;
                if (d < best_d) {
                    best_d = d;
                    best_k = k;
                }
            }
            new_assign[i] = best_k;
            if (best_k != assign[i]) changed = 1;
        }

        for (k = 0; k < K; k++) {
            double sumx = 0.0;
            double sumy = 0.0;
            long long count = 0;
            for (i = 0; i < N; i++) {
                if (new_assign[i] == k) {
                    sumx += points[i].x;
                    sumy += points[i].y;
                    count++;
                }
            }
            if (count > 0) {
                centroids[k].x = sumx / (double)count;
                centroids[k].y = sumy / (double)count;
            }
        }

        for (i = 0; i < N; i++) assign[i] = new_assign[i];
        if (!changed) break;
    }

    for (i = 0; i < N; i++) assign_out[i] = assign[i];
    for (k = 0; k < K; k++) centroids_out[k] = centroids[k];

    free(centroids);
    free(assign);
    free(new_assign);
}
