#include <stddef.h>
#include <stdint.h>
#include <math.h>
#include <stdlib.h>
#include <omp.h>

void kmeans_lloyd_omp(
    const size_t n,
    double *x,
    double *y,
    double *cx,
    double *cy,
    int *a,
    size_t maxIters,
    int k,
    int *outIters
) {
    (void)k; /* k is fixed to 64 by the benchmark; kept only for signature compatibility */

    const size_t K = 64;

    if (n == 0) {
        if (outIters) {
            *outIters = 0;
        }
        return;
    }

    /* Initialize centroids deterministically from points */
    if (cx && cy) {
        for (size_t j = 0; j < K; j++) {
            size_t idx = (size_t)((j * 1315423911ULL) % (uint64_t)n);
            cx[j] = x[idx];
            cy[j] = y[idx];
        }
    }

    int *prevA = (int *)malloc(n * sizeof(int));
    if (!prevA) {
        return;
    }

    for (size_t i = 0; i < n; i++) {
        prevA[i] = -1;
        a[i] = -1;
    }

    int itersDone = 0;

    for (size_t iter = 0; iter < maxIters; iter++) {
        int anyChanged = 0;

        /* Phase 1: assignment */
        #pragma omp parallel for schedule(static) reduction(| : anyChanged)
        for (size_t i = 0; i < n; i++) {
            double xi = x[i];
            double yi = y[i];

            size_t bestj = 0;
            double bestDist;
            {
                double dx0 = xi - cx[0];
                double dy0 = yi - cy[0];
                bestDist = dx0 * dx0 + dy0 * dy0;
            }

            for (size_t j = 1; j < K; j++) {
                double dx = xi - cx[j];
                double dy = yi - cy[j];
                double dist = dx * dx + dy * dy;
                if (dist < bestDist) {
                    bestDist = dist;
                    bestj = j;
                }
            }

            a[i] = (int)bestj;
            if (a[i] != prevA[i]) {
                anyChanged = 1;
            }
        }

        if (!anyChanged) {
            itersDone = (int)iter;
            break;
        }

        /* Phase 2: recompute centroids */
        double *sumX = (double *)calloc(K * (size_t)omp_get_max_threads(), sizeof(double));
        double *sumY = (double *)calloc(K * (size_t)omp_get_max_threads(), sizeof(double));
        uint64_t *cnt = (uint64_t *)calloc(K * (size_t)omp_get_max_threads(), sizeof(uint64_t));

        int maxT = omp_get_max_threads();

        #pragma omp parallel
        {
            int tid = omp_get_thread_num();
            double *localSumX = sumX + (size_t)tid * K;
            double *localSumY = sumY + (size_t)tid * K;
            uint64_t *localCnt = cnt + (size_t)tid * K;

            #pragma omp for schedule(static)
            for (size_t i = 0; i < n; i++) {
                int cj = a[i];
                localCnt[(size_t)cj] += 1ULL;
                localSumX[(size_t)cj] += x[i];
                localSumY[(size_t)cj] += y[i];
            }
        }

        /* Combine per-thread partials in a fixed order for deterministic arithmetic */
        for (size_t j = 0; j < K; j++) {
            double sX = 0.0;
            double sY = 0.0;
            uint64_t c = 0;
            for (int tid = 0; tid < maxT; tid++) {
                sX += sumX[(size_t)tid * K + j];
                sY += sumY[(size_t)tid * K + j];
                c += cnt[(size_t)tid * K + j];
            }
            if (c > 0) {
                double inv = 1.0 / (double)c;
                cx[j] = sX * inv;
                cy[j] = sY * inv;
            }
        }

        free(sumX);
        free(sumY);
        free(cnt);

        /* Phase 3: update previous assignments */
        #pragma omp parallel for schedule(static)
        for (size_t i = 0; i < n; i++) {
            prevA[i] = a[i];
        }

        itersDone = (int)(iter + 1);
    }

    if (outIters) {
        *outIters = itersDone;
    }

    free(prevA);
}
