#include <stddef.h>
#include <stdint.h>
#include <math.h>

static uint64_t lcg_next_u64(uint64_t s) {
    return (uint64_t)(6364136223846793005ULL * s + 1ULL);
}

static double lcg_uniform01(uint64_t *state) {
    uint64_t s = lcg_next_u64(*state);
    *state = s;
    /* u in [0,1): u = (s >> 11) * 2^-53 */
    return (double)((s >> 11) & 0x1FFFFFFFFFFFFFULL) * (1.0 / 9007199254740992.0);
}

void kmeans_lloyd_serial(
    const size_t n,
    double *x,
    double *y,
    double *cx,
    double *cy,
    int *a,
    size_t maxIters,
    int k,
    int *outIters
) {
    (void)k; /* k is fixed to 64 by the benchmark; kept only for signature compatibility */

    const size_t K = 64;

    if (n == 0) {
        if (outIters) {
            *outIters = 0;
        }
        return;
    }

    /* Initialize centroids deterministically from points */
    if (cx && cy) {
        for (size_t j = 0; j < K; j++) {
            size_t idx = (size_t)((j * 1315423911ULL) % (uint64_t)n);
            cx[j] = x[idx];
            cy[j] = y[idx];
        }
    }

    int *prevA = (int *)malloc(n * sizeof(int));
    if (!prevA) {
        return;
    }

    for (size_t i = 0; i < n; i++) {
        prevA[i] = -1;
        a[i] = -1;
    }

    int itersDone = 0;

    for (size_t iter = 0; iter < maxIters; iter++) {
        int anyChanged = 0;

        /* Phase 1: assignment */
        for (size_t i = 0; i < n; i++) {
            double xi = x[i];
            double yi = y[i];

            size_t bestj = 0;
            double bestDist = 0.0;
            {
                double dx0 = xi - cx[0];
                double dy0 = yi - cy[0];
                bestDist = dx0 * dx0 + dy0 * dy0;
            }

            for (size_t j = 1; j < K; j++) {
                double dx = xi - cx[j];
                double dy = yi - cy[j];
                double dist = dx * dx + dy * dy;
                if (dist < bestDist) {
                    bestDist = dist;
                    bestj = j;
                }
            }

            a[i] = (int)bestj;
            if (a[i] != prevA[i]) {
                anyChanged = 1;
            }
        }

        if (!anyChanged) {
            itersDone = (int)iter;
            break;
        }

        /* Phase 2: recompute centroids */
        double sumX[64];
        double sumY[64];
        uint64_t cnt[64];
        for (size_t j = 0; j < K; j++) {
            sumX[j] = 0.0;
            sumY[j] = 0.0;
            cnt[j] = 0;
        }

        for (size_t i = 0; i < n; i++) {
            int cj = a[i];
            cnt[(size_t)cj] += 1ULL;
            sumX[(size_t)cj] += x[i];
            sumY[(size_t)cj] += y[i];
        }

        for (size_t j = 0; j < K; j++) {
            if (cnt[j] > 0) {
                double inv = 1.0 / (double)cnt[j];
                cx[j] = sumX[j] * inv;
                cy[j] = sumY[j] * inv;
            }
        }

        /* Phase 3: update previous assignments */
        for (size_t i = 0; i < n; i++) {
            prevA[i] = a[i];
        }

        itersDone = (int)(iter + 1);
    }

    if (outIters) {
        *outIters = itersDone;
    }

    free(prevA);
}
