/* harness.c — differential driver for bfs_parent_distance (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

// Forward declarations (must match real signatures exactly)
void bfs_parent_distance_serial(
    int V,
    const int *rowPtr,
    const int *colInd,
    int sourcesCount,
    const int *sources,
    int *outDist,
    int *outParent,
    int distStride,
    int parentStride);

void bfs_parent_distance_omp(
    int V,
    const int *rowPtr,
    const int *colInd,
    int sourcesCount,
    const int *sources,
    int *outDist,
    int *outParent,
    int distStride,
    int parentStride);

static uint64_t splitmix64(uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

static uint32_t rng_u32(uint64_t *state) {
    *state = splitmix64(*state);
    return (uint32_t)(*state >> 32);
}

static double rng_uniform01(uint64_t *state) {
    // 53-bit precision
    uint64_t hi = (uint64_t)rng_u32(state);
    uint64_t lo = (uint64_t)rng_u32(state);
    uint64_t x = (hi << 32) ^ lo;
    return (x >> 11) * (1.0 / 9007199254740992.0);
}

// Generate deterministic graph in CSR form.
// This matches the spec at a high level (power-law sampling, self-loop rejection-ish,
// and 20 injected edges for reachability), but uses a scaled-down E to keep runtime reasonable.
static void generate_graph(int V, uint64_t seed, int *outE, int **outRowPtr, int **outColInd) {
    const double alpha = 2.6;
    const int maxOut = 1000;
    // Scale edge count to keep harness fast.
    const int E_target_full = 5000000;
    int E_target = (int)((int64_t)E_target_full * (int64_t)V / 310000);
    if (E_target < 800000) E_target = 800000;
    // Also cap to keep allocations reasonable for harness.
    if (E_target > 1200000) E_target = 1200000;

    int E = E_target;

    int sourcesInjected = 20;
    int *rowPtr = (int*)calloc((size_t)V + 1, sizeof(int));
    if (!rowPtr) { fprintf(stderr, "alloc rowPtr failed\n"); exit(1); }

    // First pass: sample out-degrees quotas and then edges (store colInd in growing buffer)
    // Since E is fixed, we'll stop adding edges once created reaches E.
    int *deg = (int*)calloc((size_t)V, sizeof(int));
    if (!deg) { fprintf(stderr, "alloc deg failed\n"); exit(1); }

    uint64_t state = seed;

    // Precompute truncated power-law normalization constant not strictly needed for proportional sampling.
    // We'll do rejection sampling in degree sampling as described.
    // For sampling neighbors v proportional to i^{-alpha} over [0..V-1].

    // For efficiency, we will use a discrete distribution proportional to k^{-alpha} by rejection:
    // draw candidate i uniformly and accept with prob proportional to (cand)^{-alpha} / M.
    // Choose M = 1^{-alpha} = 1.

    // Sample out-degree for each u.
    for (int u = 0; u < V; u++) {
        int d = 0;
        // rejection sampling until accepted; target at least 1.
        while (1) {
            // propose d uniformly in [1..maxOut]
            uint32_t x = rng_u32(&state);
            d = (int)(x % (uint32_t)maxOut) + 1;
            // accept with probability proportional to d^{-alpha}
            double u01 = rng_uniform01(&state);
            double acceptProb = 1.0 / pow(d, alpha); // d in [1..maxOut]
            if (acceptProb > 1.0) acceptProb = 1.0;
            if (u01 < acceptProb) break;
            // continue
        }
        deg[u] = d;
    }

    // Now create exactly E edges, honoring deg quotas.
    // Allocate colInd with exact E.
    int *colInd = (int*)malloc((size_t)E * sizeof(int));
    if (!colInd) { fprintf(stderr, "alloc colInd failed\n"); exit(1); }

    // Track per-source 