#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

void bfs_parent_distance_serial(
    int V,
    const int *rowPtr,
    const int *colInd,
    int sourcesCount,
    const int *sources,
    int *outDist,
    int *outParent,
    int distStride,
    int parentStride)
{
    if (V <= 0 || sourcesCount <= 0 || !rowPtr || !colInd || !sources || !outDist || !outParent) return;

    int *dist = (int *)malloc((size_t)V * sizeof(int));
    int *parent = (int *)malloc((size_t)V * sizeof(int));
    int *queue = (int *)malloc((size_t)V * sizeof(int));
    if (!dist || !parent || !queue) {
        free(dist);
        free(parent);
        free(queue);
        return;
    }

    for (int si = 0; si < sourcesCount; ++si) {
        int s = sources[si];
        if (s < 0 || s >= V) {
            for (int v = 0; v < V; ++v) {
                outDist[(size_t)si * (size_t)distStride + (size_t)v] = -1;
                outParent[(size_t)si * (size_t)parentStride + (size_t)v] = -1;
            }
            continue;
        }

        for (int v = 0; v < V; ++v) {
            dist[v] = -1;
            parent[v] = -1;
        }

        int qh = 0, qt = 0;
        dist[s] = 0;
        parent[s] = -1;
        queue[qt++] = s;

        while (qh < qt) {
            int u = queue[qh++];
            int du = dist[u];
            int start = rowPtr[u];
            int end = rowPtr[u + 1];
            for (int ei = start; ei < end; ++ei) {
                int v = colInd[ei];
                if (v < 0 || v >= V) continue;
                if (dist[v] == -1) {
                    dist[v] = du + 1;
                    parent[v] = u;
                    queue[qt++] = v;
                }
            }
        }

        for (int v = 0; v < V; ++v) {
            outDist[(size_t)si * (size_t)distStride + (size_t)v] = dist[v];
            outParent[(size_t)si * (size_t)parentStride + (size_t)v] = parent[v];
        }
    }

    free(dist);
    free(parent);
    free(queue);
}
