#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <omp.h>

void bfs_parent_distance_omp(
    int V,
    const int *rowPtr,
    const int *colInd,
    int sourcesCount,
    const int *sources,
    int *outDist,
    int *outParent,
    int distStride,
    int parentStride)
{
    if (V <= 0 || sourcesCount <= 0 || !rowPtr || !colInd || !sources || !outDist || !outParent) return;

    int *dist = (int *)malloc((size_t)V * sizeof(int));
    int *parent = (int *)malloc((size_t)V * sizeof(int));
    int *queue = (int *)malloc((size_t)V * sizeof(int));
    if (!dist || !parent || !queue) {
        free(dist);
        free(parent);
        free(queue);
        return;
    }

    for (int si = 0; si < sourcesCount; ++si) {
        int s = sources[si];
        int baseDist = si * distStride;
        int baseParent = si * parentStride;

        if (s < 0 || s >= V) {
            #pragma omp parallel for schedule(static)
            for (int v = 0; v < V; ++v) {
                outDist[(size_t)baseDist + (size_t)v] = -1;
                outParent[(size_t)baseParent + (size_t)v] = -1;
            }
            continue;
        }

        #pragma omp parallel for schedule(static)
        for (int v = 0; v < V; ++v) {
            dist[v] = -1;
            parent[v] = -1;
        }

        int qh = 0, qt = 0;
        dist[s] = 0;
        parent[s] = -1;
        queue[qt++] = s;

        while (qh < qt) {
            int levelEnd = qt;
            int currFrontierStart = qh;
            #pragma omp parallel
            {
                int *localQueue = (int *)malloc((size_t)(levelEnd - currFrontierStart) * (size_t)2 * sizeof(int));
                int localCount = 0;

                #pragma omp for schedule(static)
                for (int qi = currFrontierStart; qi < levelEnd; ++qi) {
                    int u = queue[qi];
                    int du = dist[u];
                    int start = rowPtr[u];
                    int end = rowPtr[u + 1];
                    for (int ei = start; ei < end; ++ei) {
                        int v = colInd[ei];
                        if (v < 0 || v >= V) continue;
                        if (dist[v] == -1) {
                            int expected = -1;
                            if (__sync_bool_compare_and_swap(&dist[v], expected, du + 1)) {
                                parent[v] = u;
                                localQueue[localCount++] = v;
                            }
                        }
                    }
                }

                #pragma omp critical
                {
                    if (localCount > 0) {
                        for (int i = 0; i < localCount; ++i) {
                            if (qt < V) queue[qt++] = localQueue[i];
                        }
                    }
                }

                free(localQueue);
            }

            qh = levelEnd;
        }

        #pragma omp parallel for schedule(static)
        for (int v = 0; v < V; ++v) {
            outDist[(size_t)baseDist + (size_t)v] = dist[v];
            outParent[(size_t)baseParent + (size_t)v] = parent[v];
        }
    }

    free(dist);
    free(parent);
    free(queue);
}
