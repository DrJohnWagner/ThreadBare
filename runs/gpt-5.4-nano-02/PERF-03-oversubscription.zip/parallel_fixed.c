#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

typedef struct {
    int fileId;
    int sensorId;
    int count;
    double sum;
    double sumsq;
} SensorSummaryRow;

static uint64_t lcg_next(uint64_t *state) {
    const uint64_t a = 6364136223846793005ULL;
    const uint64_t c = 1442695040888963407ULL;
    *state = (*state) * a + c;
    return *state;
}

static void decompress_xor(const uint8_t *compressed, uint8_t *decompressed, size_t L) {
    for (size_t j = 0; j < L; j++) {
        uint8_t key = (uint8_t)(((uint64_t)j * 1315423911ULL) & 0xFFULL);
        decompressed[j] = (uint8_t)(compressed[j] ^ key);
    }
}

static void decode_value_and_sensor(const uint8_t *rec8, int *sid_out, double *v_out) {
    uint32_t t = (uint32_t)rec8[0]
               | ((uint32_t)rec8[1] << 8)
               | ((uint32_t)rec8[2] << 16)
               | ((uint32_t)rec8[3] << 24);
    int sid = (int)((uint32_t)rec8[4]
               | ((uint32_t)rec8[5] << 8)
               | ((uint32_t)rec8[6] << 16)
               | ((uint32_t)rec8[7] << 24));

    double v = (double)t / 1000.0;
    *sid_out = sid;
    *v_out = v;
}

SensorSummaryRow sensor_log_ingest_pipeline_omp(int numFiles, int recordsPerFile, int numSensors) {
    SensorSummaryRow *rows = (SensorSummaryRow *)calloc((size_t)numFiles * (size_t)numSensors,
                                                         sizeof(SensorSummaryRow));
    if (!rows) {
        SensorSummaryRow empty = {0};
        return empty;
    }

    for (int f = 0; f < numFiles; f++) {
        for (int sid = 0; sid < numSensors; sid++) {
            size_t idx = (size_t)f * (size_t)numSensors + (size_t)sid;
            rows[idx].fileId = f;
            rows[idx].sensorId = sid;
            rows[idx].count = 0;
            rows[idx].sum = 0.0;
            rows[idx].sumsq = 0.0;
        }
    }

    const int bytesPerRecord = 8;
    const size_t L = (size_t)recordsPerFile * (size_t)bytesPerRecord;

    uint64_t rng = 123456789ULL;

#pragma omp parallel
    {
        uint8_t *decompressed = (uint8_t *)malloc(L);
        uint8_t *compressed = (uint8_t *)malloc(L);
        if (!decompressed || !compressed) {
            free(decompressed);
            free(compressed);
        } else {
#pragma omp for schedule(static)
            for (int f = 0; f < numFiles; f++) {
                for (int i = 0; i < recordsPerFile; i++) {
                    uint64_t x;
                    uint32_t t_u;
                    int sid;
                    double v;

#pragma omp critical
                    {
                        x = lcg_next(&rng);
                    }

                    sid = (int)(x % (uint64_t)numSensors);
                    v = (double)(((x >> 16) % 1000000ULL)) / 1000.0;
                    t_u = (uint32_t)llround(v * 1000.0);

                    size_t off = (size_t)i * (size_t)bytesPerRecord;

                    compressed[off + 0] = (uint8_t)(t_u & 0xFFu);
                    compressed[off + 1] = (uint8_t)((t_u >> 8) & 0xFFu);
                    compressed[off + 2] = (uint8_t)((t_u >> 16) & 0xFFu);
                    compressed[off + 3] = (uint8_t)((t_u >> 24) & 0xFFu);

                    uint32_t usid = (uint32_t)sid;
                    compressed[off + 4] = (uint8_t)(usid & 0xFFu);
                    compressed[off + 5] = (uint8_t)((usid >> 8) & 0xFFu);
                    compressed[off + 6] = (uint8_t)((usid >> 16) & 0xFFu);
                    compressed[off + 7] = (uint8_t)((usid >> 24) & 0xFFu);
                }

                decompress_xor(compressed, decompressed, L);

                for (int i = 0; i < recordsPerFile; i++) {
                    size_t off = (size_t)i * (size_t)bytesPerRecord;
                    int sid;
                    double v;
                    decode_value_and_sensor(&decompressed[off], &sid, &v);

                    size_t idx = (size_t)f * (size_t)numSensors + (size_t)sid;
                    rows[idx].count += 1;
                    rows[idx].sum += v;
                    rows[idx].sumsq += v * v;
                }
            }
        }
        free(decompressed);
        free(compressed);
    }

    SensorSummaryRow result = rows[0];
    free(rows);
    return result;
}
