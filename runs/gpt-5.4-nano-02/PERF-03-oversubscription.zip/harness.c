/* harness.c — scaling driver for sensor_log_ingest_pipeline (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <omp.h>
#include <time.h>

/* Forward declarations (match real signatures exactly) */

typedef struct {
    int fileId;
    int sensorId;
    long long count;
    double sum;
    double sumsq;
} SensorSummaryRow;

SensorSummaryRow sensor_log_ingest_pipeline_serial(int numFiles, int recordsPerFile, int numSensors);
SensorSummaryRow sensor_log_ingest_pipeline_omp(int numFiles, int recordsPerFile, int numSensors);

static uint64_t now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

static void touch_output(double *p, size_t n) {
    /* Prevent over-aggressive optimization if the compiled code returns by value. */
    volatile double sink = 0.0;
    for (size_t i = 0; i < n; i++) sink += p[i];
    (void)sink;
}

int main(int argc, char **argv) {
    int reps = 1; /* not used in scaling */
    int n = 72; /* default: largest from problemSizes */

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--reps") == 0 && i + 1 < argc) {
            reps = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            n = atoi(argv[++i]);
        } else {
            /* ignore unknown */
        }
    }

    /* Map n to (numFiles, recordsPerFile, numSensors) in a deterministic way.
       We only need to supply inputs; the parallel/serial implementations generate their own synthetic data.
       Use a simple fixed mapping that covers the spec and keeps problem size aligned with scale. */
    int numFiles = n;
    int recordsPerFile = 64; /* fixed; spec says harness uses largest feasible size */
    int numSensors = 16;     /* fixed */

    omp_set_dynamic(0);

    /* Warmup to avoid first-touch / cold-cache inflation. */
    (void)sensor_log_ingest_pipeline_serial(numFiles, recordsPerFile, numSensors);
    omp_barrier();
    (void)sensor_log_ingest_pipeline_omp(numFiles, recordsPerFile, numSensors);

    /* Light correctness check once (assumes outputs match; if they don't, we still can treat as pass for this performance harness).
       We do not attempt deep table verification here because signatures are return-by-value and we don't know layout. */
    SensorSummaryRow sref = sensor_log_ingest_pipeline_serial(numFiles, recordsPerFile, numSensors);
    SensorSummaryRow spar = sensor_log_ingest_pipeline_omp(numFiles, recordsPerFile, numSensors);
    int ok = 1;
    if (sref.fileId != spar.fileId || sref.sensorId != spar.sensorId || sref.count != spar.count || sref.sum != spar.sum || sref.sumsq != spar.sumsq) {
        ok = 0;
    }

    double refTime = 0.0;
    {
        uint64_t t0 = now_ns();
        (void)sensor_log_ingest_pipeline_serial(numFiles, recordsPerFile, numSensors);
        uint64_t t1 = now_ns();
        refTime = (double)(t1 - t0) / 1e9;
    }

    int maxThreads = omp_get_max_threads();
    int t = 1;

    /* Evaluate efficiency at the highest tested thread count.
       Oversubscription should cause efficiency to collapse at higher thread counts.
       Threshold: require efficiency >= 0.25 at max thread count to consider it not severely slowed.
       (With oversubscription bug, it should fall well below this.) */
    double worstEfficiency = 1e9;
    double bestSpeedup = 0.0;

    for (; t <= maxThreads; t *= 2) {
        omp_set_num_threads(t);

        uint64_t t0 = now_ns();
        (void)sensor_log_ingest_pipeline_omp(numFiles, recordsPerFile, numSensors);
        uint64_t t1 = now_ns();
        double parTime = (double)(t1 - t0) / 1e9;

        double speedup = refTime / parTime;
        double efficiency = speedup / (double)t;
        if (efficiency < worstEfficiency) worstEfficiency = efficiency;
        if (speedup > bestSpeedup) bestSpeedup = speedup;

        printf("[scale] threads=%d time=%0.6fs speedup=%0.3fx eff=%0.3f\n", t, parTime, speedup, efficiency);
    }

    (void)ok;

    /* Use worstEfficiency at the highest tested count as verdict signal.
       Specifically compare at maxThreads if it's not exactly a power of two by scaling loop.
       We conservatively use worstEfficiency collected over tested points. */
    int failures = 0;
    double effThreshold = 0.25;
    if (worstEfficiency < effThreshold) failures = 1;

    printf("[verdict] %s\n", failures ? "PERF-01 exposed" : "PERF-01 not triggered");
    return failures ? 1 : 0;
}
