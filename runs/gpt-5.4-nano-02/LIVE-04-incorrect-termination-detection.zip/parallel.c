#include <stdint.h>
#include <stdlib.h>
#include <omp.h>

void bfs_parent_hops_omp(
    int N,
    int M,
    const int *row_ptr,
    const int *col_idx,
    const int *sources,
    int Ssrc,
    int *out_hops,
    int *out_parent
) {
    (void)M;

    for (int si = 0; si < Ssrc; si++) {
        int s = sources[si];

        int *hops = out_hops + (size_t)si * (size_t)N;
        int *parent = out_parent + (size_t)si * (size_t)N;

        for (int v = 0; v < N; v++) {
            hops[v] = -1;
            parent[v] = -1;
        }

        hops[s] = 0;
        parent[s] = -1;

        int *Qcur = (int *)malloc((size_t)N * sizeof(int));
        int *Qnext = (int *)malloc((size_t)N * sizeof(int));

        if (!Qcur || !Qnext) {
            free(Qcur);
            free(Qnext);
            return;
        }

        int qcur_n = 1;
        Qcur[0] = s;

        int level = 0;
        while (qcur_n > 0) {
            int qnext_n = 0;

            size_t cap = (size_t)qcur_n * 4u + 1024u;
            int *candV = (int *)malloc(cap * sizeof(int));
            int *candP = (int *)malloc(cap * sizeof(int));
            uint64_t *candKey = (uint64_t *)malloc(cap * sizeof(uint64_t));

            if (!candV || !candP || !candKey) {
                free(candV);
                free(candP);
                free(candKey);
                break;
            }

            size_t total_candidates = 0;
            #pragma omp parallel for reduction(+:total_candidates) schedule(static)
            for (int qi = 0; qi < qcur_n; qi++) {
                int u = Qcur[qi];
                int e0 = row_ptr[u];
                int e1 = row_ptr[u + 1];
                size_t local = 0;
                for (int e = e0; e < e1; e++) {
                    int v = col_idx[e];
                    if (hops[v] == -1) local++;
                }
                total_candidates += local;
            }

            free(candV);
            free(candP);
            free(candKey);

            candV = (int *)malloc(total_candidates * sizeof(int));
            candP = (int *)malloc(total_candidates * sizeof(int));
            candKey = (uint64_t *)malloc(total_candidates * sizeof(uint64_t));
            if (!candV || !candP || !candKey) {
                free(candV);
                free(candP);
                free(candKey);
                break;
            }

            size_t *counts = (size_t *)malloc((size_t)qcur_n * sizeof(size_t));
            size_t *offsets = (size_t *)malloc((size_t)qcur_n * sizeof(size_t));
            if (!counts || !offsets) {
                free(counts);
                free(offsets);
                free(candV);
                free(candP);
                free(candKey);
                break;
            }

            #pragma omp parallel for schedule(static)
            for (int qi = 0; qi < qcur_n; qi++) {
                int u = Qcur[qi];
                int e0 = row_ptr[u];
                int e1 = row_ptr[u + 1];
                size_t local = 0;
                for (int e = e0; e < e1; e++) {
                    int v = col_idx[e];
                    if (hops[v] == -1) local++;
                }
                counts[qi] = local;
            }

            size_t run = 0;
            for (int qi = 0; qi < qcur_n; qi++) {
                offsets[qi] = run;
                run += counts[qi];
            }
            size_t cand_n = run;

            #pragma omp parallel for schedule(static)
            for (int qi = 0; qi < qcur_n; qi++) {
                int u = Qcur[qi];
                int e0 = row_ptr[u];
                int e1 = row_ptr[u + 1];
                size_t pos = offsets[qi];
                for (int e = e0; e < e1; e++) {
                    int v = col_idx[e];
                    if (hops[v] == -1) {
                        candV[pos] = v;
                        candP[pos] = u;
                        candKey[pos] = ((uint64_t)(uint32_t)qi << 32) | (uint32_t)e;
                        pos++;
                    }
                }
            }

            if (cand_n > 0) {
                int *tmpV = (int *)malloc(cand_n * sizeof(int));
                int *tmpP = (int *)malloc(cand_n * sizeof(int));
                uint64_t *tmpK = (uint64_t *)malloc(cand_n * sizeof(uint64_t));

                const size_t RAD = 1u << 16;
                size_t *count = (size_t *)malloc(RAD * sizeof(size_t));
                if (tmpV && tmpP && tmpK && count) {
                    for (int pass = 0; pass < 4; pass++) {
                        for (size_t i = 0; i < RAD; i++) count[i] = 0;
                        int shift = pass * 16;
                        for (size_t i = 0; i < cand_n; i++) {
                            uint64_t b = (candKey[i] >> (uint64_t)shift) & 0xFFFFu;
                            count[b]++;
                        }
                        size_t sum = 0;
                        for (size_t i = 0; i < RAD; i++) {
                            size_t c = count[i];
                            count[i] = sum;
                            sum += c;
                        }
                        for (size_t i = 0; i < cand_n; i++) {
                            uint64_t b = (candKey[i] >> (uint64_t)shift) & 0xFFFFu;
                            size_t pos = count[b]++;
                            tmpK[pos] = candKey[i];
                            tmpV[pos] = candV[i];
                            tmpP[pos] = candP[i];
                        }
                        for (size_t i = 0; i < cand_n; i++) {
                            candKey[i] = tmpK[i];
                            candV[i] = tmpV[i];
                            candP[i] = tmpP[i];
                        }
                    }

                    for (int pass = 0; pass < 2; pass++) {
                        for (size_t i = 0; i < RAD; i++) count[i] = 0;
                        uint32_t shift = (uint32_t)(pass * 16);
                        for (size_t i = 0; i < cand_n; i++) {
                            uint32_t b = ((uint32_t)candV[i] >> shift) & 0xFFFFu;
                            count[b]++;
                        }
                        size_t sum = 0;
                        for (size_t i = 0; i < RAD; i++) {
                            size_t c = count[i];
                            count[i] = sum;
                            sum += c;
                        }
                        for (size_t i = 0; i < cand_n; i++) {
                            uint32_t b = ((uint32_t)candV[i] >> shift) & 0xFFFFu;
                            size_t pos = count[b]++;
                            tmpK[pos] = candKey[i];
                            tmpV[pos] = candV[i];
                            tmpP[pos] = candP[i];
                        }
                        for (size_t i = 0; i < cand_n; i++) {
                            candKey[i] = tmpK[i];
                            candV[i] = tmpV[i];
                            candP[i] = tmpP[i];
                        }
                    }

                    int prev_v = -1;
                    for (size_t i = 0; i < cand_n; i++) {
                        int v = candV[i];
                        if (v != prev_v) {
                            prev_v = v;
                            if (hops[v] == -1) {
                                hops[v] = level + 1;
                                parent[v] = candP[i];
                                Qnext[qnext_n++] = v;
                            }
                        }
                    }
                }

                free(tmpV);
                free(tmpP);
                free(tmpK);
                free(count);
            }

            free(counts);
            free(offsets);
            free(candV);
            free(candP);
            free(candKey);

            if (qnext_n > 0) {
                qcur_n = qnext_n;
                for (int i = 0; i < qcur_n; i++) Qcur[i] = Qnext[i];
            } else {
                qcur_n = 0;
            }

            if (qcur_n > 0) qcur_n -= 1;
            level++;
        }

        free(Qcur);
        free(Qnext);
    }
}
