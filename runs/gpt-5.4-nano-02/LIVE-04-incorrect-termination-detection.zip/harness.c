/* harness.c — timeout driver for bfs_parent_hops (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

// Forward declarations matching the real signatures.
void bfs_parent_hops_serial(int N, int M,
                             const int *row_ptr, const int *col_idx,
                             const int *sources, int Ssrc,
                             int *out_hops, int *out_parent);

void bfs_parent_hops_omp(int N, int M,
                         const int *row_ptr, const int *col_idx,
                         const int *sources, int Ssrc,
                         int *out_hops, int *out_parent);

static void die_usage(const char *prog) {
    fprintf(stderr, "Usage: %s [--n N] [--reps R] [--timeout-ms T]\n", prog);
}

static unsigned long long splitmix64(unsigned long long *x) {
    unsigned long long z = (*x += 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}

static double rng_uniform01(unsigned long long *state) {
    // Convert to [0,1)
    const unsigned long long v = splitmix64(state);
    // 53-bit precision
    return (double)(v >> 11) * (1.0 / 9007199254740992.0);
}

static void generate_graph(int N, int M,
                            int **row_ptr_out, int **col_idx_out) {
    const unsigned long long seed = 123456789ULL;
    unsigned long long rng = seed;
    const double alpha = 2.5;
    const double xm = 1.0;
    const double k = (double)M / (double)N;
    const int dmax = (int)(4.0 * k);
    int dmax_clamped = dmax;
    if (dmax_clamped < 1) dmax_clamped = 1;

    int *d = (int*)malloc(sizeof(int) * (size_t)N);
    int *d_floor = (int*)malloc(sizeof(int) * (size_t)N);
    double *frac = (double*)malloc(sizeof(double) * (size_t)N);
    if (!d || !d_floor || !frac) {
        fprintf(stderr, "malloc failed\n");
        exit(1);
    }

    double *raw = (double*)malloc(sizeof(double) * (size_t)N);
    if (!raw) {
        fprintf(stderr, "malloc failed\n");
        exit(1);
    }

    // Generate raw power-law degrees, clamp.
    for (int v = 0; v < N; v++) {
        double U = rng_uniform01(&rng);
        // x = xm * (1 - U)^(-1/alpha)
        double one_minus = 1.0 - U;
        if (one_minus <= 0.0) one_minus = 1e-16;
        double x = xm * pow(one_minus, -1.0 / alpha);
        long long df = (long long)(x);
        if (df < 0) df = 0;
        if (df > (long long)dmax_clamped) df = dmax_clamped;
        d[v] = (int)df;
        raw[v] = (double)d[v];
    }

    // Scale degrees to exact sum M using fractional parts of d[v]*(M/S).
    double S = 0.0;
    for (int v = 0; v < N; v++) S += raw[v];
    if (S <= 0.0) {
        // Degenerate fallback: make a simple uniform distribution.
        for (int v = 0; v < N; v++) raw[v] = 1.0;
        S = (double)N;
    }

    long long sum_floor = 0;
    for (int v = 0; v < N; v++) {
        double scaled = raw[v] * ((double)M / S);
        long long fl = (long long)scaled;
        if (fl < 0) fl = 0;
        if (fl > LLONG_MAX / 2) fl = LLONG_MAX / 2;
        d_floor[v] = (int)fl;
        frac[v] = scaled - (double)fl;
        sum_floor += fl;
    }

    long long r = (long long)M - sum_floor;
    // Distribute remaining edges by incrementing vertices with largest fractional parts.
    // We avoid O(N log N) by repeated scan; N is large though, but r should be small.
    // Still, we implement a one-pass sort of indices by fractional part.
    int *idx = (int*)malloc(sizeof(int) * (size_t)N);
    if (!idx) {
        fprintf(stderr, "malloc failed\n");
        exit(1);
    }
    for (int v = 0; v < N; v++) idx[v] = v;

    // Simple selection sort for small N would be too slow; use qsort with comparator on frac.
    // Store comparator via global pointer.
    struct Ctx { double *f; };
    (void)r;
    static double *gfrac = NULL;
    gfrac = frac;
    int cmp(const void *a, const void *b) {
        int ia = *(const int*)a;
        int ib = *(const int*)b;
        double fa = gfrac[ia];
        double fb = gfrac[ib];
        if (fa < fb) return 1;
        if (fa > fb) return -1;
        return ia - ib;
    }
    qsort(idx, (size_t)N, sizeof(int), cmp);

    for (long long t = 0; t < r; t++) {
        int v = idx[(size_t)t];
        d_floor[v] += 1;
    }

    // Build CSR.
    int *row_ptr = (int*)malloc(sizeof(int) * (size_t)(N + 1));
    int *col_idx = (int*)malloc(sizeof(int) * (size_t)M);
    if (!row_ptr || !col_idx) {
        fprintf(stderr, "malloc failed\n");
        exit(1);
    }

    row_ptr[0] = 0;
    for (int v = 0; v < N; v++) row_ptr[v + 1] = row_ptr[v] + d_floor[v];

    // In case of any rounding oddities, enforce exact M.
    long long total = (long long)row_ptr[N];
    if (total != (long long)M) {
        // Adjust last vertex to make exact sum.
        long long diff = (long long)M - total;
        row_ptr[N] += (int)diff;
        d_floor[N - 1] += (int)diff;
    }

    for (int v = 0; v < N; v++) {
        int start = row_ptr[v];
        int deg = d_floor[v];
        for (int e = 0; e < deg; e++) {
            double U = rng_uniform01(&rng);
            int u = (int)(U * (double)N);
            if (u >= N) u = N - 1;
            col_idx[start + e] = u;
        }
    }

    free(d); free(d_floor); free(frac); free(raw);
    free(idx);

    *row_ptr_out = row_ptr;
    *col_idx_out = col_idx;
}

static volatile sig_atomic_t g_timed_out = 0;
static void alarm_handler(int sig) {
    (void)sig;
    g_timed_out = 1;
}

int main(int argc, char **argv) {
    int N = 520000;
    int reps = 1;
    int timeout_ms = 2000; // wall-clock watchdog for liveness

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            N = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--reps") == 0 && i + 1 < argc) {
            reps = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--timeout-ms") == 0 && i + 1 < argc) {
            timeout_ms = atoi(argv[++i]);
        } else {
            die_usage(argv[0]);
            return 0;
        }
    }

    const int M = 5000000; // per spec
    const int Ssrc = 20;

    int *row_ptr = NULL;
    int *col_idx = NULL;
    generate_graph(N, M, &row_ptr, &col_idx);

    int *sources = (int*)malloc(sizeof(int) * (size_t)Ssrc);
    if (!sources) { fprintf(stderr, "malloc sources failed\n"); exit(1);} 
    for (int i = 0; i < Ssrc; i++) {
        sources[i] = (i * 137 + 17) % N;
    }

    size_t out_sz = (size_t)Ssrc * (size_t)N;
    int *out_hops_serial = (int*)malloc(sizeof(int) * out_sz);
    int *out_parent_serial = (int*)malloc(sizeof(int) * out_sz);
    int *out_hops_par = (int*)malloc(sizeof(int) * out_sz);
    int *out_parent_par = (int*)malloc(sizeof(int) * out_sz);
    if (!out_hops_serial || !out_parent_serial || !out_hops_par || !out_parent_par) {
        fprintf(stderr, "malloc outputs failed\n");
        return 1;
    }

    // Compute ground truth once (also warms up CPU/allocators).
    memset(out_hops_serial, 0, sizeof(int) * out_sz);
    memset(out_parent_serial, 0, sizeof(int) * out_sz);
    bfs_parent_hops_serial(N, M, row_ptr, col_idx, sources, Ssrc, out_hops_serial, out_parent_serial);

    int failures = 0;

    // Liveness check: the planted failure is incorrect termination detection (missing work),
    // which may not hang; however liveness category requires a timeout harness.
    // We still guard with a hard wall-clock timeout; if it finishes, we fall back
    // to a quick correctness check to avoid false negatives.

    for (int rep = 0; rep < reps; rep++) {
        memset(out_hops_par, 0, sizeof(int) * out_sz);
        memset(out_parent_par, 0, sizeof(int) * out_sz);

        g_timed_out = 0;
        struct sigaction sa;
        memset(&sa, 0, sizeof(sa));
        sa.sa_handler = alarm_handler;
        sigemptyset(&sa.sa_mask);
        sigaction(SIGALRM, &sa, NULL);

        unsigned int sec = (unsigned int)((timeout_ms + 999) / 1000);
        if (sec < 1) sec = 1;
        alarm(sec);

        bfs_parent_hops_omp(N, M, row_ptr, col_idx, sources, Ssrc, out_hops_par, out_parent_par);

        alarm(0);

        if (g_timed_out) {
            printf("[check] timeout detected on rep %d\n", rep);
            failures = 1;
            break;
        }

        // Quick differential check (light correctness) to catch the planted incorrect termination.
        // Compare a subset of outputs deterministically first; if mismatch found, fail.
        // This is safe even if the computation is fast; we won't fully scan all outputs.
        size_t stride = (out_sz > 1000000) ? (out_sz / 1000000) : 1;
        for (size_t idx = 0; idx < out_sz; idx += stride) {
            if (out_hops_par[idx] != out_hops_serial[idx] || out_parent_par[idx] != out_parent_serial[idx]) {
                printf("[check] mismatch detected at flat index %zu (rep %d)\n", idx, rep);
                failures = 1;
                break;
            }
        }
        if (failures) break;
    }

    free(row_ptr);
    free(col_idx);
    free(sources);
    free(out_hops_serial);
    free(out_parent_serial);
    free(out_hops_par);
    free(out_parent_par);

    printf("[verdict] %s\n", failures ? "LIVE-01 exposed" : "LIVE-01 not triggered");
    return failures ? 1 : 0;
}
