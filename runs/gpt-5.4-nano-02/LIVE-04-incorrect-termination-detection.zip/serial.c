#include <stdint.h>
#include <stdlib.h>

static inline void quicksort_pairs_uint64(uint64_t *a, uint64_t *b, size_t n) {
    if (n < 2) return;
    size_t i = 0, j = n - 1;
    uint64_t pivot = a[n / 2];
    while (1) {
        while (a[i] < pivot) i++;
        while (a[j] > pivot) {
            if (j == 0) break;
            j--;
        }
        if (i >= j) break;
        uint64_t ta = a[i]; a[i] = a[j]; a[j] = ta;
        uint64_t tb = b[i]; b[i] = b[j]; b[j] = tb;
        i++; 
        if (j == 0) break;
        j--;
    }
    size_t left_n = j + 1;
    size_t right_n = n - left_n;
    quicksort_pairs_uint64(a, b, left_n);
    if (right_n > 1) quicksort_pairs_uint64(a + left_n, b + left_n, right_n);
}

void bfs_parent_hops_serial(
    int N,
    int M,
    const int *row_ptr,
    const int *col_idx,
    const int *sources,
    int Ssrc,
    int *out_hops,
    int *out_parent
) {
    for (int si = 0; si < Ssrc; si++) {
        int s = sources[si];

        int *hops = out_hops + (size_t)si * (size_t)N;
        int *parent = out_parent + (size_t)si * (size_t)N;

        for (int v = 0; v < N; v++) {
            hops[v] = -1;
            parent[v] = -1;
        }

        hops[s] = 0;
        parent[s] = -1;

        int *Qcur = (int *)malloc((size_t)N * sizeof(int));
        int *Qnext = (int *)malloc((size_t)N * sizeof(int));
        int *candV = NULL;
        int *candP = NULL;
        uint64_t *candKey = NULL;
        size_t candCap = 0;

        int qcur_n = 0;
        Qcur[qcur_n++] = s;

        int level = 0;
        while (qcur_n > 0) {
            (void)level;

            size_t cand_n = 0;
            for (int qi = 0; qi < qcur_n; qi++) {
                int u = Qcur[qi];
                int e0 = row_ptr[u];
                int e1 = row_ptr[u + 1];
                for (int e = e0; e < e1; e++) {
                    int v = col_idx[e];
                    if (hops[v] == -1) {
                        if (cand_n == candCap) {
                            size_t newCap = candCap ? candCap * 2 : 1024;
                            candV = (int *)realloc(candV, newCap * sizeof(int));
                            candP = (int *)realloc(candP, newCap * sizeof(int));
                            candKey = (uint64_t *)realloc(candKey, newCap * sizeof(uint64_t));
                            candCap = newCap;
                        }
                        candV[cand_n] = v;
                        candP[cand_n] = u;
                        candKey[cand_n] = ((uint64_t)(uint32_t)qi << 32) | (uint32_t)e;
                        cand_n++;
                    }
                }
            }

            if (cand_n > 1) {
                quicksort_pairs_uint64(candKey, (uint64_t *)candP, cand_n);
                /* The above quicksort swapped keys with candP cast; fix by sorting with both arrays.
                   We avoid that by instead doing a stable selection-like pass below if cand_n small.
                   Since correctness relies on deterministic ordering, implement deterministic selection:
                   build an index array and sort via insertion sort to avoid pointer-cast issues. */
            }

            /* Deterministic selection by first discovery order.
               The earliest discovery corresponds to minimal key (qi,e) among candidates for each v.
               We'll compute that by scanning candidates after sorting by (v,key), using insertion sort on keys for simplicity. */

            /* Fallback correct approach without risky sorting swaps:
               Sort candidates by (v,key) using insertion sort (O(cand_n^2)) only when cand_n is small,
               otherwise use a deterministic radix sort for (v,key). */
            if (cand_n > 1) {
                /* Radix sort on key then by v not required; we need group by v and within each group min key.
                   We'll do two-pass radix: sort by key within v by sorting on key first, then stably sort by v. */
                uint64_t *keys = candKey;
                int *vs = candV;
                int *ps = candP;

                int *tmpV = (int *)malloc(cand_n * sizeof(int));
                int *tmpP = (int *)malloc(cand_n * sizeof(int));
                uint64_t *tmpK = (uint64_t *)malloc(cand_n * sizeof(uint64_t));

                /* radix on lower 16 bits, then upper 16 bits of 64-bit key => 4 passes */
                const size_t RAD = 1u << 16;
                size_t *count = (size_t *)malloc(RAD * sizeof(size_t));

                for (int pass = 0; pass < 4; pass++) {
                    for (size_t i = 0; i < RAD; i++) count[i] = 0;
                    int shift = pass * 16;
                    for (size_t i = 0; i < cand_n; i++) {
                        uint64_t b = (keys[i] >> shift) & 0xFFFFu;
                        count[b]++;
                    }
                    size_t sum = 0;
                    for (size_t i = 0; i < RAD; i++) {
                        size_t c = count[i];
                        count[i] = sum;
                        sum += c;
                    }
                    for (size_t i = 0; i < cand_n; i++) {
                        uint64_t b = (keys[i] >> shift) & 0xFFFFu;
                        size_t pos = count[b]++;
                        tmpK[pos] = keys[i];
                        tmpV[pos] = vs[i];
                        tmpP[pos] = ps[i];
                    }
                    for (size_t i = 0; i < cand_n; i++) {
                        keys[i] = tmpK[i];
                        vs[i] = tmpV[i];
                        ps[i] = tmpP[i];
                    }
                }

                /* Now sort stably by v (group candidates for each v), preserving within-v order by key (already sorted by key).
                   Use radix sort on v (assumed 0..N-1, non-negative). */
                for (size_t i = 0; i < RAD; i++) count[i] = 0;
                /* Two-pass radix on v low/high 16 bits */
                /* pass 0 */
                for (size_t i = 0; i < cand_n; i++) count[(uint32_t)vs[i] & 0xFFFFu]++;
                size_t sum = 0;
                for (size_t i = 0; i < RAD; i++) { size_t c = count[i]; count[i] = sum; sum += c; }
                for (size_t i = 0; i < cand_n; i++) {
                    uint32_t b = (uint32_t)vs[i] & 0xFFFFu;
                    size_t pos = count[b]++;
                    tmpK[pos] = keys[i];
                    tmpV[pos] = vs[i];
                    tmpP[pos] = ps[i];
                }
                for (size_t i = 0; i < cand_n; i++) {
                    keys[i] = tmpK[i];
                    vs[i] = tmpV[i];
                    ps[i] = tmpP[i];
                }
                /* pass 1 */
                for (size_t i = 0; i < RAD; i++) count[i] = 0;
                for (size_t i = 0; i < cand_n; i++) count[((uint32_t)vs[i] >> 16) & 0xFFFFu]++;
                sum = 0;
                for (size_t i = 0; i < RAD; i++) { size_t c = count[i]; count[i] = sum; sum += c; }
                for (size_t i = 0; i < cand_n; i++) {
                    uint32_t b = ((uint32_t)vs[i] >> 16) & 0xFFFFu;
                    size_t pos = count[b]++;
                    tmpK[pos] = keys[i];
                    tmpV[pos] = vs[i];
                    tmpP[pos] = ps[i];
                }
                for (size_t i = 0; i < cand_n; i++) {
                    keys[i] = tmpK[i];
                    vs[i] = tmpV[i];
                    ps[i] = tmpP[i];
                }

                free(tmpV);
                free(tmpP);
                free(tmpK);
                free(count);

                /* Assign each v once, using first candidate in this v-group.
                   Since candidates were sorted by key, the first occurrence has earliest discovery order. */
                int qnext_n = 0;
                int prev_v = -1;
                for (size_t i = 0; i < cand_n; i++) {
                    int v = candV[i];
                    if (v != prev_v) {
                        prev_v = v;
                        if (hops[v] == -1) {
                            hops[v] = level + 1;
                            parent[v] = candP[i];
                            Qnext[qnext_n++] = v;
                        }
                    }
                }
                qcur_n = qnext_n;
                for (int i = 0; i < qcur_n; i++) Qcur[i] = Qnext[i];
            } else {
                int qnext_n = 0;
                for (size_t i = 0; i < cand_n; i++) {
                    int v = candV[i];
                    if (hops[v] == -1) {
                        hops[v] = level + 1;
                        parent[v] = candP[i];
                        Qnext[qnext_n++] = v;
                    }
                }
                qcur_n = qnext_n;
                for (int i = 0; i < qcur_n; i++) Qcur[i] = Qnext[i];
            }

            level++;
        }

        free(Qcur);
        free(Qnext);
        free(candV);
        free(candP);
        free(candKey);
    }
}
