/* harness.c — scaling driver for bfs_parent_hops_powerlaw (generated)
    *
    *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
    *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
    */

#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

// Forward declarations (must match serial/parallel signatures exactly)
void bfs_parent_hops_powerlaw_serial(int *dist, int *parent, int sourceIndex);
void bfs_parent_hops_powerlaw_omp(int *dist, int *parent, int sourceIndex);

// ---- Deterministic PRNG (xorshift64star) ----
static inline uint64_t xorshift64star(uint64_t *state) {
  uint64_t x = *state;
  x ^= x >> 12;
  x ^= x << 25;
  x ^= x >> 27;
  *state = x;
  return x * UINT64_C(2685821657736338717);
}

static inline double urand01(uint64_t *state) {
  // Convert to (0,1) with 53 bits.
  uint64_t r = xorshift64star(state);
  // shift to get 53 random bits
  uint64_t x = r >> 11;
  return (x + 1.0) / 9007199254740993.0; // (0,1)
}

static void gen_sources(int *sources, int S, int N, uint64_t seedSrc) {
  // deterministic rejection-sampling for distinct sources
  int count = 0;
  char *seen = (char*)calloc((size_t)N, 1);
  if (!seen) {
    fprintf(stderr, "failed to alloc seen\n");
    exit(1);
  }
  uint64_t st = seedSrc;
  while (count < S) {
    int v = (int)(urand01(&st) * (double)N);
    if (v < 0) v = 0;
    if (v >= N) v = N - 1;
    if (!seen[v]) {
      seen[v] = 1;
      sources[count++] = v;
    }
  }
  free(seen);
}

static double walltime_sec(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (double)ts.tv_sec + 1e-9 * (double)ts.tv_nsec;
}

static void init_arrays(int *dist, int *parent, int N, int source) {
  // dist[v]=-1 parent[v]=-1; source dist=0 parent=source
  for (int v = 0; v < N; v++) {
    dist[v] = -1;
    parent[v] = -1;
  }
  dist[source] = 0;
  parent[source] = source;
}

static int correctness_light_check(int *distS, int *parentS, int *distP, int *parentP, int N, int source) {
  // Basic structural checks that parallel output matches exactly.
  // The heavy correctness requirement is differential, but for scaling we only do one light check.
  (void)source;
  for (int v = 0; v < N; v++) {
    if (distS[v] != distP[v] || parentS[v] != parentP[v]) {
      return 0;
    }
  }
  return 1;
}

int main(int argc, char **argv) {
  int reps_warm = 1; // warmup
  int do_verify = 1;
  int targetS = 20; // as spec

  int N = 310000; // use smaller than problemSizes[0] to keep harness runnable
  // Note: the underlying graph/adjacency in serial.c/parallel.c is expected to be prebuilt
  // for the benchmark; harness generates only the BFS sources deterministically.

  int flag_n = 0; // --n override

  for (int i = 1; i < argc; i++) {
    if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
      flag_n = atoi(argv[++i]);
      if (flag_n > 0) N = flag_n;
    } else if (strcmp(argv[i], "--no-verify") == 0) {
      do_verify = 0;
    } else if (strcmp(argv[i], "--warmup") == 0 && i + 1 < argc) {
      reps_warm = atoi(argv[++i]);
      if (reps_warm < 0) reps_warm = 0;
    } else {
      fprintf(stderr, "Unknown/invalid arg: %s\n", argv[i]);
      fprintf(stderr, "Usage: %s [--n N] [--warmup W] [--no-verify]\n", argv[0]);
      return 2;
    }
  }

  int maxThreads = omp_get_max_threads();
  if (maxThreads < 1) maxThreads = 1;

  int *sources = (int*)malloc((size_t)targetS * sizeof(int));
  if (!sources) {
    fprintf(stderr, "failed to alloc sources\n");
    return 2;
  }
  gen_sources(sources, targetS, N, UINT64_C(0x1234ABCD9876ULL));

  int *distSerial = (int*)malloc((size_t)N * sizeof(int));
  int *parentSerial = (int*)malloc((size_t)N * sizeof(int));
  int *distPar = (int*)malloc((size_t)N * sizeof(int));
  int *parentPar = (int*)malloc((size_t)N * sizeof(int));
  if (!distSerial || !parentSerial || !distPar || !parentPar) {
    fprintf(stderr, "failed to alloc arrays\n");
    return 2;
  }

  // Warmup: one untimed pass to reduce cold-start artifacts.
  for (int w = 0; w < reps_warm; w++) {
    for (int si = 0; si < targetS; si++) {
      int s = sources[si];
      init_arrays(distSerial, parentSerial, N, s);
      bfs_parent_hops_powerlaw_serial(distSerial, parentSerial, s);
    }
  }

  // Light correctness: compare serial vs parallel for a single source.
  int verifySourceIdx = 0;
  int verifySource = sources[verifySourceIdx];
  if (do_verify) {
    init_arrays(distSerial, parentSerial, N, verifySource);
    bfs_parent_hops_powerlaw_serial(distSerial, parentSerial, verifySource);
    init_arrays(distPar, parentPar, N, verifySource);
    bfs_parent_hops_powerlaw_omp(distPar, parentPar, verifySource);
    if (!correctness_light_check(distSerial, parentSerial, distPar, parentPar, N, verifySource)) {
      printf("[check] mismatch during light verification at source %d\n", verifySource);
      free(sources); free(distSerial); free(parentSerial); free(distPar); free(parentPar);
      printf("[verdict] PERF-01 not triggered\n");
      return 0;
    }
  }

  // Time serial once.
  double t_serial = 0.0;
  {
    double t0 = walltime_sec();
    for (int si = 0; si < targetS; si++) {
      int s = sources[si];
      init_arrays(distSerial, parentSerial, N, s);
      bfs_parent_hops_powerlaw_serial(distSerial, parentSerial, s);
    }
    double t1 = walltime_sec();
    t_serial = t1 - t0;
  }

  // Time parallel for thread counts.
  int threads = 1;
  int highest = 1;
  int detected = 0;

  // Efficiency threshold: dynamic scheduling overhead should reduce efficiency noticeably.
  // We treat efficiency at highest thread count below 0.60 as suspicious.
  const double effThreshold = 0.60;

  while (threads <= maxThreads) {
    omp_set_num_threads(threads);
    double t_par = 0.0;
    {
      double t0 = walltime_sec();
      for (int si = 0; si < targetS; si++) {
        int s = sources[si];
        init_arrays(distPar, parentPar, N, s);
        bfs_parent_hops_powerlaw_omp(distPar, parentPar, s);
      }
      double t1 = walltime_sec();
      t_par = t1 - t0;
    }

    double speedup = (t_par > 0.0) ? (t_serial / t_par) : 0.0;
    double efficiency = speedup / (double)threads;
    printf("[scale] threads=%d time=%.6f speedup=%.3f eff=%.3f\n", threads, t_par, speedup, efficiency);

    highest = threads;
    if (threads == highest) {
      if (efficiency < effThreshold) detected = 1;
    }

    // next powers of two
    if (threads == maxThreads) break;
    threads *= 2;
  }

  free(sources);
  free(distSerial); free(parentSerial);
  free(distPar); free(parentPar);

  printf("[verdict] %s\n", detected ? "PERF-01 exposed" : "PERF-01 not triggered");
  return detected ? 1 : 0;
}
