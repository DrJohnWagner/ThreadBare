#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <math.h>

#ifdef _OPENMP
#include <omp.h>
#endif

typedef struct {
    uint64_t state;
} xorshift64star_rng;

static uint64_t rng_next_u64(xorshift64star_rng *r) {
    uint64_t x = r->state;
    x ^= x >> 12;
    x ^= x << 25;
    x ^= x >> 27;
    r->state = x;
    return x * 2685821657736338717ULL;
}

static double rng_next_open01(xorshift64star_rng *r) {
    /* Returns u in (0,1), never exactly 0 or 1. */
    uint64_t x = rng_next_u64(r);
    /* Map to (0, 2^64-1) then divide by 2^64. */
    return ((double)(x + 1ULL)) / 18446744073709551616.0; /* 2^64 */
}

static uint32_t select_powerlaw_index(xorshift64star_rng *r, uint32_t N, double alpha) {
    double u = rng_next_open01(r);
    double t = (1.0 - u);
    double k = (double)(N - 1U) * (1.0 - pow(t, -1.0 / (alpha - 1.0)));
    if (k < 0.0) return 0U;
    if (k > (double)(N - 1U)) return (uint32_t)(N - 1U);
    return (uint32_t)k;
}

static uint32_t choose_unique_source(xorshift64star_rng *r, uint32_t N, uint32_t *chosen, uint32_t chosenCount) {
    for (;;) {
        const double alpha = 2.5;
        uint32_t v = select_powerlaw_index(r, N, alpha);

        uint32_t ok = 1U;
        for (uint32_t i = 0; i < chosenCount; i++) {
            if (chosen[i] == v) { ok = 0U; break; }
        }
        if (ok) return v;
    }
}

typedef struct {
    uint32_t *rowStart;
    uint32_t *adj;
    uint32_t N;
    uint32_t M_undirected;
} graph_u;

static uint64_t hash_pair_u32(uint32_t a, uint32_t b) {
    uint64_t x = ((uint64_t)a << 32) ^ (uint64_t)b;
    x ^= x >> 33;
    x *= 0xff51afd7ed558ccdULL;
    x ^= x >> 33;
    x *= 0xc4ceb9fe1a85ec53ULL;
    x ^= x >> 33;
    return x;
}

static int generate_graph(graph_u *g) {
    const uint32_t N = 310000U;
    const uint32_t M = 5000000U;
    const uint64_t seedGraph = 0xC0FFEE123456789ULL;
    const double alpha = 2.5;

    uint32_t *deg = (uint32_t *)calloc((size_t)N, sizeof(uint32_t));
    if (!deg) return -1;

    uint64_t tableSize64 = 1ULL;
    while (tableSize64 < (uint64_t)M * 2ULL) tableSize64 <<= 1;
    uint32_t tableSize = (uint32_t)tableSize64;

    uint32_t *keys = (uint32_t *)malloc((size_t)tableSize * 2U * sizeof(uint32_t));
    if (!keys) { free(deg); return -1; }
    uint32_t *k1 = keys;
    uint32_t *k2 = keys + tableSize;
    for (uint32_t idx = 0; idx < tableSize; idx++) {
        k1[idx] = 0xFFFFFFFFU;
    }

    xorshift64star_rng rng;
    rng.state = seedGraph;

    uint32_t edges = 0U;
    while (edges < M) {
        uint32_t i, j;
        for (;;) {
            i = select_powerlaw_index(&rng, N, alpha);
            j = select_powerlaw_index(&rng, N, alpha);
            if (i != j) break;
        }
        uint32_t a = i < j ? i : j;
        uint32_t b = i < j ? j : i;

        uint64_t h = hash_pair_u32(a, b);
        uint32_t pos = (uint32_t)(h & (uint64_t)(tableSize - 1U));
        for (;;) {
            uint32_t curA = k1[pos];
            if (curA == 0xFFFFFFFFU) {
                k1[pos] = a;
                k2[pos] = b;
                deg[a]++;
                deg[b]++;
                edges++;
                break;
            }
            if (curA == a && k2[pos] == b) {
                break;
            }
            pos = (pos + 1U) & (tableSize - 1U);
        }
    }

    free(keys);

    uint32_t *rowStart = (uint32_t *)malloc((size_t)(N + 1U) * sizeof(uint32_t));
    if (!rowStart) { free(deg); return -1; }

    rowStart[0] = 0U;
    for (uint32_t v = 0U; v < N; v++) {
        rowStart[v + 1U] = rowStart[v] + deg[v];
    }

    uint32_t totalAdj = rowStart[N];
    uint32_t *adj = (uint32_t *)malloc((size_t)totalAdj * sizeof(uint32_t));
    if (!adj) { free(rowStart); free(deg); return -1; }

    uint32_t *cursor = (uint32_t *)malloc((size_t)N * sizeof(uint32_t));
    if (!cursor) { free(adj); free(rowStart); free(deg); return -1; }
    for (uint32_t v = 0U; v < N; v++) cursor[v] = rowStart[v];

    uint64_t tableSize64b = 1ULL;
    while (tableSize64b < (uint64_t)M * 2ULL) tableSize64b <<= 1;
    uint32_t tableSizeB = (uint32_t)tableSize64b;

    uint32_t *keysB = (uint32_t *)malloc((size_t)tableSizeB * 2U * sizeof(uint32_t));
    if (!keysB) { free(cursor); free(adj); free(rowStart); free(deg); return -1; }
    uint32_t *k1b = keysB;
    uint32_t *k2b = keysB + tableSizeB;
    for (uint32_t idx = 0; idx < tableSizeB; idx++) k1b[idx] = 0xFFFFFFFFU;

    xorshift64star_rng rng2;
    rng2.state = seedGraph;

    uint32_t edges2 = 0U;
    while (edges2 < M) {
        uint32_t i, j;
        for (;;) {
            i = select_powerlaw_index(&rng2, N, alpha);
            j = select_powerlaw_index(&rng2, N, alpha);
            if (i != j) break;
        }
        uint32_t a = i < j ? i : j;
        uint32_t b = i < j ? j : i;

        uint64_t h = hash_pair_u32(a, b);
        uint32_t pos = (uint32_t)(h & (uint64_t)(tableSizeB - 1U));
        for (;;) {
            uint32_t curA = k1b[pos];
            if (curA == 0xFFFFFFFFU) {
                k1b[pos] = a;
                k2b[pos] = b;
                adj[cursor[a]++] = b;
                adj[cursor[b]++] = a;
                edges2++;
                break;
            }
            if (curA == a && k2b[pos] == b) {
                break;
            }
            pos = (pos + 1U) & (tableSizeB - 1U);
        }
    }

    free(keysB);
    free(cursor);
    free(deg);

    g->rowStart = rowStart;
    g->adj = adj;
    g->N = N;
    g->M_undirected = M;
    return 0;
}

static void free_graph(graph_u *g) {
    free(g->rowStart);
    free(g->adj);
    g->rowStart = NULL;
    g->adj = NULL;
}

void bfs_parent_hops_powerlaw_omp(int *dist, int *parent, int sourceIndex) {
    graph_u g;
    if (generate_graph(&g) != 0) return;

    const uint32_t N = g.N;
    const uint32_t S = 20U;

    uint32_t sources[20];
    xorshift64star_rng rng;
    rng.state = 0x1234ABCD9876ULL;
    uint32_t chosenCount = 0U;
    while (chosenCount < S) {
        uint32_t v = choose_unique_source(&rng, N, sources, chosenCount);
        sources[chosenCount++] = v;
    }

    uint32_t s = sources[(uint32_t)sourceIndex];

    for (uint32_t v = 0U; v < N; v++) {
        dist[v] = -1;
        parent[v] = -1;
    }
    dist[s] = 0;
    parent[s] = (int)s;

    uint32_t *frontier = (uint32_t *)malloc((size_t)N * sizeof(uint32_t));
    uint32_t *nextFrontier = (uint32_t *)malloc((size_t)N * sizeof(uint32_t));
    uint32_t *nextParent = (uint32_t *)malloc((size_t)N * sizeof(uint32_t));
    if (!frontier || !nextFrontier || !nextParent) {
        free(frontier);
        free(nextFrontier);
        free(nextParent);
        free_graph(&g);
        return;
    }

    uint32_t frontierSize = 1U;
    frontier[0] = s;
    int d = 0;

    while (frontierSize > 0U) {
        uint32_t nextSize = 0U;

#ifdef _OPENMP
#pragma omp parallel
#endif
        {
            uint32_t localCount = 0U;
            uint32_t *localVerts = NULL;
            uint32_t *localParents = NULL;

            uint32_t tid = 0U;
#ifdef _OPENMP
            tid = (uint32_t)omp_get_thread_num();
#endif
            (void)tid;

            uint32_t cap = (frontierSize / (1U
#ifdef _OPENMP
                + (uint32_t)omp_get_num_threads()
#endif
                )) + 64U;

            localVerts = (uint32_t *)malloc((size_t)cap * sizeof(uint32_t));
            localParents = (uint32_t *)malloc((size_t)cap * sizeof(uint32_t));

#ifdef _OPENMP
#pragma omp for schedule(dynamic,1)
#endif
            for (uint32_t fi = 0U; fi < frontierSize; fi++) {
                uint32_t u = frontier[fi];
                int du = d;
                uint32_t start = g.rowStart[u];
                uint32_t end = g.rowStart[u + 1U];
                for (uint32_t ei = start; ei < end; ei++) {
                    uint32_t w = g.adj[ei];
                    if (dist[w] == -1) {
                        /* Reserve unique discovery deterministically by atomic compare */
#ifdef _OPENMP
#pragma omp atomic capture
#endif
                        {
                            int old;
#ifdef _OPENMP
#pragma omp atomic read
#endif
                            old = dist[w];
                            if (old == -1) {
#ifdef _OPENMP
#pragma omp critical
#endif
                                {
                                    if (dist[w] == -1) {
                                        dist[w] = du + 1;
                                        parent[w] = (int)u;

                                        if (localCount == cap) {
                                            uint32_t newCap = cap * 2U;
                                            uint32_t *nv = (uint32_t *)realloc(localVerts, (size_t)newCap * sizeof(uint32_t));
                                            uint32_t *np = (uint32_t *)realloc(localParents, (size_t)newCap * sizeof(uint32_t));
                                            if (nv && np) {
                                                localVerts = nv;
                                                localParents = np;
                                                cap = newCap;
                                            }
                                        }
                                        if (localCount < cap) {
                                            localVerts[localCount] = w;
                                            localParents[localCount] = u;
                                            localCount++;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

#ifdef _OPENMP
#pragma omp critical
#endif
            {
                for (uint32_t i = 0U; i < localCount; i++) {
                    nextFrontier[nextSize++] = localVerts[i];
                    (void)localParents[i];
                }
            }

            free(localVerts);
            free(localParents);
        }

        uint32_t *tmp = frontier;
        frontier = nextFrontier;
        nextFrontier = tmp;
        frontierSize = nextSize;
        d++;
    }

    free(frontier);
    free(nextFrontier);
    free(nextParent);
    free_graph(&g);
}
