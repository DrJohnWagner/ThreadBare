#include <stdint.h>
#include <stddef.h>

typedef struct {
    uint64_t state;
} xorshift64star_rng;

static uint64_t rng_next_u64(xorshift64star_rng *r) {
    uint64_t x = r->state;
    x ^= x >> 12;
    x ^= x << 25;
    x ^= x >> 27;
    r->state = x;
    return x * 2685821657736338717ULL;
}

static double rng_next_open01(xorshift64star_rng *r) {
    /* Returns u in (0,1), never exactly 0 or 1. */
    uint64_t x = rng_next_u64(r);
    /* Map to (0, 2^64-1) then divide by 2^64. */
    return ((double)(x + 1ULL)) / 18446744073709551616.0; /* 2^64 */
}

static uint32_t select_powerlaw_index(xorshift64star_rng *r, uint32_t N, double alpha) {
    /* Inverse-CDF with discrete exponent as specified. */
    double u = rng_next_open01(r);
    double t = (1.0 - u);
    double k = (double)(N - 1U) * (1.0 - pow(t, -1.0 / (alpha - 1.0)));
    /* Clamp to [0, N-1]. */
    if (k < 0.0) return 0U;
    if (k > (double)(N - 1U)) return (uint32_t)(N - 1U);
    return (uint32_t)k;
}

/* We need pow(), but standard only. */
#include <math.h>

static uint32_t choose_unique_source(xorshift64star_rng *r, uint32_t N, uint32_t *chosen, uint32_t chosenCount) {
    for (;;) {
        uint32_t v = 0U;
        {
            /* Use same mapping technique as graph endpoint sampling. */
            const double alpha = 2.5;
            double u = rng_next_open01(r);
            double t = (1.0 - u);
            double k = (double)(N - 1U) * (1.0 - pow(t, -1.0 / (alpha - 1.0)));
            if (k < 0.0) v = 0U;
            else if (k > (double)(N - 1U)) v = (uint32_t)(N - 1U);
            else v = (uint32_t)k;
        }
        uint32_t ok = 1U;
        for (uint32_t i = 0; i < chosenCount; i++) {
            if (chosen[i] == v) { ok = 0U; break; }
        }
        if (ok) return v;
    }
}

typedef struct {
    uint32_t *rowStart;
    uint32_t *adj;
    uint32_t N;
    uint32_t M_undirected;
} graph_u;

static uint64_t hash_pair_u32(uint32_t a, uint32_t b) {
    /* Deterministic 64-bit mix for open addressing. */
    uint64_t x = ((uint64_t)a << 32) ^ (uint64_t)b;
    x ^= x >> 33;
    x *= 0xff51afd7ed558ccdULL;
    x ^= x >> 33;
    x *= 0xc4ceb9fe1a85ec53ULL;
    x ^= x >> 33;
    return x;
}

static int generate_graph(graph_u *g) {
    const uint32_t N = 310000U;
    const uint32_t M = 5000000U;
    const uint64_t seedGraph = 0xC0FFEE123456789ULL;
    const double alpha = 2.5;

    /* Adjacency build: degree counts first, then prefix sums, then fill. */
    uint32_t *deg = (uint32_t *)calloc((size_t)N, sizeof(uint32_t));
    if (!deg) return -1;

    /* Hash set for unique undirected edges: store packed (i,j) with i<j. */
    /* Choose table size as power-of-two >= M*2 for low load. */
    uint64_t tableSize64 = 1ULL;
    while (tableSize64 < (uint64_t)M * 2ULL) tableSize64 <<= 1;
    uint32_t tableSize = (uint32_t)tableSize64;

    uint32_t *keys = (uint32_t *)malloc((size_t)tableSize * 2U * sizeof(uint32_t));
    /* Use a special marker for empty: i==UINT32_MAX. */
    if (!keys) { free(deg); return -1; }
    uint32_t *k1 = keys;
    uint32_t *k2 = keys + tableSize;
    for (uint32_t idx = 0; idx < tableSize; idx++) {
        k1[idx] = 0xFFFFFFFFU;
    }

    xorshift64star_rng rng;
    rng.state = seedGraph;

    uint32_t edges = 0U;
    while (edges < M) {
        uint32_t i, j;
        for (;;) {
            double u = rng_next_open01(&rng);
            double t = (1.0 - u);
            double k = (double)(N - 1U) * (1.0 - pow(t, -1.0 / (alpha - 1.0)));
            if (k < 0.0) i = 0U;
            else if (k > (double)(N - 1U)) i = (uint32_t)(N - 1U);
            else i = (uint32_t)k;

            u = rng_next_open01(&rng);
            t = (1.0 - u);
            k = (double)(N - 1U) * (1.0 - pow(t, -1.0 / (alpha - 1.0)));
            if (k < 0.0) j = 0U;
            else if (k > (double)(N - 1U)) j = (uint32_t)(N - 1U);
            else j = (uint32_t)k;

            if (i != j) break;
        }
        uint32_t a = i < j ? i : j;
        uint32_t b = i < j ? j : i;

        uint64_t h = hash_pair_u32(a, b);
        uint32_t pos = (uint32_t)(h & (uint64_t)(tableSize - 1U));
        for (;;) {
            uint32_t curA = k1[pos];
            if (curA == 0xFFFFFFFFU) {
                k1[pos] = a;
                k2[pos] = b;
                deg[a]++;
                deg[b]++;
                edges++;
                break;
            }
            if (curA == a && k2[pos] == b) {
                break;
            }
            pos = (pos + 1U) & (tableSize - 1U);
        }
    }

    free(keys);

    uint32_t *rowStart = (uint32_t *)malloc((size_t)(N + 1U) * sizeof(uint32_t));
    if (!rowStart) { free(deg); return -1; }

    rowStart[0] = 0U;
    for (uint32_t v = 0U; v < N; v++) {
        rowStart[v + 1U] = rowStart[v] + deg[v];
    }

    uint32_t totalAdj = rowStart[N];
    uint32_t *adj = (uint32_t *)malloc((size_t)totalAdj * sizeof(uint32_t));
    if (!adj) { free(rowStart); free(deg); return -1; }

    /* Fill adjacency using a cursor per vertex. */
    uint32_t *cursor = (uint32_t *)malloc((size_t)N * sizeof(uint32_t));
    if (!cursor) { free(adj); free(rowStart); free(deg); return -1; }
    for (uint32_t v = 0U; v < N; v++) cursor[v] = rowStart[v];

    /* Regenerate edges again to fill adjacency deterministically and match the same unique set logic.
       This keeps the single function simple and deterministic (no need to store all edges).
       We rebuild a fresh hash set, then insert edges until M unique, filling adj. */
    {
        uint64_t tableSize64b = 1ULL;
        while (tableSize64b < (uint64_t)M * 2ULL) tableSize64b <<= 1;
        uint32_t tableSizeB = (uint32_t)tableSize64b;

        uint32_t *keysB = (uint32_t *)malloc((size_t)tableSizeB * 2U * sizeof(uint32_t));
        if (!keysB) { free(cursor); free(adj); free(rowStart); free(deg); return -1; }
        uint32_t *k1b = keysB;
        uint32_t *k2b = keysB + tableSizeB;
        for (uint32_t idx = 0; idx < tableSizeB; idx++) k1b[idx] = 0xFFFFFFFFU;

        xorshift64star_rng rng2;
        rng2.state = seedGraph;

        uint32_t edges2 = 0U;
        while (edges2 < M) {
            uint32_t i, j;
            for (;;) {
                double u = rng_next_open01(&rng2);
                double t = (1.0 - u);
                double k = (double)(N - 1U) * (1.0 - pow(t, -1.0 / (alpha - 1.0)));
                if (k < 0.0) i = 0U;
                else if (k > (double)(N - 1U)) i = (uint32_t)(N - 1U);
                else i = (uint32_t)k;

                u = rng_next_open01(&rng2);
                t = (1.0 - u);
                k = (double)(N - 1U) * (1.0 - pow(t, -1.0 / (alpha - 1.0)));
                if (k < 0.0) j = 0U;
                else if (k > (double)(N - 1U)) j = (uint32_t)(N - 1U);
                else j = (uint32_t)k;

                if (i != j) break;
            }
            uint32_t a = i < j ? i : j;
            uint32_t b = i < j ? j : i;

            uint64_t h = hash_pair_u32(a, b);
            uint32_t pos = (uint32_t)(h & (uint64_t)(tableSizeB - 1U));
            for (;;) {
                uint32_t curA = k1b[pos];
                if (curA == 0xFFFFFFFFU) {
                    k1b[pos] = a;
                    k2b[pos] = b;
                    adj[cursor[a]++] = b;
                    adj[cursor[b]++] = a;
                    edges2++;
                    break;
                }
                if (curA == a && k2b[pos] == b) {
                    break;
                }
                pos = (pos + 1U) & (tableSizeB - 1U);
            }
        }

        free(keysB);
    }

    free(cursor);
    free(deg);

    g->rowStart = rowStart;
    g->adj = adj;
    g->N = N;
    g->M_undirected = M;
    return 0;
}

static void free_graph(graph_u *g) {
    free(g->rowStart);
    free(g->adj);
    g->rowStart = NULL;
    g->adj = NULL;
}

/* Primary function: perform BFS for S=20 deterministic sources and write outputs for one BFS.
   The harness is expected to call this per-source by selecting an index; dist/parent arrays are provided by caller.
   To keep a single serial oracle function, we interpret the function parameters as requesting BFS for one source index.
*/
void bfs_parent_hops_powerlaw_serial(int *dist, int *parent, int sourceIndex) {
    graph_u g;
    if (generate_graph(&g) != 0) return;

    const uint32_t N = g.N;
    const uint32_t S = 20U;

    uint32_t sources[20];
    xorshift64star_rng rng;
    rng.state = 0x1234ABCD9876ULL;
    uint32_t chosenCount = 0U;
    while (chosenCount < S) {
        uint32_t v = choose_unique_source(&rng, N, sources, chosenCount);
        sources[chosenCount++] = v;
    }

    uint32_t s = sources[(uint32_t)sourceIndex];

    for (uint32_t v = 0U; v < N; v++) {
        dist[v] = -1;
        parent[v] = -1;
    }
    dist[s] = 0;
    parent[s] = (int)s;

    uint32_t *queue = (uint32_t *)malloc((size_t)N * sizeof(uint32_t));
    uint32_t qh = 0U, qt = 0U;
    queue[qt++] = s;

    while (qh < qt) {
        uint32_t u = queue[qh++];
        int du = dist[u];
        uint32_t start = g.rowStart[u];
        uint32_t end = g.rowStart[u + 1U];
        for (uint32_t ei = start; ei < end; ei++) {
            uint32_t w = g.adj[ei];
            if (dist[w] == -1) {
                dist[w] = du + 1;
                parent[w] = (int)u;
                queue[qt++] = w;
            }
        }
    }

    free(queue);
    free_graph(&g);
}
