#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>

typedef struct {
    float x;
    float y;
} Point2f;

static uint32_t lcg_next_u32(uint32_t *state) {
    *state = (uint32_t)(1664525u * (*state) + 1013904223u);
    return *state;
}

static float lcg_next_f32_01(uint32_t *state) {
    uint32_t u = lcg_next_u32(state);
    return (float)((double)u / 4294967296.0);
}

void kmeans_lloyd_2d_omp(
    int N,
    int K,
    int maxIters,
    Point2f *points,
    int *assignments_out,
    Point2f *centroids_out,
    int *iters_out)
{
    int i, j, it;

    if (N <= 0 || K <= 0 || points == NULL || assignments_out == NULL || centroids_out == NULL || iters_out == NULL) {
        return;
    }

    uint32_t state = 123456789u;

    int *used = (int *)malloc((size_t)K * sizeof(int));
    int *used_marks = (int *)malloc((size_t)N * sizeof(int));
    int *assign_prev = (int *)malloc((size_t)N * sizeof(int));
    if (used == NULL || used_marks == NULL || assign_prev == NULL) {
        free(used);
        free(used_marks);
        free(assign_prev);
        return;
    }

    for (i = 0; i < N; i++) used_marks[i] = 0;

    const int maxRetries = 32;
    for (j = 0; j < K; j++) {
        int idx = -1;
        int retries;
        for (retries = 0; retries < maxRetries; retries++) {
            float u = lcg_next_f32_01(&state);
            int cand = (int)floorf(u * (float)N);
            if (cand < 0) cand = 0;
            if (cand >= N) cand = N - 1;
            if (!used_marks[cand]) {
                idx = cand;
                break;
            }
        }
        if (idx < 0) {
            float u = lcg_next_f32_01(&state);
            int start = (int)floorf(u * (float)N);
            if (start < 0) start = 0;
            if (start >= N) start = N - 1;
            int scan = start;
            for (retries = 0; retries < N; retries++) {
                if (!used_marks[scan]) {
                    idx = scan;
                    break;
                }
                scan++;
                if (scan >= N) scan = 0;
            }
        }
        if (idx < 0) {
            for (i = 0; i < N; i++) {
                if (!used_marks[i]) {
                    idx = i;
                    break;
                }
            }
        }

        used[j] = idx;
        used_marks[idx] = 1;
        centroids_out[j] = points[idx];
    }

    for (i = 0; i < N; i++) assign_prev[i] = -1;

    float *sumx = NULL;
    float *sumy = NULL;
    int *count = NULL;

    for (it = 0; it < maxIters; it++) {
        int changed = 0;

        #pragma omp parallel for schedule(static) reduction(|:changed)
        for (i = 0; i < N; i++) {
            float px = points[i].x;
            float py = points[i].y;

            int best_k = 0;
            float best_d = INFINITY;

            for (j = 0; j < K; j++) {
                float dx = px - centroids_out[j].x;
                float dy = py - centroids_out[j].y;
                float d = dx * dx + dy * dy;
                if (d < best_d) {
                    best_d = d;
                    best_k = j;
                }
            }

            assignments_out[i] = best_k;
            if (assign_prev[i] != best_k) changed = 1;
        }

        if (!changed) {
            *iters_out = it;
            free(used);
            free(used_marks);
            free(assign_prev);
            return;
        }

        free(sumx);
        free(sumy);
        free(count);
        sumx = (float *)malloc((size_t)K * sizeof(float));
        sumy = (float *)malloc((size_t)K * sizeof(float));
        count = (int *)malloc((size_t)K * sizeof(int));
        if (sumx == NULL || sumy == NULL || count == NULL) {
            free(sumx);
            free(sumy);
            free(count);
            free(used);
            free(used_marks);
            free(assign_prev);
            return;
        }

        for (j = 0; j < K; j++) {
            sumx[j] = 0.0f;
            sumy[j] = 0.0f;
            count[j] = 0;
        }

        int nthreads = 1;
        #pragma omp parallel
        {
            #pragma omp single
            nthreads = omp_get_num_threads();
        }

        float *sumx_all = (float *)calloc((size_t)nthreads * (size_t)K, sizeof(float));
        float *sumy_all = (float *)calloc((size_t)nthreads * (size_t)K, sizeof(float));
        int *count_all = (int *)calloc((size_t)nthreads * (size_t)K, sizeof(int));
        if (sumx_all == NULL || sumy_all == NULL || count_all == NULL) {
            free(sumx_all);
            free(sumy_all);
            free(count_all);
            for (i = 0; i < N; i++) {
                int cid = assignments_out[i];
                count[cid]++;
                sumx[cid] += points[i].x;
                sumy[cid] += points[i].y;
            }
        } else {
            #pragma omp parallel
            {
                int tid = omp_get_thread_num();
                float *lsx = sumx_all + (size_t)tid * (size_t)K;
                float *lsy = sumy_all + (size_t)tid * (size_t)K;
                int *lcnt = count_all + (size_t)tid * (size_t)K;

                #pragma omp for schedule(static)
                for (i = 0; i < N; i++) {
                    int cid = assignments_out[i];
                    lcnt[cid]++;
                    lsx[cid] += points[i].x;
                    lsy[cid] += points[i].y;
                }
            }

            for (j = 0; j < K; j++) {
                float sx = 0.0f;
                float sy = 0.0f;
                int ctot = 0;
                for (int tid = 0; tid < nthreads; tid++) {
                    sx += sumx_all[(size_t)tid * (size_t)K + (size_t)j];
                    sy += sumy_all[(size_t)tid * (size_t)K + (size_t)j];
                    ctot += count_all[(size_t)tid * (size_t)K + (size_t)j];
                }
                sumx[j] = sx;
                sumy[j] = sy;
                count[j] = ctot / nthreads;
            }

            free(sumx_all);
            free(sumy_all);
            free(count_all);
        }

        for (j = 0; j < K; j++) {
            if (count[j] > 0) {
                centroids_out[j].x = sumx[j] / (float)count[j];
                centroids_out[j].y = sumy[j] / (float)count[j];
            }
        }

        #pragma omp parallel for schedule(static)
        for (i = 0; i < N; i++) assign_prev[i] = assignments_out[i];
    }

    *iters_out = maxIters;

    free(sumx);
    free(sumy);
    free(count);
    free(used);
    free(used_marks);
    free(assign_prev);
}
