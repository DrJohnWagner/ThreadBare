#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <math.h>

typedef struct {
    float x;
    float y;
} Point2f;

static uint32_t lcg_next_u32(uint32_t *state) {
    *state = (uint32_t)(1664525u * (*state) + 1013904223u);
    return *state;
}

static float lcg_next_f32_01(uint32_t *state) {
    uint32_t u = lcg_next_u32(state);
    /* u / 2^32 in [0,1). Use double for correct division then cast to float. */
    return (float)((double)u / 4294967296.0);
}

void kmeans_lloyd_2d_serial(
    int N,
    int K,
    int maxIters,
    Point2f *points,
    int *assignments_out,
    Point2f *centroids_out,
    int *iters_out)
{
    int i, j, it;

    if (N <= 0 || K <= 0 || points == NULL || assignments_out == NULL || centroids_out == NULL || iters_out == NULL) {
        return;
    }

    /* Deterministic initialization using the exact LCG + Gaussian-like blobs assumed by spec.
       If points are supplied by harness, we still need deterministic centroids chosen from points.
       Spec requires centroids initialized by selecting 64 distinct point indices using the LCG.
       Therefore we reproduce the same LCG-driven index selection, independent of point generation.

       We generate a reproducible stream for centroid index selection only.
    */
    uint32_t state = 123456789u;
    float *u_stream = NULL; /* not needed; kept minimal */
    (void)u_stream;

    int *used = (int *)malloc((size_t)K * sizeof(int));
    int *used_marks = (int *)malloc((size_t)N * sizeof(int));
    int *assign_prev = (int *)malloc((size_t)N * sizeof(int));
    if (used == NULL || used_marks == NULL || assign_prev == NULL) {
        free(used);
        free(used_marks);
        free(assign_prev);
        return;
    }

    for (i = 0; i < N; i++) used_marks[i] = 0;

    /* Select K distinct point indices; retries are bounded. */
    const int maxRetries = 32;
    for (j = 0; j < K; j++) {
        int idx = -1;
        int retries;
        for (retries = 0; retries < maxRetries; retries++) {
            float u = lcg_next_f32_01(&state);
            int cand = (int)floorf(u * (float)N);
            if (cand < 0) cand = 0;
            if (cand >= N) cand = N - 1;
            if (!used_marks[cand]) {
                idx = cand;
                break;
            }
        }
        if (idx < 0) {
            float u = lcg_next_f32_01(&state);
            int start = (int)floorf(u * (float)N);
            if (start < 0) start = 0;
            if (start >= N) start = N - 1;
            int scan = start;
            for (retries = 0; retries < N; retries++) {
                if (!used_marks[scan]) {
                    idx = scan;
                    break;
                }
                scan++;
                if (scan >= N) scan = 0;
            }
        }
        if (idx < 0) {
            /* Should not happen; fall back to first unused. */
            for (i = 0; i < N; i++) {
                if (!used_marks[i]) {
                    idx = i;
                    break;
                }
            }
        }

        used[j] = idx;
        used_marks[idx] = 1;
        centroids_out[j] = points[idx];
    }

    for (i = 0; i < N; i++) assign_prev[i] = -1;

    /* Lloyd iterations */
    for (it = 0; it < maxIters; it++) {
        int changed = 0;

        /* Assignment step */
        for (i = 0; i < N; i++) {
            float px = points[i].x;
            float py = points[i].y;

            int best_k = 0;
            float best_d = INFINITY;

            for (j = 0; j < K; j++) {
                float dx = px - centroids_out[j].x;
                float dy = py - centroids_out[j].y;
                float d = dx * dx + dy * dy;
                if (d < best_d) {
                    best_d = d;
                    best_k = j;
                }
            }

            assignments_out[i] = best_k;
            if (assign_prev[i] != best_k) changed = 1;
        }

        /* Check convergence */
        if (!changed) {
            *iters_out = it;
            free(used);
            free(used_marks);
            free(assign_prev);
            return;
        }

        /* Prepare for centroid recomputation */
        float *sumx = (float *)malloc((size_t)K * sizeof(float));
        float *sumy = (float *)malloc((size_t)K * sizeof(float));
        int *count = (int *)malloc((size_t)K * sizeof(int));
        if (sumx == NULL || sumy == NULL || count == NULL) {
            free(sumx);
            free(sumy);
            free(count);
            free(used);
            free(used_marks);
            free(assign_prev);
            return;
        }

        for (j = 0; j < K; j++) {
            sumx[j] = 0.0f;
            sumy[j] = 0.0f;
            count[j] = 0;
        }

        /* Accumulate */
        for (i = 0; i < N; i++) {
            int cid = assignments_out[i];
            count[cid]++;
            sumx[cid] += points[i].x;
            sumy[cid] += points[i].y;
        }

        /* Update centroids (empty clusters unchanged) */
        for (j = 0; j < K; j++) {
            if (count[j] > 0) {
                centroids_out[j].x = sumx[j] / (float)count[j];
                centroids_out[j].y = sumy[j] / (float)count[j];
            }
        }

        for (i = 0; i < N; i++) assign_prev[i] = assignments_out[i];

        free(sumx);
        free(sumy);
        free(count);
    }

    *iters_out = maxIters;

    free(used);
    free(used_marks);
    free(assign_prev);
}
