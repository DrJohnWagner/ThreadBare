/* harness.c — differential driver for kmeans_lloyd_2d (generated)
    *
    *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
    *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
    */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <omp.h>

typedef struct { float x; float y; } Point2f;

void kmeans_lloyd_2d_serial(int N, int K, int maxIters,
                           Point2f *points,
                           int *assignments_out,
                           Point2f *centroids_out,
                           int *iters_out);

void kmeans_lloyd_2d_omp(int N, int K, int maxIters,
                          Point2f *points,
                          int *assignments_out,
                          Point2f *centroids_out,
                          int *iters_out);

static uint32_t lcg_next(uint32_t *state) {
    *state = (uint32_t)(1664525u * (*state) + 1013904223u);
    return *state;
}

static void fill_points(int N, int K_unused, Point2f *points) {
    (void)K_unused;
    uint32_t state = 123456789u;
    for (int i = 0; i < N; i++) {
        uint32_t r_u32 = lcg_next(&state);
        float u = (float)((double)r_u32 / 4294967296.0); /* [0,1) */
        int blob = (u < 0.5f) ? 0 : 1;
        float cx = blob ? 1000.0f : -1000.0f;
        float cy = blob ? 1000.0f : -1000.0f;

        uint32_t ux_u32 = lcg_next(&state);
        uint32_t uy_u32 = lcg_next(&state);
        float ux = (float)((double)ux_u32 / 4294967296.0);
        float uy = (float)((double)uy_u32 / 4294967296.0);

        float jx = (ux - 0.5f) * 2.0f * 25.0f;
        float jy = (uy - 0.5f) * 2.0f * 25.0f;

        points[i].x = cx + jx;
        points[i].y = cy + jy;
    }
}

static void usage(const char *argv0) {
    printf("usage: %s [--n N] [--reps R] [--threads T]\n", argv0);
}

int main(int argc, char **argv) {
    int K = 64;
    int maxIters = 1000;

    long n_spec[] = {1000000L, 2000000L, 800000L, 1200000L};
    int defaultN = (int)n_spec[1]; /* 2000000 */

    int N = defaultN;
    int reps = 20;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--n") && i + 1 < argc) {
            N = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--reps") && i + 1 < argc) {
            reps = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--threads") && i + 1 < argc) {
            int t = atoi(argv[++i]);
            omp_set_num_threads(t);
        } else if (!strcmp(argv[i], "--help")) {
            usage(argv[0]);
            return 0;
        } else {
            fprintf(stderr, "unknown arg: %s\n", argv[i]);
            usage(argv[0]);
            return 2;
        }
    }

    if (N <= 0) {
        fprintf(stderr, "--n must be positive\n");
        return 2;
    }
    if (reps < 1) reps = 1;

    Point2f *points = (Point2f *)malloc((size_t)N * sizeof(Point2f));
    int *a_ref = (int *)malloc((size_t)N * sizeof(int));
    int *a_par = (int *)malloc((size_t)N * sizeof(int));
    Point2f *c_ref = (Point2f *)malloc((size_t)K * sizeof(Point2f));
    Point2f *c_par = (Point2f *)malloc((size_t)K * sizeof(Point2f));
    int it_ref = 0, it_par = 0;
    int *iters_ref_out = &it_ref;
    int *iters_par_out = &it_par;

    if (!points || !a_ref || !a_par || !c_ref || !c_par) {
        fprintf(stderr, "allocation failure\n");
        return 2;
    }

    fill_points(N, K, points);

    /* Ground truth */
    kmeans_lloyd_2d_serial(N, K, maxIters, points, a_ref, c_ref, iters_ref_out);

    int failures = 0;

    for (int r = 0; r < reps; r++) {
        kmeans_lloyd_2d_omp(N, K, maxIters, points, a_par, c_par, iters_par_out);

        /* Must match assignments exactly element-wise. */
        int mismatch_index = -1;
        for (int i = 0; i < N; i++) {
            if (a_par[i] != a_ref[i]) {
                mismatch_index = i;
                break;
            }
        }
        if (mismatch_index != -1) {
            failures = 1;
            printf("[check] divergence at iter_run=%d point=%d: A_par=%d A_ref=%d (iters_par=%d iters_ref=%d)\n",
                   r, mismatch_index, a_par[mismatch_index], a_ref[mismatch_index], it_par, it_ref);
            break;
        }

        /* Also check centroids within tolerance. */
        const double tol_scale = 1e-4;
        int centroid_mismatch = 0;
        int centroid_j = -1;
        int coord = -1;
        for (int j = 0; j < K && !centroid_mismatch; j++) {
            for (int cc = 0; cc < 2; cc++) {
                float parv = (cc == 0) ? c_par[j].x : c_par[j].y;
                float refv = (cc == 0) ? c_ref[j].x : c_ref[j].y;
                double denom = 1.0 + fabs((double)refv);
                double tol = tol_scale * denom;
                double diff = fabs((double)parv - (double)refv);
                if (diff > tol) {
                    centroid_mismatch = 1;
                    centroid_j = j;
                    coord = cc;
                    break;
                }
            }
        }
        if (centroid_mismatch) {
            failures = 1;
            printf("[check] centroid divergence at iter_run=%d centroid=%d coord=%c: par=%g ref=%g iters_par=%d iters_ref=%d\n",
                   r, centroid_j, (coord==0?'x':'y'),
                   (coord==0?(double)c_par[centroid_j].x:(double)c_par[centroid_j].y),
                   (coord==0?(double)c_ref[centroid_j].x:(double)c_ref[centroid_j].y),
                   it_par, it_ref);
            break;
        }

        if (it_par != it_ref) {
            failures = 1;
            printf("[check] iteration-count divergence at iter_run=%d iters_par=%d iters_ref=%d\n", r, it_par, it_ref);
            break;
        }
    }

    free(points);
    free(a_ref);
    free(a_par);
    free(c_ref);
    free(c_par);

    if (failures) {
        printf("[verdict] SAFE-01 exposed\n");
        return 1;
    }
    printf("[verdict] SAFE-01 not triggered\n");
    return 0;
}
