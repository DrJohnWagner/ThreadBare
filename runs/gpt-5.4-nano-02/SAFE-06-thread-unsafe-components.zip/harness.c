/* harness.c — differential driver for sensor_log_ingest_pipeline (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <omp.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <inttypes.h>

// Forward declarations (must match real signatures exactly)
void sensor_log_ingest_pipeline_serial(
    uint32_t *out_total_files_processed,
    uint32_t *out_total_sensor_aggregate_rows,
    uint64_t *out_checksum);

void sensor_log_ingest_pipeline_omp(
    uint32_t *out_total_files_processed,
    uint32_t *out_total_sensor_aggregate_rows,
    uint64_t *out_checksum);

static void usage(const char *prog) {
    fprintf(stderr,
            "Usage: %s [--reps N] [--n F] [--threads T]\n"
            "  --reps N     Repetitions for the parallel run (default 25)\n"
            "  --n F        Number of files to use (default 200)\n"
            "  --threads T Set OMP_NUM_THREADS (also works via env)\n",
            prog);
}

static uint64_t now_ns(void) {
    // Not used for correctness; kept minimal.
    return 0;
}

int main(int argc, char **argv) {
    int reps = 25;
    int F = 200;
    int threads_override = -1;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--reps") && i + 1 < argc) {
            reps = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--n") && i + 1 < argc) {
            F = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--threads") && i + 1 < argc) {
            threads_override = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) {
            usage(argv[0]);
            return 0;
        } else {
            fprintf(stderr, "Unknown/invalid arg: %s\n", argv[i]);
            usage(argv[0]);
            return 2;
        }
    }

    if (F <= 0) {
        fprintf(stderr, "--n must be > 0\n");
        return 2;
    }

    if (threads_override > 0) {
        char buf[32];
        snprintf(buf, sizeof(buf), "%d", threads_override);
        setenv("OMP_NUM_THREADS", buf, 1);
    }

    // Deterministic synthetic inputs.
    // The workload described in the spec is implemented inside serial/parallel;
    // the harness still deterministically varies a simple parameter if the
    // implementation supports it via environment. Since we don't have headers,
    // we rely on convention: implementations read F from env SENSOR_PIPELINE_F.
    // We set it deterministically here. If the implementation ignores it, the
    // check still works (using its built-in F).
    {
        char buf[32];
        snprintf(buf, sizeof(buf), "%d", F);
        setenv("SENSOR_PIPELINE_F", buf, 1);
    }

    uint32_t s_files_ref = 0;
    uint32_t s_rows_ref = 0;
    uint64_t c_ref = 0;
    
    // Compute ground truth once using serial reference.
    sensor_log_ingest_pipeline_serial(&s_files_ref, &s_rows_ref, &c_ref);

    // Run parallel multiple times to catch nondeterministic corruption from
    // thread-unsafe rand() usage.
    int detected = 0;
    for (int rep = 0; rep < reps; rep++) {
        uint32_t s_files = 0;
        uint32_t s_rows = 0;
        uint64_t c = 0;

        sensor_log_ingest_pipeline_omp(&s_files, &s_rows, &c);

        if (s_files != s_files_ref || s_rows != s_rows_ref || c != c_ref) {
            detected = 1;
            printf("[check] mismatch on rep=%d: serial(A=%u,B=%u,C=%" PRIu64 ") vs omp(A=%u,B=%u,C=%" PRIu64 ")\n",
                   rep, s_files_ref, s_rows_ref, c_ref, s_files, s_rows, c);
            break;
        }
    }

    if (detected) {
        printf("[verdict] SAFE-01 exposed\n");
        return 1;
    }

    printf("[verdict] SAFE-01 not triggered\n");
    return 0;
}
