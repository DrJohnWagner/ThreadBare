#include <stdint.h>
#include <stdlib.h>
#include <math.h>

static uint64_t lcg_next(uint64_t z) {
    return z * 6364136223846793005ULL + 1ULL;
}

void sensor_log_ingest_pipeline_serial(uint32_t *out_total_files_processed,
                                        uint32_t *out_total_sensor_aggregate_rows,
                                        uint64_t *out_checksum) {
    const uint32_t F = 200;
    const uint32_t R = 23000;
    const uint32_t M = 16;

    uint32_t total_files_processed = F;
    uint32_t total_sensor_aggregate_rows = F * M;

    float *sum_x = (float *)calloc((size_t)F * (size_t)M, sizeof(float));
    uint64_t *sum_t = (uint64_t *)calloc((size_t)F * (size_t)M, sizeof(uint64_t));
    (void)sum_t; /* count not needed for checksum; sums are enough */

    if (!sum_x) {
        /* If allocation fails, produce deterministic non-crashing behavior. */
        if (out_total_files_processed) *out_total_files_processed = total_files_processed;
        if (out_total_sensor_aggregate_rows) *out_total_sensor_aggregate_rows = total_sensor_aggregate_rows;
        if (out_checksum) *out_checksum = 0;
        return;
    }

    /* Stage order for correctness: for each file i, for each record k in order,
       decode and accumulate in sensor order preserving the specified float order. */
    for (uint32_t i = 0; i < F; i++) {
        for (uint32_t k = 0; k < R; k++) {
            uint64_t z = (uint64_t)123456ULL + 1000003ULL * (uint64_t)i + 10007ULL * (uint64_t)k;
            /* generator update applied once per record for the first field */
            z = lcg_next(z);

            uint32_t t = (uint32_t)((z >> 16) % 1000000ULL);
            uint8_t s = (uint8_t)((z >> 32) % (uint64_t)M);
            int32_t raw = (int32_t)((int64_t)(z >> 0) % 20001LL);
            float x = (float)raw / 100.0f;

            size_t idx = (size_t)i * (size_t)M + (size_t)s;
            sum_x[idx] += x;
            ((uint64_t *)sum_t)[idx] += (uint64_t)t;

            /* Advance RNG state for next record: handled by recomputation of z per (i,k).
               This matches the deterministic per-(i,k) definition exactly. */
        }
    }

    uint64_t checksum = 0;
    for (uint32_t i = 0; i < F; i++) {
        for (uint32_t s = 0; s < M; s++) {
            size_t idx = (size_t)i * (size_t)M + (size_t)s;
            float sx = sum_x[idx];
            long long rounded = llround(1000.0f * sx);
            uint64_t a = (uint64_t)rounded;
            uint64_t b = ((uint64_t)sum_t[idx]) & 0xFFFFFFFFULL;
            checksum ^= (a ^ b);
        }
    }

    free(sum_x);
    free(sum_t);

    if (out_total_files_processed) *out_total_files_processed = total_files_processed;
    if (out_total_sensor_aggregate_rows) *out_total_sensor_aggregate_rows = total_sensor_aggregate_rows;
    if (out_checksum) *out_checksum = checksum;
}
