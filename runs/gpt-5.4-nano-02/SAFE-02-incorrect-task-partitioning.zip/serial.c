#include <stddef.h>

static void lcg_seeded_points(int N, double *x, double *y) {
    unsigned int s = 123456789u;
    for (int i = 0; i < N; ++i) {
        s = 1664525u * s + 1013904223u;
        unsigned int s1 = s;
        s = 1664525u * s + 1013904223u;
        unsigned int s2 = s;
        x[i] = (double)s1 / 4294967296.0; /* 2^32 */
        y[i] = (double)s2 / 4294967296.0;
    }
}

void kmeans_2d_serial(int N, int maxIters, double *centX, double *centY, int *assign) {
    const int K = 64;

    double *x = (double *)((N > 0) ? (void *)0 : (void *)0);
    double *y = (double *)((N > 0) ? (void *)0 : (void *)0);
    /* Allocate with standard C library via malloc/free without including headers.
       The harness will link with libc; implicit declarations are not allowed in C99.
       So we declare malloc/free prototypes here. */
    /* Note: GCC with -Wall -Wextra forbids implicit declarations; provide prototypes. */
}

/* Proper implementation with malloc/free prototypes */

#include <stdlib.h>
#include <math.h>

void kmeans_2d_serial(int N, int maxIters, double *centX, double *centY, int *assign_out) {
    const int K = 64;

    if (N <= 0) {
        for (int c = 0; c < K; ++c) {
            centX[c] = 0.0;
            centY[c] = 0.0;
        }
        return;
    }
    if (maxIters < 0) {
        maxIters = 0;
    }

    double *x = (double *)malloc((size_t)N * sizeof(double));
    double *y = (double *)malloc((size_t)N * sizeof(double));
    if (!x || !y) {
        free(x);
        free(y);
        return;
    }

    lcg_seeded_points(N, x, y);

    for (int c = 0; c < K; ++c) {
        int idx = (int)((long long)c * 10007LL % (long long)N);
        centX[c] = x[idx];
        centY[c] = y[idx];
    }

    int *assign = assign_out;

    int *prevAssign = (int *)malloc((size_t)N * sizeof(int));
    double *sumX = (double *)malloc((size_t)K * sizeof(double));
    double *sumY = (double *)malloc((size_t)K * sizeof(double));
    int *cnt = (int *)malloc((size_t)K * sizeof(int));
    if (!prevAssign || !sumX || !sumY || !cnt) {
        free(prevAssign);
        free(sumX);
        free(sumY);
        free(cnt);
        free(x);
        free(y);
        return;
    }

    for (int i = 0; i < N; ++i) {
        prevAssign[i] = -1;
    }

    int it = 0;
    for (; it < maxIters; ++it) {
        for (int c = 0; c < K; ++c) {
            sumX[c] = 0.0;
            sumY[c] = 0.0;
            cnt[c] = 0;
        }

        int changed = 0;

        for (int i = 0; i < N; ++i) {
            double xi = x[i];
            double yi = y[i];

            int best = 0;
            double bestDist = (centX[0] - xi) * (centX[0] - xi) + (centY[0] - yi) * (centY[0] - yi);

            for (int c = 1; c < K; ++c) {
                double dx = centX[c] - xi;
                double dy = centY[c] - yi;
                double d = dx * dx + dy * dy;
                if (d < bestDist) {
                    bestDist = d;
                    best = c;
                }
            }

            assign[i] = best;
            if (best != prevAssign[i]) {
                changed = 1;
            }

            sumX[best] += xi;
            sumY[best] += yi;
            cnt[best] += 1;
        }

        if (!changed) {
            break;
        }

        for (int c = 0; c < K; ++c) {
            if (cnt[c] > 0) {
                centX[c] = sumX[c] / (double)cnt[c];
                centY[c] = sumY[c] / (double)cnt[c];
            }
        }

        for (int i = 0; i < N; ++i) {
            prevAssign[i] = assign[i];
        }
    }

    free(prevAssign);
    free(sumX);
    free(sumY);
    free(cnt);
    free(x);
    free(y);
}
