/* harness.c — differential driver for kmeans_2d (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

/* Forward declarations matching the real signatures exactly */
void kmeans_2d_serial(int N, int maxIters, double *centX, double *centY, int *assign_out);
void kmeans_2d_omp(int N, int maxIters, double *centX, double *centY, int *assign_out);

#define K 64

static void gen_points_and_init_centroids(int N, double *x, double *y, double *centX, double *centY) {
    uint32_t s = 123456789u;
    for (int i = 0; i < N; i++) {
        /* LCG update */
        s = (uint32_t)(1664525u * s + 1013904223u);
        uint32_t t = s;
        s = (uint32_t)(1664525u * s + 1013904223u);
        uint32_t u = s;
        x[i] = (double)t / 4294967296.0; /* 2^32 */
        y[i] = (double)u / 4294967296.0;
    }

    for (int c = 0; c < K; c++) {
        int idx = (c * 10007) % N;
        centX[c] = x[idx];
        centY[c] = y[idx];
    }
}

static void copy_double(double *dst, const double *src, size_t n) {
    memcpy(dst, src, n * sizeof(double));
}

static void copy_int(int *dst, const int *src, size_t n) {
    memcpy(dst, src, n * sizeof(int));
}

static int compare_results(int N, const double *centX_ref, const double *centY_ref, const int *assign_ref,
                            const double *centX_par, const double *centY_par, const int *assign_par) {
    /* Exact match on assignments */
    for (int i = 0; i < N; i++) {
        if (assign_par[i] != assign_ref[i]) {
            printf("[check] assign mismatch at i=%d ref=%d par=%d\n", i, assign_ref[i], assign_par[i]);
            return 1;
        }
    }

    /* Centroids within tolerance */
    const double tol = 1e-9;
    for (int c = 0; c < K; c++) {
        double dx = fabs(centX_par[c] - centX_ref[c]);
        double dy = fabs(centY_par[c] - centY_ref[c]);
        if (dx > tol || dy > tol) {
            printf("[check] centroid mismatch at c=%d ref=(%.17g,%.17g) par=(%.17g,%.17g) dx=%.3g dy=%.3g\n",
                   c, centX_ref[c], centY_ref[c], centX_par[c], centY_par[c], dx, dy);
            return 1;
        }
    }

    return 0;
}

int main(int argc, char **argv) {
    int reps = 20;
    int N = 1000000; /* largest from spec */
    int maxIters = 50;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--reps") == 0 && i + 1 < argc) {
            reps = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            N = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--iters") == 0 && i + 1 < argc) {
            maxIters = atoi(argv[++i]);
        } else {
            fprintf(stderr, "Unknown/invalid arg: %s\n", argv[i]);
            return 2;
        }
    }

    double *x = (double *)malloc((size_t)N * sizeof(double));
    double *y = (double *)malloc((size_t)N * sizeof(double));
    if (!x || !y) {
        fprintf(stderr, "Allocation failed\n");
        return 2;
    }

    double centX_init[K], centY_init[K];
    gen_points_and_init_centroids(N, x, y, centX_init, centY_init);

    double centX_ref[K], centY_ref[K];
    int *assign_ref = (int *)malloc((size_t)N * sizeof(int));
    if (!assign_ref) {
        fprintf(stderr, "Allocation failed\n");
        return 2;
    }

    /* Reference run once */
    copy_double(centX_ref, centX_init, K);
    copy_double(centY_ref, centY_init, K);
    kmeans_2d_serial(N, maxIters, centX_ref, centY_ref, assign_ref);

    int failures = 0;

    double centX_par[K], centY_par[K];
    int *assign_par = (int *)malloc((size_t)N * sizeof(int));
    if (!assign_par) {
        fprintf(stderr, "Allocation failed\n");
        return 2;
    }

    for (int r = 0; r < reps; r++) {
        copy_double(centX_par, centX_init, K);
        copy_double(centY_par, centY_init, K);
        kmeans_2d_omp(N, maxIters, centX_par, centY_par, assign_par);

        if (compare_results(N, centX_ref, centY_ref, assign_ref, centX_par, centY_par, assign_par)) {
            failures = 1;
            printf("[check] failure observed on repetition %d\n", r);
            break;
        }
    }

    free(assign_par);
    free(assign_ref);
    free(x);
    free(y);

    printf("[verdict] %s\n", failures ? "SAFE-01 exposed" : "SAFE-01 not triggered");
    return failures ? 1 : 0;
}
