/* harness.c — timeout driver for sensor_log_pipeline_summary (generated)
    *
    *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
    *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
    */

#include <omp.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

// Forward declarations: must match real signatures exactly.
typedef struct {
    double sum;
    uint64_t count;
} SensorSummary;

void sensor_log_pipeline_summary_serial(size_t numFiles, size_t recordsPerFile, size_t numSensors, SensorSummary *resultsTable);
void sensor_log_pipeline_summary_omp(size_t numFiles, size_t recordsPerFile, size_t numSensors, SensorSummary *resultsTable);

static volatile sig_atomic_t timed_out = 0;
static void alarm_handler(int sig) {
    (void)sig;
    timed_out = 1;
}

typedef struct {
    size_t numFiles;
    size_t recordsPerFile;
    size_t numSensors;
} Params;

static void fill_inputs_implicitly(void) {
    // Inputs are implicit in the computation description; no-op.
}

static void run_one_parallel(const Params *p, SensorSummary *out) {
    timed_out = 0;
    fill_inputs_implicitly();
    sensor_log_pipeline_summary_omp(p->numFiles, p->recordsPerFile, p->numSensors, out);
}

int main(int argc, char **argv) {
    Params p;
    // Default to the largest given size.
    p.numFiles = 200;
    p.recordsPerFile = 200000;
    p.numSensors = 500;

    int timeout_sec = 3;
    int sleep_grace_ms = 50;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--timeout") == 0 && i + 1 < argc) {
            timeout_sec = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            // Map --n to recordsPerFile choice from spec problemSizes.
            // If n is 0/1/2/3 we pick spec[0..3]; if it's large we take it directly as recordsPerFile.
            size_t n = (size_t)strtoull(argv[++i], NULL, 10);
            size_t specSizes[] = {200u, 200u, 500u, 800u, 200000u};
            if (n <= 4) {
                p.recordsPerFile = specSizes[n];
            } else {
                p.recordsPerFile = n;
            }
        } else if (strcmp(argv[i], "--grace") == 0 && i + 1 < argc) {
            sleep_grace_ms = atoi(argv[++i]);
        } else {
            fprintf(stderr, "Unknown/invalid argument: %s\n", argv[i]);
            return 2;
        }
    }

    // Allocate output (not used for comparison in liveness mode).
    SensorSummary *buf = (SensorSummary *)calloc(p.numFiles * p.numSensors, sizeof(SensorSummary));
    if (!buf) {
        perror("calloc");
        return 2;
    }

    // Set a wall-clock timeout for the parallel kernel.
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = alarm_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    if (sigaction(SIGALRM, &sa, NULL) != 0) {
        perror("sigaction");
        free(buf);
        return 2;
    }

    // Run the parallel version in this process with an alarm.
    // If it livelocks, it should exceed the timeout and we flag failure.
    timed_out = 0;
    alarm((unsigned)timeout_sec);
    run_one_parallel(&p, buf);
    alarm(0);

    // Small grace to avoid false positives due to signal timing.
    if (!timed_out && sleep_grace_ms > 0) {
        usleep((useconds_t)sleep_grace_ms * 1000u);
    }

    int failures = timed_out ? 1 : 0;

    if (failures) {
        // Try to ensure no further output.
    }

    free(buf);

    printf("[verdict] %s\n", failures ? "LIVE-01 exposed" : "LIVE-01 not triggered");
    return failures ? 1 : 0;
}
