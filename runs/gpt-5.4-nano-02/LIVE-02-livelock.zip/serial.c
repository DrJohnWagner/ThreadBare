#include <stdint.h>
#include <stddef.h>

typedef struct {
    double sum;
    uint32_t count;
} SensorSummary;

static uint32_t next_lcg_u32(uint32_t x) {
    return 1664525u * x + 1013904223u;
}

void sensor_log_pipeline_summary_serial(
    size_t numFiles,
    size_t recordsPerFile,
    size_t numSensors,
    SensorSummary *resultsTable)
{
    if (!resultsTable || numSensors == 0) return;

    for (size_t f = 0; f < numFiles; ++f) {
        double sums[8];
        uint32_t counts[8];
        for (size_t s = 0; s < numSensors; ++s) {
            sums[s] = 0.0;
            counts[s] = 0u;
        }

        uint32_t x = 12345u + 1103515245u * (uint32_t)f;
        for (size_t r = 0; r < recordsPerFile; ++r) {
            x = next_lcg_u32(x);
            uint32_t sensorId = x % (uint32_t)numSensors;
            int value = (int)((int32_t)(x % 2001u)) - 1000;

            double decodedValue = (double)value * 0.1;
            if ((sensorId % 2u) == 0u) decodedValue += 1.0;
            else decodedValue -= 1.0;

            sums[sensorId] += decodedValue;
            counts[sensorId] += 1u;
        }

        for (size_t s = 0; s < numSensors; ++s) {
            resultsTable[f * numSensors + s].sum = sums[s];
            resultsTable[f * numSensors + s].count = counts[s];
        }
    }
}
