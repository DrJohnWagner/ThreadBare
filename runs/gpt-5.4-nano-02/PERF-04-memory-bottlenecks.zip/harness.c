/* harness.c — scaling driver for kmeans_assignment_recompute_converge (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <time.h>

// Forward declarations (must match real signatures exactly)
void kmeans_assignment_recompute_converge_serial(int N, double centroids_out[64][2], int *assignments_out, int *iterations_out);
void kmeans_assignment_recompute_converge_omp(int N, double centroids_out[64][2], int *assignments_out, int *iterations_out);

static double now_sec(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (double)ts.tv_sec + 1e-9 * (double)ts.tv_nsec;
}

int main(int argc, char **argv) {
  int N = 1600000;
  int reps = 1; // not used for scaling; kept for flag parsing compatibility

  for (int i = 1; i < argc; i++) {
    if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
      N = atoi(argv[++i]);
    } else if (strcmp(argv[i], "--reps") == 0 && i + 1 < argc) {
      reps = atoi(argv[++i]);
      if (reps < 1) reps = 1;
    }
  }

  const int K = 64;

  // Deterministic dataset generation (as specified)
  double *points = (double *)malloc((size_t)N * 2u * sizeof(double));
  if (!points) {
    fprintf(stderr, "alloc failed for points\n");
    return 1;
  }

  const uint64_t A = 6364136223846793005ULL;
  const uint64_t C = 1442695040888963407ULL;
  uint64_t state = 123456789012345ULL;

  // Precompute 8 generating centers on a circle of radius 100
  double centers[8][2];
  const double R = 100.0;
  for (int c = 0; c < 8; c++) {
    double ang = (2.0 * M_PI * (double)c) / 8.0;
    centers[c][0] = R * cos(ang);
    centers[c][1] = R * sin(ang);
  }

  // LCG draw -> u in (0,1)
  auto uint64_draw = [&]() -> uint64_t {
    state = state * A + C;
    return state; // mod 2^64 via overflow
  };
  auto uniform01 = [&]() -> double {
    uint64_t s = uint64_draw();
    // u = (state >> 11) * (1.0 / 9007199254740992.0)
    return (double)(s >> 11) * (1.0 / 9007199254740992.0);
  };

  // Box–Muller; generate z0,z1 from two uniforms
  for (int i = 0; i < N; i++) {
    double u1 = uniform01();
    double u2 = uniform01();
    // Guard against u1==0 (extremely unlikely); clamp to smallest positive
    if (u1 <= 0.0) u1 = 1e-16;
    double mag = sqrt(-2.0 * log(u1));
    double z0 = mag * cos(2.0 * M_PI * u2);
    double z1 = mag * sin(2.0 * M_PI * u2);

    double u = uniform01();
    int g = (int)floor(8.0 * u);
    if (g < 0) g = 0;
    if (g > 7) g = 7;

    double cx = centers[g][0];
    double cy = centers[g][1];
    points[(size_t)i * 2u + 0u] = cx + 10.0 * z0;
    points[(size_t)i * 2u + 1u] = cy + 10.0 * z1;
  }

  // Initial centroids: choose every (N/K)-th point (wrap)
  // The kernel itself computes initialization internally according to spec,
  // but we also need a warmup touch of points; we already generated them.

  double centroids_serial[K][2];
  double centroids_parallel[K][2];
  int *assign_serial = (int *)malloc((size_t)N * sizeof(int));
  int *assign_parallel = (int *)malloc((size_t)N * sizeof(int));
  int it_serial = 0;
  int it_parallel = 0;

  if (!assign_serial || !assign_parallel) {
    fprintf(stderr, "alloc failed for assignments\n");
    free(points);
    free(assign_serial);
    free(assign_parallel);
    return 1;
  }

  // Warmup: touch every point to force page faults / cold cache outside timing
  // (Kernel may compute its own initialization; we just ensure memory subsystem is warm.)
  volatile double sink = 0.0;
  for (size_t i = 0; i < (size_t)N * 2u; i++) sink += points[i];
  (void)sink;

  // Warmup pass on both kernels (untimed) to reduce first-call overhead
  kmeans_assignment_recompute_converge_serial(N, centroids_serial, assign_serial, &it_serial);
  kmeans_assignment_recompute_converge_omp(N, centroids_parallel, assign_parallel, &it_parallel);

  // Timed serial (single call)
  // Ensure serial baseline at current thread count? (omp threads only affect omp kernel)
  // Serial kernel should be single-threaded by design.
  double t0 = now_sec();
  kmeans_assignment_recompute_converge_serial(N, centroids_serial, assign_serial, &it_serial);
  double t_serial = now_sec() - t0;

  // Light correctness check using parallel at highest thread count tested later.
  int max_threads = omp_get_max_threads();
  int t_list[64];
  int tcount = 0;
  // Thread counts: 1,2,4,... up to max
  int t = 1;
  while (t <= max_threads && tcount < 64) {
    t_list[tcount++] = t;
    if (t == 0) break;
    t *= 2;
  }
  if (tcount == 0) { t_list[tcount++] = 1; }

  int best_t = t_list[tcount - 1];
  double t_parallel_best = 0.0;
  int verdict = 0;

  for (int idx = 0; idx < tcount; idx++) {
    int threads = t_list[idx];
    omp_set_num_threads(threads);

    double tp0 = now_sec();
    kmeans_assignment_recompute_converge_omp(N, centroids_parallel, assign_parallel, &it_parallel);
    double t_parallel = now_sec() - tp0;

    double speedup = t_serial / t_parallel;
    double efficiency = speedup / (double)threads;

    printf("[scale] threads=%d time=%g speedup=%g eff=%g\n", threads, t_parallel, speedup, efficiency);

    if (threads == best_t) {
      t_parallel_best = t_parallel;

      // One light correctness check at best_t
      int mismatch = 0;
      for (int i = 0; i < N; i++) {
        if (assign_parallel[i] != assign_serial[i]) { mismatch = 1; break; }
      }
      if (!mismatch) {
        for (int j = 0; j < K; j++) {
          for (int d = 0; d < 2; d++) {
            double a = centroids_parallel[j][d];
            double b = centroids_serial[j][d];
            double tol = 1e-9 + 1e-9 * fabs(b);
            if (fabs(a - b) > tol) { mismatch = 1; break; }
          }
          if (mismatch) break;
        }
      }
      // iterations equality is also part of correctness criteria
      if (!mismatch && it_parallel != it_serial) mismatch = 1;

      if (mismatch) {
        // If correctness is broken, still treat as failure but this harness primarily targets performance.
        verdict = 1;
      }

      // Performance verdict: memory-bottleneck should degrade efficiency at high threads.
      // Choose threshold conservative but sensitive.
      // For severe memory traffic overload, efficiency often drops well below ~0.4.
      double eff = (t_serial / t_parallel_best) / (double)best_t;
      if (eff < 0.35) {
        verdict = 1;
      }
    }
  }

  // Free
  free(points);
  free(assign_serial);
  free(assign_parallel);

  printf("[verdict] %s\n", verdict ? "PERF-01 exposed" : "PERF-01 not triggered");
  return verdict ? 1 : 0;
}
