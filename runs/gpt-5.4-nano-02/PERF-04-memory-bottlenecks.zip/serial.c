#include <stdint.h>
#include <stddef.h>
#include <math.h>

typedef struct {
  double x;
  double y;
} kmeans_point2d_t;

static uint64_t lcg_next_u64(uint64_t *state) {
  *state = (*state * 6364136223846793005ULL + 1442695040888963407ULL);
  return *state;
}

static double lcg_next_uniform_open01(uint64_t *state) {
  uint64_t s = lcg_next_u64(state);
  return (double)(s >> 11) * (1.0 / 9007199254740992.0); /* in [0,1) */
}

static void box_muller_pair(double *z0, double *z1, uint64_t *state) {
  /* Ensure u1 is in (0,1) to avoid log(0). */
  double u1 = lcg_next_uniform_open01(state);
  while (u1 == 0.0) {
    u1 = lcg_next_uniform_open01(state);
  }
  double u2 = lcg_next_uniform_open01(state);
  double r = sqrt(-2.0 * log(u1));
  double theta = 2.0 * 3.14159265358979323846 * u2;
  *z0 = r * cos(theta);
  *z1 = r * sin(theta);
}

void kmeans_assignment_recompute_converge_serial(
    int N,
    double centroids_out[64][2],
    int *assignments_out,
    int *iterations_out) {
  const int K = 64;

  kmeans_point2d_t *points = (kmeans_point2d_t *)malloc((size_t)N * sizeof(*points));
  if (!points) {
    /* Allocation failure: deterministic failure mode; harness should not trigger this. */
    return;
  }

  /* Generate 8 Gaussian mixture centers on a circle of radius 100. */
  const double R = 100.0;
  double cx[8];
  double cy[8];
  for (int c = 0; c < 8; ++c) {
    double ang = 2.0 * 3.14159265358979323846 * (double)c / 8.0;
    cx[c] = R * cos(ang);
    cy[c] = R * sin(ang);
  }

  uint64_t state = 123456789012345ULL;
  for (int i = 0; i < N; ++i) {
    double u = lcg_next_uniform_open01(&state);
    int g = (int)floor(8.0 * u);
    if (g < 0) g = 0;
    if (g > 7) g = 7;

    double z0, z1;
    box_muller_pair(&z0, &z1, &state);

    points[i].x = cx[g] + 10.0 * z0;
    points[i].y = cy[g] + 10.0 * z1;
  }

  /* Initialize centroids: take every (N/K)-th point, wrap if needed. */
  int step = N / K;
  if (step <= 0) step = 1;

  double centroids[64][2];
  for (int j = 0; j < K; ++j) {
    int idx = (int)(((int64_t)j * (int64_t)step) % (int64_t)N);
    centroids[j][0] = points[idx].x;
    centroids[j][1] = points[idx].y;
  }

  int *assignments = (int *)malloc((size_t)N * sizeof(*assignments));
  int *new_assignments = (int *)malloc((size_t)N * sizeof(*new_assignments));
  if (!assignments || !new_assignments) {
    free(points);
    free(assignments);
    free(new_assignments);
    return;
  }

  /* Initial assignment based on initial centroids. */
  for (int i = 0; i < N; ++i) {
    double px = points[i].x;
    double py = points[i].y;
    double best_d = -1.0;
    int best_j = 0;
    for (int j = 0; j < K; ++j) {
      double dx = px - centroids[j][0];
      double dy = py - centroids[j][1];
      double d = dx * dx + dy * dy;
      if (j == 0 || d < best_d) {
        best_d = d;
        best_j = j;
      }
    }
    assignments[i] = best_j;
  }

  int iterations = 0;
  for (;;) {
    /* Step 1: assign points to nearest centroid (based on current centroids). */
    int changed = 0;
    for (int i = 0; i < N; ++i) {
      double px = points[i].x;
      double py = points[i].y;
      double best_d = -1.0;
      int best_j = 0;
      for (int j = 0; j < K; ++j) {
        double dx = px - centroids[j][0];
        double dy = py - centroids[j][1];
        double d = dx * dx + dy * dy;
        if (j == 0 || d < best_d) {
          best_d = d;
          best_j = j;
        }
      }
      new_assignments[i] = best_j;
      if (best_j != assignments[i]) {
        changed = 1;
      }
    }

    /* Step 2: recompute centroids from new assignments. */
    double sum_x[64];
    double sum_y[64];
    int count[64];
    for (int j = 0; j < K; ++j) {
      sum_x[j] = 0.0;
      sum_y[j] = 0.0;
      count[j] = 0;
    }

    for (int i = 0; i < N; ++i) {
      int a = new_assignments[i];
      sum_x[a] += points[i].x;
      sum_y[a] += points[i].y;
      count[a] += 1;
    }

    for (int j = 0; j < K; ++j) {
      if (count[j] > 0) {
        centroids[j][0] = sum_x[j] / (double)count[j];
        centroids[j][1] = sum_y[j] / (double)count[j];
      }
    }

    /* Step 3: convergence check on assignments for this iteration. */
    iterations++;
    if (!changed) {
      /* Use new_assignments as final assignments (no change occurred). */
      for (int i = 0; i < N; ++i) assignments[i] = new_assignments[i];
      break;
    }

    /* Prepare for next iteration. */
    for (int i = 0; i < N; ++i) assignments[i] = new_assignments[i];
    /* Continue. */
  }

  for (int j = 0; j < K; ++j) {
    centroids_out[j][0] = centroids[j][0];
    centroids_out[j][1] = centroids[j][1];
  }
  for (int i = 0; i < N; ++i) {
    assignments_out[i] = assignments[i];
  }
  if (iterations_out) {
    *iterations_out = iterations;
  }

  free(points);
  free(assignments);
  free(new_assignments);
}
