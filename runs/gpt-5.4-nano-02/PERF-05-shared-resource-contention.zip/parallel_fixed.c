#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <omp.h>

static uint64_t splitmix64(uint64_t *state) {
    uint64_t z = (*state += 0x9E3779B97F4A7C15ULL);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
    return z ^ (z >> 31);
}

static uint64_t rng_u64(uint64_t *state) {
    return splitmix64(state);
}

static double rng_uniform01(uint64_t *state) {
    /* 53-bit precision double in [0,1) */
    uint64_t x = rng_u64(state);
    x >>= 11;
    return (double)x * (1.0 / 9007199254740992.0);
}

static void build_graph_csr(int N, int M, int *rowPtr, int *colIdx) {
    (void)M;

    int *deg = (int *)calloc((size_t)N, sizeof(int));
    if (!deg) return;

    const double alpha = 2.5;
    const double alpha_inv_lit = 1.0 - (1.0 / alpha);
    const double power = 1.0 / (1.0 - alpha_inv_lit);

    uint64_t rng_state = 123456789ULL;
    long long total_stubs = 0;
    long long target_stubs = 2LL * (long long)M;

    while (total_stubs < target_stubs) {
        double u = rng_uniform01(&rng_state);
        if (u < 0.0) u = 0.0;
        if (u >= 1.0) u = nextafter(1.0, 0.0);
        double x = u;
        double v_d;
        if (power == 1.0) {
            v_d = (double)N * x;
        } else {
            v_d = (double)N * pow(x, power);
        }
        if (v_d < 0.0) v_d = 0.0;
        if (v_d > (double)N - 1.0) v_d = (double)N - 1.0;
        int v = (int)v_d;
        deg[v] += 1;
        total_stubs += 1;
    }

    int k = 0;
    for (int i = 0; i < N; i++) {
        if (deg[i] == 0) { k = i; break; }
    }
    if (k > 0) {
        for (int i = 0; i <= k; i++) {
            if (deg[i] == 0) deg[i] = 1;
        }
    }

    long long stub_count = 0;
    for (int i = 0; i < N; i++) stub_count += (long long)deg[i];

    int *stubs = (int *)malloc((size_t)stub_count * sizeof(int));
    if (!stubs) {
        free(deg);
        return;
    }
    long long idx = 0;
    for (int i = 0; i < N; i++) {
        for (int t = 0; t < deg[i]; t++) {
            stubs[idx++] = i;
        }
    }

    rng_state = 987654321ULL;
    for (long long i = stub_count - 1; i > 0; i--) {
        uint64_t r = rng_u64(&rng_state);
        long long j = (long long)(r % (uint64_t)(i + 1));
        int tmp = stubs[i];
        stubs[i] = stubs[j];
        stubs[j] = tmp;
    }

    int *deg2 = (int *)calloc((size_t)N, sizeof(int));
    if (!deg2) {
        free(stubs);
        free(deg);
        return;
    }

    rng_state = 4242424242ULL;
    for (int e = 0; e < M; e++) {
        int a = stubs[2LL * e];
        int b = stubs[2LL * e + 1];
        while (b == a) {
            double u = rng_uniform01(&rng_state);
            double v_d;
            if (power == 1.0) {
                v_d = (double)N * u;
            } else {
                v_d = (double)N * pow(u, power);
            }
            if (v_d < 0.0) v_d = 0.0;
            if (v_d > (double)N - 1.0) v_d = (double)N - 1.0;
            b = (int)v_d;
        }
        deg2[a] += 1;
        deg2[b] += 1;
    }

    rowPtr[0] = 0;
    for (int i = 0; i < N; i++) {
        rowPtr[i + 1] = rowPtr[i] + deg2[i];
    }

    int *writePos = (int *)malloc((size_t)N * sizeof(int));
    if (!writePos) {
        free(deg2);
        free(stubs);
        free(deg);
        return;
    }
    for (int i = 0; i < N; i++) writePos[i] = rowPtr[i];

    rng_state = 4242424242ULL;
    for (int e = 0; e < M; e++) {
        int a = stubs[2LL * e];
        int b = stubs[2LL * e + 1];
        while (b == a) {
            double u = rng_uniform01(&rng_state);
            double v_d;
            if (power == 1.0) {
                v_d = (double)N * u;
            } else {
                v_d = (double)N * pow(u, power);
            }
            if (v_d < 0.0) v_d = 0.0;
            if (v_d > (double)N - 1.0) v_d = (double)N - 1.0;
            b = (int)v_d;
        }
        colIdx[writePos[a]++] = b;
        colIdx[writePos[b]++] = a;
    }

    free(writePos);
    free(deg2);
    free(stubs);
    free(deg);
}

void bfs_parent_hop_omp(int N, int M, int S, const int *sources, int *hop, int *parent) {
    int *rowPtr = (int *)malloc((size_t)(N + 1) * sizeof(int));
    int *colIdx = (int *)malloc((size_t)(2LL * M) * sizeof(int));
    if (!rowPtr || !colIdx) {
        free(rowPtr);
        free(colIdx);
        return;
    }

    build_graph_csr(N, M, rowPtr, colIdx);

    int *dist = (int *)malloc((size_t)N * sizeof(int));
    int *par = (int *)malloc((size_t)N * sizeof(int));
    int *queue = (int *)malloc((size_t)N * sizeof(int));
    int *nextq = (int *)malloc((size_t)N * sizeof(int));
    int *pos = (int *)malloc((size_t)N * sizeof(int));

    if (!dist || !par || !queue || !nextq || !pos) {
        free(pos);
        free(nextq);
        free(queue);
        free(par);
        free(dist);
        free(colIdx);
        free(rowPtr);
        return;
    }

    for (int si = 0; si < S; si++) {
        int src = sources[si];

        #pragma omp parallel for schedule(static)
        for (int v = 0; v < N; v++) {
            dist[v] = -1;
            par[v] = -1;
        }

        int qh = 0, qt = 0;
        dist[src] = 0;
        par[src] = -1;
        queue[qt++] = src;

        while (qh < qt) {
            int level = dist[queue[qh]];

            int level_end = qh;
            while (level_end < qt && dist[queue[level_end]] == level) level_end++;

            int next_size = 0;

            #pragma omp parallel for schedule(static)
            for (int idx = qh; idx < level_end; idx++) {
                int u = queue[idx];
                int du = dist[u];
                for (int ei = rowPtr[u]; ei < rowPtr[u + 1]; ei++) {
                    int v = colIdx[ei];
                    if (dist[v] == -1) {
                        int expected = -1;
                        /* ensure only first discovery wins and tie-breaking matches serial */
                        #pragma omp critical
                        {
                            if (dist[v] == expected) {
                                dist[v] = du + 1;
                                par[v] = u;
                                pos[v] = next_size++;
                                nextq[pos[v]] = v;
                            }
                        }
                    }
                }
            }

            qh = level_end;
            int old_qt = qt;
            (void)old_qt;

            #pragma omp parallel for schedule(static)
            for (int i = 0; i < next_size; i++) {
                queue[qt + i] = nextq[i];
            }
            qt += next_size;
        }

        int base = si * N;
        #pragma omp parallel for schedule(static)
        for (int v = 0; v < N; v++) {
            hop[base + v] = dist[v];
            parent[base + v] = par[v];
        }
    }

    free(pos);
    free(nextq);
    free(queue);
    free(par);
    free(dist);
    free(colIdx);
    free(rowPtr);
}
