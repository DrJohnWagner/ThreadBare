/* harness.c — scaling driver for bfs_parent_hop (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -lm -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <time.h>

// Forward declarations: must match serial.c / parallel.c exactly.
void bfs_parent_hop_serial(int N, int M, int S,
                            const int *sources,
                            int *hop, int *parent);
void bfs_parent_hop_omp(int N, int M, int S,
                       const int *sources,
                       int *hop, int *parent);

static uint64_t splitmix64(uint64_t *x) {
    uint64_t z = (*x += 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}

static double urand01(uint64_t *seed) {
    // [0,1)
    uint64_t r = splitmix64(seed);
    // Use 53 bits
    const double inv = 1.0 / (double)(1ULL << 53);
    return (double)(r >> 11) * inv;
}

static void generate_graph_csr(int N, int M,
                                int **out_rowPtr,
                                int **out_colIdx) {
    // This generator mirrors the deterministic procedure described in the spec.
    // It constructs CSR arrays for an undirected graph with M undirected edges.

    // Power-law-ish degree assignment:
    // alpha=2.5, alpha_inv = 1/alpha.
    const double alpha = 2.5;
    const double alpha_inv = 1.0 / alpha;
    const double beta = 1.0 / alpha_inv; // = alpha; used only in the spec's verbal description
    (void)beta;
    const int kmax = 1000;

    int *deg = (int*)calloc((size_t)N, sizeof(int));
    if (!deg) {
        fprintf(stderr, "alloc deg failed\n");
        exit(1);
    }

    // Seed fixed.
    uint64_t seed = 0x123456789abcdef0ULL;

    // total stubs = 2M*? Spec: for t=1..M*2 (stubs). Then deg increments per stub.
    // This yields sum(deg)=2*M.
    // For sampling v: v = floor(N * u^(1/(1-alpha_inv))) with u~U(0,1)
    // with clamp.
    // Compute exponent e = 1/(1-alpha_inv).
    double e = 1.0 / (1.0 - alpha_inv);

    long long totalStubs = 2LL * (long long)M;
    long long count = 0;
    while (count < totalStubs) {
        double u = urand01(&seed);
        double x = pow(u, e);
        long long v = (long long)floor((double)N * x);
        if (v < 0) v = 0;
        if (v > N - 1) v = N - 1;
        deg[v] += 1;
        count++;
    }

    // Remove isolated vertices by forcing deg[0..k] at least 1 if any deg[v]=0.
    // Interpret as: if any vertex in [0,kmax] is isolated, set those to 1.
    int k = kmax;
    if (k >= N) k = N - 1;
    for (int v = 0; v <= k; v++) {
        if (deg[v] == 0) deg[v] = 1;
    }

    // Build stubs array.
    long long sumDeg = 0;
    for (int i = 0; i < N; i++) sumDeg += deg[i];
    // After forcing deg[0..k] to at least 1, sumDeg may exceed 2M. Clamp to 2M stubs by truncation.
    // Determinism: truncate from the end of vertices in increasing id.
    if (sumDeg < 2LL * M) {
        fprintf(stderr, "Internal: sumDeg < 2M\n");
        free(deg);
        exit(1);
    }

    long long needStubs = 2LL * M;
    int *stubs = (int*)malloc((size_t)needStubs * sizeof(int));
    if (!stubs) {
        fprintf(stderr, "alloc stubs failed\n");
        free(deg);
        exit(1);
    }

    long long idx = 0;
    for (int v = 0; v < N && idx < needStubs; v++) {
        int d = deg[v];
        for (int r = 0; r < d && idx < needStubs; r++) {
            stubs[idx++] = v;
        }
    }
    free(deg);

    // Shuffle stubs deterministically with seeded Fisher-Yates.
    for (long long i = needStubs - 1; i > 0; i--) {
        uint64_t r = splitmix64(&seed);
        long long j = (long long)(r % (uint64_t)(i + 1));
        int tmp = stubs[i];
        stubs[i] = stubs[j];
        stubs[j] = tmp;
    }

    // Create edges endpoints by pairing stubs[2e], stubs[2e+1], resample second endpoint if self-loop.
    int *rowCount = (int*)calloc((size_t)N, sizeof(int));
    if (!rowCount) {
        fprintf(stderr, "alloc rowCount failed\n");
        free(stubs);
        exit(1);
    }

    // For symmetrized adjacency lists we will later fill CSR using 2M directed entries.
    // But the spec says colIdx[2M] and adds both directions for each undirected edge, so total directed entries = 2M.
    // Here we treat each pair as one undirected edge.

    for (int eidx = 0; eidx < M; eidx++) {
        int a = stubs[2LL*eidx];
        int b = stubs[2LL*eidx + 1];
        while (b == a) {
            double u = urand01(&seed);
            long long vv = (long long)floor((double)N * u);
            if (vv < 0) vv = 0;
            if (vv > N - 1) vv = N - 1;
            b = (int)vv;
        }
        rowCount[a]++;
        rowCount[b]++;
    }

    // Prefix sum offsets
    int *rowPtr = (int*)malloc((size_t)(N + 1) * sizeof(int));
    int totalAdj = 0;
    if (!rowPtr) {
        fprintf(stderr, "alloc rowPtr failed\n");
        free(rowCount);
        free(stubs);
        exit(1);
    }
    rowPtr[0] = 0;
    for (int v = 0; v < N; v++) {
        totalAdj += rowCount[v];
        rowPtr[v+1] = totalAdj;
    }

    // Spec expects exactly 2M entries.
    if (totalAdj != 2*M) {
        // In case truncation/isolated forcing changed counts, still proceed with actual totalAdj.
        // Parallel/serial kernels may assume CSR built internally; however those kernels in this benchmark
        // are given only N,M,S,sources and output hop/parent, so they must reconstruct the same graph.
        // Our harness only needs to drive kernels and timing; we don't pass CSR.
        // Therefore, this CSR generator is unused by kernels, but kept for spec completeness.
    }

    int *colIdx = (int*)malloc((size_t)totalAdj * sizeof(int));
    if (!colIdx) {
        fprintf(stderr, "alloc colIdx failed\n");
        free(rowPtr);
        free(rowCount);
        free(stubs);
        exit(1);
    }

    // Fill CSR with neighbor ids in deterministic order of edge processing.
    int *cursor = (int*)malloc((size_t)N * sizeof(int));
    memcpy(cursor, rowPtr, (size_t)N * sizeof(int));

    for (int eidx = 0; eidx < M; eidx++) {
        int a = stubs[2LL*eidx];
        int b = stubs[2LL*eidx + 1];
        while (b == a) {
            double u = urand01(&seed);
            long long vv = (long long)floor((double)N * u);
            if (vv < 0) vv = 0;
            if (vv > N - 1) vv = N - 1;
            b = (int)vv;
        }
        colIdx[cursor[a]++] = b;
        colIdx[cursor[b]++] = a;
    }

    free(cursor);
    free(rowCount);
    free(stubs);

    *out_rowPtr = rowPtr;
    *out_colIdx = colIdx;
}

static double wall_seconds(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

int main(int argc, char **argv) {
    int N = 310000;
    int M = 5000000;
    int S = 20;
    int maxThreadsOverride = -1;

    int repsWarmup = 1;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--n") == 0 && i+1 < argc) {
            int v = atoi(argv[++i]);
            if (v == 310000) N = 310000;
            else if (v == 5000000) M = 5000000; // allow sloppy usage
            else N = v;
        } else if (strcmp(argv[i], "--M") == 0 && i+1 < argc) {
            M = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--S") == 0 && i+1 < argc) {
            S = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--threads") == 0 && i+1 < argc) {
            maxThreadsOverride = atoi(argv[++i]);
        }
    }

    int *sources = (int*)malloc((size_t)S * sizeof(int));
    if (!sources) {
        fprintf(stderr, "alloc sources failed\n");
        return 2;
    }
    for (int s = 0; s < S; s++) {
        long long x = (long long)s * 9973LL + 12345LL;
        sources[s] = (int)(x % N);
    }

    int *hop_ref = (int*)malloc((size_t)N * sizeof(int));
    int *parent_ref = (int*)malloc((size_t)N * sizeof(int));
    int *hop_par = (int*)malloc((size_t)N * sizeof(int));
    int *parent_par = (int*)malloc((size_t)N * sizeof(int));
    if (!hop_ref || !parent_ref || !hop_par || !parent_par) {
        fprintf(stderr, "alloc outputs failed\n");
        return 2;
    }

    // Warmup: un-timed pass so cold-start costs are not attributed to serial baseline.
    bfs_parent_hop_omp(N, M, S, sources, hop_par, parent_par);
    for (int w = 1; w < repsWarmup; w++) bfs_parent_hop_omp(N, M, S, sources, hop_par, parent_par);

    // Serial timing.
    omp_set_num_threads(1);
    double t_serial_start = wall_seconds();
    bfs_parent_hop_serial(N, M, S, sources, hop_ref, parent_ref);
    double t_serial = wall_seconds() - t_serial_start;

    int maxThreads = omp_get_max_threads();
    if (maxThreadsOverride > 0 && maxThreadsOverride < maxThreads) maxThreads = maxThreadsOverride;

    // Light correctness check at thread count 1.
    omp_set_num_threads(1);
    bfs_parent_hop_omp(N, M, S, sources, hop_par, parent_par);
    // Compare elementwise.
    int ok = 1;
    for (int i = 0; i < N; i++) {
        if (hop_par[i] != hop_ref[i] || parent_par[i] != parent_ref[i]) {
            ok = 0;
            printf("[check] mismatch at idx=%d hop %d!=%d parent %d!=%d\n",
                   i, hop_par[i], hop_ref[i], parent_par[i], parent_ref[i]);
            break;
        }
    }

    // Scaling loop.
    double t_ref = t_serial;
    int testedMax = 1;
    double bestEff = 1e100;
    double bestSpeedup = 1.0;
    double bestEffHighT = 0.0;

    int t = 1;
    while (t <= maxThreads) {
        omp_set_num_threads(t);
        double ts = wall_seconds();
        bfs_parent_hop_omp(N, M, S, sources, hop_par, parent_par);
        double elapsed = wall_seconds() - ts;
        testedMax = t;

        double speedup = t_ref / elapsed;
        double eff = speedup / (double)t;

        printf("[scale] threads=%d time=%.6f speedup=%.3f eff=%.3f\n", t, elapsed, speedup, eff);

        if (t == maxThreads) bestEffHighT = eff;
        if (eff < bestEff) bestEff = eff;
        if (speedup > bestSpeedup) bestSpeedup = speedup;

        if (t == 1) t = 2; else t *= 2;
        if (t > maxThreads) t = maxThreads + 1;
    }

    // Verdict based on efficiency degradation at highest thread count.
    // For shared-resource-contention, expect significant slowdown: efficiency should be far below ideal (1.0).
    // Use a conservative but discriminative threshold.
    int failures = 0;
    double threshold = 0.12; // if eff < 0.12 at max threads, treat as contention failure.
    if (ok == 0) {
        // Even though this is a performance category, correctness failure would also be a strong signal.
        failures = 1;
    } else if (bestEffHighT > 0 && bestEffHighT < threshold) {
        failures = 1;
    }

    printf("[verdict] %s\n", failures ? "PERF-01 exposed" : "PERF-01 not triggered");

    free(sources);
    free(hop_ref);
    free(parent_ref);
    free(hop_par);
    free(parent_par);

    return failures ? 1 : 0;
}
