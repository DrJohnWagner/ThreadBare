#include <stdlib.h>
#include <stdint.h>
#include <string.h>

static uint64_t splitmix64(uint64_t *state) {
    uint64_t z = (*state += 0x9E3779B97F4A7C15ULL);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
    return z ^ (z >> 31);
}

static uint64_t rng_u64(uint64_t *state) {
    return splitmix64(state);
}

static double rng_uniform01(uint64_t *state) {
    /* 53-bit precision double in [0,1) */
    uint64_t x = rng_u64(state);
    x >>= 11;
    return (double)x * (1.0 / 9007199254740992.0);
}

static void build_graph_csr(int N, int M, int *rowPtr, int *colIdx) {
    const double alpha_inv = 1.0 - (1.0 / 2.5); /* not used directly; keep deterministic mapping via spec */
    (void)alpha_inv;

    int *deg = (int *)calloc((size_t)N, sizeof(int));
    if (!deg) return;

    const double u_exp = 1.0 / (1.0 - (1.0 / 2.5)); /* 1/(1-alpha_inv) with alpha_inv=1-1/2.5 */
    (void)u_exp;

    /* Spec details: sample v as v = floor(N * u^(1/(1-alpha_inv))).
       alpha_inv is implied by alpha=2.5: alpha_inv = 1/alpha? The spec is inconsistent,
       but we follow the literal formula structure using alpha=2.5 and
       alpha_inv = 1 - (1/alpha) used above. */
    const double alpha = 2.5;
    const double alpha_inv_lit = 1.0 - (1.0 / alpha);
    const double power = 1.0 / (1.0 - alpha_inv_lit);

    uint64_t rng_state = 123456789ULL;
    long long total_stubs = 0;
    long long target_stubs = 2LL * (long long)M;

    while (total_stubs < target_stubs) {
        double u = rng_uniform01(&rng_state);
        if (u < 0.0) u = 0.0;
        if (u >= 1.0) u = nextafter(1.0, 0.0);
        double x = u;
        double pw = 1.0;
        if (power != 1.0) pw = x;
        double v_d = (double)N * (power == 1.0 ? x : pow(x, power));
        if (v_d < 0.0) v_d = 0.0;
        if (v_d > (double)N - 1.0) v_d = (double)N - 1.0;
        int v = (int)v_d;
        deg[v] += 1;
        total_stubs += 1;
    }

    /* Remove isolated vertices by forcing deg[0..k] at least 1 if any deg[v]=0. */
    int k = 0;
    for (int i = 0; i < N; i++) {
        if (deg[i] == 0) { k = i; break; }
    }
    if (k > 0) {
        for (int i = 0; i <= k; i++) {
            if (deg[i] == 0) deg[i] = 1;
        }
    }

    /* Create stub list */
    long long stub_count = 0;
    for (int i = 0; i < N; i++) stub_count += (long long)deg[i];

    int *stubs = (int *)malloc((size_t)stub_count * sizeof(int));
    if (!stubs) {
        free(deg);
        return;
    }
    long long idx = 0;
    for (int i = 0; i < N; i++) {
        for (int t = 0; t < deg[i]; t++) {
            stubs[idx++] = i;
        }
    }

    /* Shuffle stubs deterministically with seeded Fisher–Yates */
    rng_state = 987654321ULL;
    for (long long i = stub_count - 1; i > 0; i--) {
        uint64_t r = rng_u64(&rng_state);
        long long j = (long long)(r % (uint64_t)(i + 1));
        int tmp = stubs[i];
        stubs[i] = stubs[j];
        stubs[j] = tmp;
    }

    /* Build undirected edge list in CSR by counting degrees first */
    /* We need to enforce no self-loops by resampling second endpoint using PRNG. */
    int *deg2 = (int *)calloc((size_t)N, sizeof(int));
    if (!deg2) {
        free(stubs);
        free(deg);
        return;
    }

    rng_state = 4242424242ULL;
    for (int e = 0; e < M; e++) {
        int a = stubs[2LL * e];
        int b = stubs[2LL * e + 1];
        while (b == a) {
            double u = rng_uniform01(&rng_state);
            double v_d = (double)N * pow(u, power);
            if (v_d < 0.0) v_d = 0.0;
            if (v_d > (double)N - 1.0) v_d = (double)N - 1.0;
            b = (int)v_d;
        }
        deg2[a] += 1;
        deg2[b] += 1;
    }

    rowPtr[0] = 0;
    for (int i = 0; i < N; i++) {
        rowPtr[i + 1] = rowPtr[i] + deg2[i];
    }
    int totalAdj = rowPtr[N];

    /* totalAdj should be 2M (symmetrized); but due to resampling it remains 2M. */
    (void)totalAdj;

    int *writePos = (int *)malloc((size_t)N * sizeof(int));
    if (!writePos) {
        free(deg2);
        free(stubs);
        free(deg);
        return;
    }
    for (int i = 0; i < N; i++) writePos[i] = rowPtr[i];

    rng_state = 4242424242ULL;
    for (int e = 0; e < M; e++) {
        int a = stubs[2LL * e];
        int b = stubs[2LL * e + 1];
        while (b == a) {
            double u = rng_uniform01(&rng_state);
            double v_d = (double)N * pow(u, power);
            if (v_d < 0.0) v_d = 0.0;
            if (v_d > (double)N - 1.0) v_d = (double)N - 1.0;
            b = (int)v_d;
        }
        colIdx[writePos[a]++] = b;
        colIdx[writePos[b]++] = a;
    }

    free(writePos);
    free(deg2);
    free(stubs);
    free(deg);
}

void bfs_parent_hop_serial(int N, int M, int S, const int *sources, int *hop, int *parent) {
    /* hop and parent are S x N flattened in row-major: hop[s*N + v] */
    int *rowPtr = (int *)malloc((size_t)(N + 1) * sizeof(int));
    int *colIdx = (int *)malloc((size_t)(2LL * M) * sizeof(int));
    if (!rowPtr || !colIdx) {
        free(rowPtr);
        free(colIdx);
        return;
    }

    build_graph_csr(N, M, rowPtr, colIdx);

    int *dist = (int *)malloc((size_t)N * sizeof(int));
    int *par = (int *)malloc((size_t)N * sizeof(int));
    int *queue = (int *)malloc((size_t)N * sizeof(int));

    if (!dist || !par || !queue) {
        free(queue);
        free(par);
        free(dist);
        free(colIdx);
        free(rowPtr);
        return;
    }

    for (int si = 0; si < S; si++) {
        int src = sources[si];

        for (int v = 0; v < N; v++) {
            dist[v] = -1;
            par[v] = -1;
        }

        int qh = 0, qt = 0;
        dist[src] = 0;
        par[src] = -1;
        queue[qt++] = src;

        while (qh < qt) {
            int u = queue[qh++];
            int du = dist[u];

            for (int ei = rowPtr[u]; ei < rowPtr[u + 1]; ei++) {
                int v = colIdx[ei];
                if (dist[v] == -1) {
                    dist[v] = du + 1;
                    par[v] = u;
                    queue[qt++] = v;
                }
            }
        }

        int base = si * N;
        for (int v = 0; v < N; v++) {
            hop[base + v] = dist[v];
            parent[base + v] = par[v];
        }
    }

    free(queue);
    free(par);
    free(dist);
    free(colIdx);
    free(rowPtr);
}
