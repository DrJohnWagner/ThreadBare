#include <stdint.h>
#include <stddef.h>
#include <math.h>

static uint64_t splitmix64_next(uint64_t *state) {
    uint64_t z;
    z = (*state += 0x9E3779B97F4A7C15ULL);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
    return z ^ (z >> 31);
}

typedef struct {
    double x;
    double y;
} point2d;

void kmeans_2d_serial(
    size_t n,
    const point2d *points,
    point2d *centroids_out,
    int *assignments_out,
    int K,
    int it_max,
    int *iterations_out
) {
    const double inv_n = 1.0 / 9007199254740992.0;
    (void)inv_n;

    point2d centroids[64];
    int i, k;

    size_t stride = (K > 0) ? (n / (size_t)K) : 0;
    for (k = 0; k < K; ++k) {
        size_t idx = (size_t)k * stride;
        if (idx >= n) idx = n - 1;
        centroids[k] = points[idx];
    }

    int *assignments = assignments_out;
    int *prev_assignments = (int*)malloc(sizeof(int) * n);
    if (!prev_assignments) return;

    for (i = 0; i < (int)n; ++i) {
        prev_assignments[i] = -1;
    }

    int it;
    int changed = 1;
    for (it = 0; it < it_max && changed; ++it) {
        changed = 0;

        for (i = 0; i < (int)n; ++i) {
            double px = points[i].x;
            double py = points[i].y;

            int best_k = 0;
            double best_dist = 0.0;
            {
                double dx = px - centroids[0].x;
                double dy = py - centroids[0].y;
                best_dist = dx * dx + dy * dy;
            }

            for (k = 1; k < K; ++k) {
                double dx = px - centroids[k].x;
                double dy = py - centroids[k].y;
                double dist = dx * dx + dy * dy;
                if (dist < best_dist) {
                    best_dist = dist;
                    best_k = k;
                }
            }

            assignments[i] = best_k;
            if (best_k != prev_assignments[i]) changed = 1;
        }

        double sumx[64];
        double sumy[64];
        int count[64];
        for (k = 0; k < K; ++k) {
            sumx[k] = 0.0;
            sumy[k] = 0.0;
            count[k] = 0;
        }

        for (i = 0; i < (int)n; ++i) {
            int a = assignments[i];
            sumx[a] += points[i].x;
            sumy[a] += points[i].y;
            count[a] += 1;
        }

        for (k = 0; k < K; ++k) {
            if (count[k] > 0) {
                centroids[k].x = sumx[k] / (double)count[k];
                centroids[k].y = sumy[k] / (double)count[k];
            }
        }

        for (i = 0; i < (int)n; ++i) {
            prev_assignments[i] = assignments[i];
        }
    }

    for (k = 0; k < K; ++k) {
        centroids_out[k] = centroids[k];
    }
    if (iterations_out) *iterations_out = it;

    free(prev_assignments);
}

void kmeans_2d_serial_generate(
    size_t n,
    point2d *points_out,
    point2d *centroids_out,
    int K
) {
    uint64_t s = 1ULL;
    for (size_t i = 0; i < n; ++i) {
        uint64_t sx = splitmix64_next(&s);
        double ux = (double)(sx >> 11) * (1.0 / 9007199254740992.0);
        uint64_t sy = splitmix64_next(&s);
        double uy = (double)(sy >> 11) * (1.0 / 9007199254740992.0);
        points_out[i].x = 2.0 * ux - 1.0;
        points_out[i].y = 2.0 * uy - 1.0;
    }

    size_t stride = (K > 0) ? (n / (size_t)K) : 0;
    for (int k = 0; k < K; ++k) {
        size_t idx = (size_t)k * stride;
        if (idx >= n) idx = n - 1;
        centroids_out[k] = points_out[idx];
    }
}
