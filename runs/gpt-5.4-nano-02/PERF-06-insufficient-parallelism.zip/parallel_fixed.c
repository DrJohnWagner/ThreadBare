#include <stdint.h>
#include <stddef.h>
#include <omp.h>

typedef struct {
    double x;
    double y;
} point2d;

void kmeans_2d_omp(
    size_t n,
    const point2d *points,
    point2d *centroids_out,
    int *assignments_out,
    int K,
    int it_max,
    int *iterations_out
) {
    const double inv_n = 1.0 / 9007199254740992.0;
    (void)inv_n;

    point2d centroids[64];

    size_t stride = (K > 0) ? (n / (size_t)K) : 0;
    for (int k = 0; k < K; ++k) {
        size_t idx = (size_t)k * stride;
        if (idx >= n) idx = n - 1;
        centroids[k] = points[idx];
    }

    int *assignments = assignments_out;
    int *prev_assignments = (int*)malloc(sizeof(int) * n);
    if (!prev_assignments) return;

    for (int i = 0; i < (int)n; ++i) {
        prev_assignments[i] = -1;
    }

    int it;
    int changed = 1;
    for (it = 0; it < it_max && changed; ++it) {
        changed = 0;

        #pragma omp parallel for schedule(static) reduction(|:changed)
        for (int i = 0; i < (int)n; ++i) {
            double px = points[i].x;
            double py = points[i].y;

            int best_k = 0;
            double best_dist = 0.0;
            {
                double dx = px - centroids[0].x;
                double dy = py - centroids[0].y;
                best_dist = dx * dx + dy * dy;
            }

            for (int k = 1; k < K; ++k) {
                double dx = px - centroids[k].x;
                double dy = py - centroids[k].y;
                double dist = dx * dx + dy * dy;
                if (dist < best_dist) {
                    best_dist = dist;
                    best_k = k;
                }
            }

            assignments[i] = best_k;
            if (best_k != prev_assignments[i]) changed = 1;
        }

        double sumx[64];
        double sumy[64];
        int count[64];
        for (int k = 0; k < K; ++k) {
            sumx[k] = 0.0;
            sumy[k] = 0.0;
            count[k] = 0;
        }

        #pragma omp parallel
        {
            double local_sumx[64];
            double local_sumy[64];
            int local_count[64];
            for (int k = 0; k < K; ++k) {
                local_sumx[k] = 0.0;
                local_sumy[k] = 0.0;
                local_count[k] = 0;
            }

            #pragma omp for schedule(static) nowait
            for (int i = 0; i < (int)n; ++i) {
                int a = assignments[i];
                local_sumx[a] += points[i].x;
                local_sumy[a] += points[i].y;
                local_count[a] += 1;
            }

            #pragma omp critical
            {
                for (int k = 0; k < K; ++k) {
                    sumx[k] += local_sumx[k];
                    sumy[k] += local_sumy[k];
                    count[k] += local_count[k];
                }
            }
        }

        for (int k = 0; k < K; ++k) {
            if (count[k] > 0) {
                centroids[k].x = sumx[k] / (double)count[k];
                centroids[k].y = sumy[k] / (double)count[k];
            }
        }

        #pragma omp parallel for schedule(static)
        for (int i = 0; i < (int)n; ++i) {
            prev_assignments[i] = assignments[i];
        }
    }

    for (int k = 0; k < K; ++k) {
        centroids_out[k] = centroids[k];
    }
    if (iterations_out) *iterations_out = it;

    free(prev_assignments);
}
