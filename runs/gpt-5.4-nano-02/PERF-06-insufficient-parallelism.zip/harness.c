/* harness.c — scaling driver for kmeans_2d (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#define _GNU_SOURCE
#include <omp.h>
#include <math.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct {
    double x;
    double y;
} point2d;

void kmeans_2d_serial(size_t n, const point2d *points, point2d *centroids_out,
                     int *assignments_out, int K, int it_max,
                     int *iterations_out);

void kmeans_2d_omp(size_t n, const point2d *points, point2d *centroids_out,
                   int *assignments_out, int K, int it_max,
                   int *iterations_out);

static uint64_t splitmix64(uint64_t *state) {
    uint64_t z = (*state += 0x9E3779B97f4A7C15ULL);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
    return z ^ (z >> 31);
}

static double now_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

static void gen_input(size_t n, point2d *points, int K) {
    uint64_t s = 1;
    const double inv = 1.0 / 9007199254740992.0; // 2^53

    for (size_t i = 0; i < n; i++) {
        // x
        s = splitmix64(&s);
        double ux = (double)(s >> 11) * inv; // in [0,1)
        // y
        s = splitmix64(&s);
        double uy = (double)(s >> 11) * inv;
        points[i].x = 2.0 * ux - 1.0;
        points[i].y = 2.0 * uy - 1.0;
    }

    // Initial centroids are derived inside the kernel from the point array (stride).
    (void)K;
}

static int parse_args(int argc, char **argv, size_t *n_out, int *reps_out) {
    size_t n = *n_out;
    int reps = *reps_out;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--n") && i + 1 < argc) {
            n = (size_t)strtoull(argv[++i], NULL, 10);
        } else if (!strcmp(argv[i], "--reps") && i + 1 < argc) {
            reps = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--help")) {
            fprintf(stderr, "Usage: %s [--n N] [--reps R]\n", argv[0]);
            exit(0);
        } else {
            fprintf(stderr, "Unknown arg: %s\n", argv[i]);
            return -1;
        }
    }
    *n_out = n;
    *reps_out = reps;
    return 0;
}

int main(int argc, char **argv) {
    size_t n = 1048576; // largest spec; chosen to expose performance degradation
    int reps = 10;       // only used for a light correctness check

    if (parse_args(argc, argv, &n, &reps) != 0) {
        return 2;
    }

    const int K = 64;
    const int it_max = 50;

    point2d *points = (point2d *)malloc(n * sizeof(point2d));
    point2d *cent_serial = (point2d *)malloc(K * sizeof(point2d));
    point2d *cent_omp = (point2d *)malloc(K * sizeof(point2d));
    int *assign_serial = (int *)malloc(n * sizeof(int));
    int *assign_omp = (int *)malloc(n * sizeof(int));
    int *iters_serial = (int *)malloc(sizeof(int));
    int *iters_omp = (int *)malloc(sizeof(int));

    if (!points || !cent_serial || !cent_omp || !assign_serial || !assign_omp || !iters_serial || !iters_omp) {
        fprintf(stderr, "Allocation failed\n");
        return 2;
    }

    gen_input(n, points, K);

    // Warmup (untimed) to reduce first-touch / initialization artifacts.
    kmeans_2d_serial(n, points, cent_serial, assign_serial, K, it_max, iters_serial);

    // Timed serial baseline
    double t_serial0 = now_sec();
    kmeans_2d_serial(n, points, cent_serial, assign_serial, K, it_max, iters_serial);
    double t_serial = now_sec() - t_serial0;

    // One light correctness check at the highest thread count (1 pass)
    // We'll also reuse the serial baseline results.
    int max_threads = omp_get_max_threads();
    int best_tcount = 1;
    double best_eff = 0.0;
    int failures = 0;

    // Build thread count list: 1,2,4,... up to max
    int *tcounts = (int *)malloc((size_t)(32) * sizeof(int));
    int tcount_len = 0;
    for (int t = 1; t <= max_threads; t <<= 1) {
        tcounts[tcount_len++] = t;
        if (t == max_threads) break;
    }
    if (tcount_len == 0) tcount_len = 1;

    for (int idx = 0; idx < tcount_len; idx++) {
        int t = tcounts[idx];
        omp_set_num_threads(t);

        double t0 = now_sec();
        kmeans_2d_omp(n, points, cent_omp, assign_omp, K, it_max, iters_omp);
        double t_par = now_sec() - t0;

        double speedup = (t_serial > 0.0) ? (t_serial / t_par) : 0.0;
        double eff = speedup / (double)t;

        printf("[scale] threads=%d time=%.6f speedup=%.3f eff=%.3f\n", t, t_par, speedup, eff);

        if (t == tcounts[tcount_len - 1]) {
            // Correctness check at highest tested thread count.
            // Compare centroids, assignments, and iteration count.
            if (*iters_omp != *iters_serial) {
                failures = 1;
            } else {
                // assignments (exact int match)
                for (size_t i = 0; i < n; i++) {
                    if (assign_omp[i] != assign_serial[i]) {
                        failures = 1;
                        break;
                    }
                }
                // centroids (bitwise/ exact double match expected per spec)
                if (!failures) {
                    for (int k = 0; k < K; k++) {
                        if (memcmp(&cent_omp[k], &cent_serial[k], sizeof(point2d)) != 0) {
                            failures = 1;
                            break;
                        }
                    }
                }
            }
        }

        if (eff > best_eff) {
            best_eff = eff;
            best_tcount = t;
        }

        if (idx == tcount_len - 1) {
            // Verdict based on efficiency at highest thread count tested.
            // The insufficient-parallelism failure should cause noticeable loss in efficiency.
            double eff_high = eff;
            // Threshold: require at least 0.30 efficiency at max threads; below means poor scaling.
            if (eff_high < 0.30) {
                // But avoid false positives if correctness is broken; that's safety, not performance.
                if (!failures) {
                    failures = 1;
                }
            }
        }
    }

    (void)reps;
    free(points);
    free(cent_serial);
    free(cent_omp);
    free(assign_serial);
    free(assign_omp);
    free(iters_serial);
    free(iters_omp);
    free(tcounts);

    // If failures==1 due to correctness mismatch, still count it as failure, but code prefix is performance.
    // Problem asks to demonstrate planted performance failure.
    printf("[verdict] %s\n", failures ? "PERF-01 exposed" : "PERF-01 not triggered");
    return failures ? 1 : 0;
}
