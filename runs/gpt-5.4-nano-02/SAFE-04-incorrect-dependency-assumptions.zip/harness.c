/* harness.c — differential driver for kmeans_2d_fixedk (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <omp.h>

// Forward declarations (must match real signatures exactly)
void kmeans_2d_fixedk_serial(uint32_t N, int *A, float *cx, float *cy);
void kmeans_2d_fixedk_omp(uint32_t N, int *A, float *cx, float *cy);

static void lcg_init(uint32_t *state) { *state = 123456789u; }
static uint32_t lcg_next_u32(uint32_t *s) {
    *s = 1664525u * (*s) + 1013904223u;
    return *s;
}
static float lcg_next_u01(uint32_t *s) {
    uint32_t u = lcg_next_u32(s);
    return (float)((u >> 8) * (1.0f / 16777216.0f));
}
static float lcg_next_n11(uint32_t *s) {
    float u = lcg_next_u01(s);
    return 2.0f * u - 1.0f;
}

static void generate_inputs(uint32_t N, int *A_init, float *cx_init, float *cy_init) {
    // Generate points deterministically, then sample K=64 initial centroids as specified.
    const uint32_t K = 64;

    // Latent centers constants
    const float centers[8][2] = {
        {-0.75f, -0.75f}, {-0.75f,  0.75f},
        { 0.75f, -0.75f}, { 0.75f,  0.75f},
        {-0.25f,  0.0f }, { 0.0f,   0.25f},
        { 0.25f,  0.0f }, { 0.0f,  -0.25f}
    };

    const float sigma = 0.10f;

    // We only need the points at the sampled indices for centroid initialization.
    // But since the sampling indices depend on N, simplest is to generate only those K points.
    // The spec: idx = (k * 2654435761u) mod N, and centroid[k] = point[idx].

    // We must advance PRNG exactly as the spec would while generating points in order.
    // Since generating only K points requires skipping PRNG values, we instead generate all points' needed
    // PRNG outputs by replaying generation but without storing all points.

    // Precompute target indices.
    uint32_t *targets = (uint32_t*)malloc(K * sizeof(uint32_t));
    if (!targets) { fprintf(stderr, "malloc failed\n"); exit(1); }
    for (uint32_t k = 0; k < K; k++) {
        targets[k] = (uint32_t)((uint64_t)k * 2654435761u % (uint64_t)N);
    }

    // Mark which centroid slot each target index corresponds to (there can be duplicates only if N small,
    // but with K=64 and N>=200000 duplicates are impossible).
    // We'll build a small mapping by linear search per i (cheap compared to assignment correctness check).

    uint32_t state;
    lcg_init(&state);

    // Iterate through point generation i=0..N-1, but only compute/store when i matches a target.
    for (uint32_t i = 0; i < N; i++) {
        // u1 determines latent cluster c in [0,8)
        float u1 = lcg_next_u01(&state);
        uint32_t c = (uint32_t)floorf(u1 * 8.0f);
        // Two independent noise values mapped to [-1,1]
        float n1 = lcg_next_n11(&state);
        float n2 = lcg_next_n11(&state);

        // Determine if this point is needed for some centroid.
        for (uint32_t k = 0; k < K; k++) {
            if (targets[k] == i) {
                cx_init[k] = centers[c][0] + sigma * n1;
                cy_init[k] = centers[c][1] + sigma * n2;
            }
        }
    }

    free(targets);

    // Initialize A to something deterministic (the kernel likely ignores A initial values for the
    // first iteration, but we pass an array anyway).
    for (uint32_t i = 0; i < N; i++) {
        A_init[i] = (int)(i % 64u);
    }
}

static int parse_args(int argc, char **argv, uint32_t *N, int *reps) {
    *N = 1000000u; // largest in spec
    *reps = 25;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            *N = (uint32_t)strtoul(argv[++i], NULL, 10);
        } else if (strcmp(argv[i], "--reps") == 0 && i + 1 < argc) {
            *reps = (int)strtol(argv[++i], NULL, 10);
        } else {
            fprintf(stderr, "Unknown/invalid arg: %s\n", argv[i]);
            return 0;
        }
    }
    return 1;
}

int main(int argc, char **argv) {
    uint32_t N;
    int reps;
    if (!parse_args(argc, argv, &N, &reps)) return 2;

    const uint32_t K = 64;

    int *A_ref = (int*)malloc((size_t)N * sizeof(int));
    int *A_par = (int*)malloc((size_t)N * sizeof(int));
    float *cx_ref = (float*)malloc((size_t)K * sizeof(float));
    float *cy_ref = (float*)malloc((size_t)K * sizeof(float));
    float *cx_par = (float*)malloc((size_t)K * sizeof(float));
    float *cy_par = (float*)malloc((size_t)K * sizeof(float));

    if (!A_ref || !A_par || !cx_ref || !cy_ref || !cx_par || !cy_par) {
        fprintf(stderr, "malloc failed\n");
        return 2;
    }

    // Generate deterministic centroid initialization (cx/cy) and initial A buffer.
    // The kernels are passed A, cx, cy; we compare their final outputs.
    generate_inputs(N, A_ref, cx_ref, cy_ref);

    // Serial reference (ground truth)
    memcpy(A_par, A_ref, (size_t)N * sizeof(int));
    memcpy(cx_par, cx_ref, (size_t)K * sizeof(float));
    memcpy(cy_par, cy_ref, (size_t)K * sizeof(float));

    kmeans_2d_fixedk_serial(N, A_ref, cx_ref, cy_ref);

    int failures = 0;

    // Differential check across repetitions
    for (int r = 0; r < reps && !failures; r++) {
        // Reset inputs to the same initial state each repetition.
        memcpy(A_par, A_ref, (size_t)N * sizeof(int));
        memcpy(cx_par, cx_ref, (size_t)K * sizeof(float));
        memcpy(cy_par, cy_ref, (size_t)K * sizeof(float));

        // But above we overwrote cx_ref/cy_ref with serial results.
        // Need to regenerate original initial centroids and A before calling parallel each time.
        // We'll do it by regenerating into temporaries once per repetition.
        // (Still deterministic, and keeps signatures independent.)
        //
        // To do this cleanly, regenerate into cx_par/cy_par and A_par, then run parallel.

        // Regenerate initial state
        // (A_ref currently holds serial final assignments; we need a fresh initial A)
        // We'll regenerate into A_par/cx_par/cy_par.
        generate_inputs(N, A_par, cx_par, cy_par);

        kmeans_2d_fixedk_omp(N, A_par, cx_par, cy_par);

        // Compare against reference
        for (uint32_t i = 0; i < N; i++) {
            if (A_par[i] != A_ref[i]) {
                printf("[check] rep=%d first assignment mismatch at i=%u: par=%d ref=%d\n",
                       r, i, A_par[i], A_ref[i]);
                failures = 1;
                break;
            }
        }
        if (failures) break;

        const float tol = 1e-5f;
        for (uint32_t k = 0; k < K && !failures; k++) {
            float dx = fabsf(cx_par[k] - cx_ref[k]);
            float dy = fabsf(cy_par[k] - cy_ref[k]);
            if (dx > tol || dy > tol) {
                printf("[check] rep=%d centroid mismatch at k=%u: "
                       "par=(%g,%g) ref=(%g,%g) diff=(%g,%g)\n",
                       r, k, (double)cx_par[k], (double)cy_par[k],
                       (double)cx_ref[k], (double)cy_ref[k], (double)dx, (double)dy);
                failures = 1;
                break;
            }
        }
    }

    printf("[verdict] %s\n", failures ? "SAFE-01 exposed" : "SAFE-01 not triggered");

    free(A_ref); free(A_par);
    free(cx_ref); free(cy_ref); free(cx_par); free(cy_par);
    return failures ? 1 : 0;
}
