#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <omp.h>

static inline uint32_t lcg_next_u32(uint32_t *s) {
    *s = (*s) * 1664525u + 1013904223u;
    return *s;
}

static inline float u32_to_unit_f(uint32_t u) {
    return (float)(u >> 8) * (1.0f / 16777216.0f);
}

static inline void prng_points_2d(uint32_t N, float sigma, float *pts_x, float *pts_y) {
    uint32_t s = 123456789u;

    const float centers_x[8] = {-0.75f, -0.75f, 0.75f, 0.75f, -0.25f, 0.0f, 0.25f, 0.0f};
    const float centers_y[8] = {-0.75f, 0.75f, -0.75f, 0.75f, 0.0f, 0.25f, 0.0f, -0.25f};

    for (uint32_t i = 0; i < N; ++i) {
        uint32_t r1 = lcg_next_u32(&s);
        float u1 = u32_to_unit_f(r1);
        uint32_t c = (uint32_t)(u1 * 8.0f);
        if (c > 7u) c = 7u;

        uint32_t r2 = lcg_next_u32(&s);
        float u2 = u32_to_unit_f(r2);
        float n1 = 2.0f * u2 - 1.0f;

        uint32_t r3 = lcg_next_u32(&s);
        float u3 = u32_to_unit_f(r3);
        float n2 = 2.0f * u3 - 1.0f;

        pts_x[i] = centers_x[c] + sigma * n1;
        pts_y[i] = centers_y[c] + sigma * n2;
    }
}

void kmeans_2d_fixedk_omp(uint32_t N, int *A, float *cx, float *cy) {
    enum { K = 64 };

    float *pts_x = (float *)malloc((size_t)N * sizeof(float));
    float *pts_y = (float *)malloc((size_t)N * sizeof(float));
    int *A_prev = (int *)malloc((size_t)N * sizeof(int));
    float *new_cx = (float *)malloc((size_t)K * sizeof(float));
    float *new_cy = (float *)malloc((size_t)K * sizeof(float));
    uint32_t *counts = (uint32_t *)malloc((size_t)K * sizeof(uint32_t));

    if (!pts_x || !pts_y || !A_prev || !new_cx || !new_cy || !counts) {
        free(pts_x);
        free(pts_y);
        free(A_prev);
        free(new_cx);
        free(new_cy);
        free(counts);
        return;
    }

    prng_points_2d(N, 0.10f, pts_x, pts_y);

    for (uint32_t k = 0; k < (uint32_t)K; ++k) {
        uint32_t idx = (uint32_t)(((uint64_t)k * 2654435761u) % (uint64_t)N);
        cx[k] = pts_x[idx];
        cy[k] = pts_y[idx];
    }

    #pragma omp parallel for schedule(static)
    for (uint32_t i = 0; i < N; ++i) {
        A_prev[i] = -1;
    }

    for (;;) {
        uint32_t changed = 0;

        #pragma omp parallel
        {
            uint32_t local_changed = 0;

            #pragma omp for schedule(static)
            for (uint32_t i = 0; i < N; ++i) {
                float x = pts_x[i];
                float y = pts_y[i];

                float best_d = 0.0f;
                int best_k = 0;

                for (uint32_t k = 0; k < (uint32_t)K; ++k) {
                    float dx = x - cx[k];
                    float dy = y - cy[k];
                    float d = dx * dx + dy * dy;
                    if (k == 0u || d < best_d) {
                        best_d = d;
                        best_k = (int)k;
                    }
                }

                A[i] = best_k;
                if (A_prev[i] != best_k) local_changed = 1;
            }

            #pragma omp atomic
            changed |= local_changed;
        }

        if (!changed) {
            break;
        }

        #pragma omp parallel for schedule(static)
        for (uint32_t k = 0; k < (uint32_t)K; ++k) {
            new_cx[k] = 0.0f;
            new_cy[k] = 0.0f;
            counts[k] = 0u;
        }

        #pragma omp parallel
        {
            float local_new_cx[K];
            float local_new_cy[K];
            uint32_t local_counts[K];

            for (uint32_t k = 0; k < (uint32_t)K; ++k) {
                local_new_cx[k] = 0.0f;
                local_new_cy[k] = 0.0f;
                local_counts[k] = 0u;
            }

            #pragma omp for schedule(static)
            for (uint32_t i = 0; i < N; ++i) {
                int k = A[i];
                local_new_cx[(uint32_t)k] += pts_x[i];
                local_new_cy[(uint32_t)k] += pts_y[i];
                local_counts[(uint32_t)k] += 1u;
            }

            #pragma omp critical
            {
                for (uint32_t k = 0; k < (uint32_t)K; ++k) {
                    new_cx[k] += local_new_cx[k];
                    new_cy[k] += local_new_cy[k];
                    counts[k] += local_counts[k];
                }
            }
        }

        #pragma omp parallel for schedule(static)
        for (uint32_t k = 0; k < (uint32_t)K; ++k) {
            if (counts[k] != 0u) {
                cx[k] = new_cx[k] / (float)counts[k];
                cy[k] = new_cy[k] / (float)counts[k];
            }
        }

        #pragma omp parallel for schedule(static)
        for (uint32_t i = 0; i < N; ++i) {
            A_prev[i] = A[i];
        }
    }

    free(pts_x);
    free(pts_y);
    free(A_prev);
    free(new_cx);
    free(new_cy);
    free(counts);
}
