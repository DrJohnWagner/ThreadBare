/* harness.c — differential driver for kmeans_2d (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

typedef void (*kmeans_fn)(size_t N, size_t K, int max_iters,
                          float *points_x, float *points_y,
                          int *assignments_out,
                          float *centroids_x_out, float *centroids_y_out);

static uint32_t lcg_next(uint32_t s) {
    return (uint32_t)(1664525u * s + 1013904223u);
}

static void generate_input(size_t N, size_t K, float *px, float *py,
                            int *expected_centroids_ix, float *expected_cx, float *expected_cy) {
    (void)K;
    uint32_t s = 123456789u;

    for (size_t i = 0; i < N; i++) {
        s = lcg_next(s);
        double u_cluster = (double)s / 4294967296.0; // in [0,1)

        double center_x, center_y;
        if (u_cluster < 0.25) { center_x = -5.0; center_y = -5.0; }
        else if (u_cluster < 0.5) { center_x = 5.0; center_y = -5.0; }
        else if (u_cluster < 0.75) { center_x = -5.0; center_y = 5.0; }
        else { center_x = 5.0; center_y = 5.0; }

        s = lcg_next(s);
        double u1 = (double)s / 4294967296.0;
        s = lcg_next(s);
        double u2 = (double)s / 4294967296.0;

        px[i] = (float)(center_x + (u1 - 0.5) * 1.5);
        py[i] = (float)(center_y + (u2 - 0.5) * 1.5);
    }

    // Deterministic initial centroids from point set using stride.
    // Reference algorithm should do this internally, but harness needs a max_iters
    // consistent with behavior. Still, we generate for possible sanity checks.
    for (size_t j = 0; j < K; j++) {
        uint64_t idx = (uint64_t)j * 2654435761ULL;
        size_t pidx = (size_t)(idx % (uint64_t)N);
        if (expected_centroids_ix) expected_centroids_ix[j] = (int)pidx;
        expected_cx[j] = px[pidx];
        expected_cy[j] = py[pidx];
    }
}

static int outputs_match(size_t N, size_t K,
                           const int *a1, const float *cx1, const float *cy1,
                           const int *a2, const float *cx2, const float *cy2) {
    for (size_t i = 0; i < N; i++) {
        if (a1[i] != a2[i]) return 0;
    }
    for (size_t j = 0; j < K; j++) {
        if (cx1[j] != cx2[j]) return 0;
        if (cy1[j] != cy2[j]) return 0;
    }
    return 1;
}

int main(int argc, char **argv) {
    size_t N = 1000000;
    size_t K = 64;
    int max_iters = 100; // shared cap to avoid runaway; reference+parallel should stop earlier if terminating.
    int reps = 20;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            N = (size_t)strtoull(argv[++i], NULL, 10);
        } else if (strcmp(argv[i], "--reps") == 0 && i + 1 < argc) {
            reps = (int)strtol(argv[++i], NULL, 10);
        } else if (strcmp(argv[i], "--max_iters") == 0 && i + 1 < argc) {
            max_iters = (int)strtol(argv[++i], NULL, 10);
        } else {
            fprintf(stderr, "Unknown/ignored arg: %s\n", argv[i]);
        }
    }

    float *points_x = (float*)malloc(N * sizeof(float));
    float *points_y = (float*)malloc(N * sizeof(float));
    int *a_ref = (int*)malloc(N * sizeof(int));
    int *a_par = (int*)malloc(N * sizeof(int));
    float *cx_ref = (float*)malloc(K * sizeof(float));
    float *cy_ref = (float*)malloc(K * sizeof(float));
    float *cx_par = (float*)malloc(K * sizeof(float));
    float *cy_par = (float*)malloc(K * sizeof(float));
    float *cx_init = (float*)malloc(K * sizeof(float));
    float *cy_init = (float*)malloc(K * sizeof(float));
    int *ix_init = (int*)malloc(K * sizeof(int));

    if (!points_x || !points_y || !a_ref || !a_par || !cx_ref || !cy_ref || !cx_par || !cy_par || !cx_init || !cy_init || !ix_init) {
        fprintf(stderr, "Allocation failure\n");
        return 2;
    }

    generate_input(N, K, points_x, points_y, ix_init, cx_init, cy_init);

    // Forward declarations matching linkage.
    extern void kmeans_2d_serial(size_t N, size_t K, int max_iters,
                                float *points_x, float *points_y,
                                int *assignments_out,
                                float *centroids_x_out, float *centroids_y_out);
    extern void kmeans_2d_omp(size_t N, size_t K, int max_iters,
                             float *points_x, float *points_y,
                             int *assignments_out,
                             float *centroids_x_out, float *centroids_y_out);

    kmeans_fn serial_fn = kmeans_2d_serial;
    kmeans_fn par_fn = kmeans_2d_omp;

    serial_fn(N, K, max_iters, points_x, points_y, a_ref, cx_ref, cy_ref);

    int failures = 0;
    for (int r = 0; r < reps; r++) {
        memset(a_par, 0, N * sizeof(int));
        par_fn(N, K, max_iters, points_x, points_y, a_par, cx_par, cy_par);

        // Compare and print first divergence point.
        int mismatch_found = 0;
        for (size_t i = 0; i < N && !mismatch_found; i++) {
            if (a_ref[i] != a_par[i]) {
                printf("[check] rep=%d first mismatch assignment at i=%zu ref=%d par=%d\n",
                       r, i, a_ref[i], a_par[i]);
                mismatch_found = 1;
            }
        }
        if (!mismatch_found) {
            for (size_t j = 0; j < K; j++) {
                if (cx_ref[j] != cx_par[j] || cy_ref[j] != cy_par[j]) {
                    printf("[check] rep=%d first mismatch centroid at j=%zu ref=(%g,%g) par=(%g,%g)\n",
                           r, j,
                           (double)cx_ref[j], (double)cy_ref[j],
                           (double)cx_par[j], (double)cy_par[j]);
                    mismatch_found = 1;
                    break;
                }
            }
        }

        if (mismatch_found) {
            failures = 1;
            break;
        }
    }

    free(points_x);
    free(points_y);
    free(a_ref);
    free(a_par);
    free(cx_ref);
    free(cy_ref);
    free(cx_par);
    free(cy_par);
    free(cx_init);
    free(cy_init);
    free(ix_init);

    printf("[verdict] %s\n", failures ? "SAFE-01 exposed" : "SAFE-01 not triggered");
    return failures ? 1 : 0;
}
