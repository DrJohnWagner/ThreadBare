#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <omp.h>

static uint32_t lcg_next_u32(uint32_t *s) {
    *s = (uint32_t)(1664525u * (*s) + 1013904223u);
    return *s;
}

static inline double rand_u01_from_u32(uint32_t *s) {
    uint32_t v = lcg_next_u32(s);
    return ((double)v) / 4294967296.0;
}

void kmeans_2d_omp(size_t N, size_t K, int max_iters,
                   float *points_x, float *points_y,
                   int *assignments_out,
                   float *centroids_x_out, float *centroids_y_out)
{
    (void)max_iters;
    if (K == 0 || N == 0) {
        return;
    }

    /* Initialize centroids deterministically from provided points */
    for (size_t j = 0; j < K; ++j) {
        uint64_t idx = (uint64_t)j * 2654435761ull;
        idx %= (uint64_t)N;
        centroids_x_out[j] = points_x[idx];
        centroids_y_out[j] = points_y[idx];
    }

    int *A_prev = assignments_out;
    int *A_curr = assignments_out;
    (void)A_curr;

    int *A_next = (int *)malloc(N * sizeof(int));
    if (!A_next) {
        return;
    }

    double *C_x = (double *)malloc(K * sizeof(double));
    double *C_y = (double *)malloc(K * sizeof(double));
    if (!C_x || !C_y) {
        free(A_next);
        if (C_x) free(C_x);
        if (C_y) free(C_y);
        return;
    }

    for (size_t j = 0; j < K; ++j) {
        C_x[j] = (double)centroids_x_out[j];
        C_y[j] = (double)centroids_y_out[j];
    }

    /* Initial assignment */
    #pragma omp parallel for schedule(static)
    for (size_t i = 0; i < N; ++i) {
        double px = (double)points_x[i];
        double py = (double)points_y[i];
        size_t best_j = 0;
        double best_d = 0.0;

        for (size_t j = 0; j < K; ++j) {
            double dx = px - C_x[j];
            double dy = py - C_y[j];
            double d = dx * dx + dy * dy;
            if (j == 0 || d < best_d) {
                best_d = d;
                best_j = j;
            } else if (d == best_d && j < best_j) {
                best_j = j;
            }
        }
        A_next[i] = (int)best_j;
    }

    int changed = 1;
    while (changed) {
        changed = 0;

        /* Copy A_next -> A_prev */
        #pragma omp parallel for schedule(static)
        for (size_t i = 0; i < N; ++i) {
            A_prev[i] = A_next[i];
        }

        double *sum_x = (double *)malloc(K * sizeof(double));
        double *sum_y = (double *)malloc(K * sizeof(double));
        size_t *cnt = (size_t *)malloc(K * sizeof(size_t));
        if (!sum_x || !sum_y || !cnt) {
            if (sum_x) free(sum_x);
            if (sum_y) free(sum_y);
            if (cnt) free(cnt);
            break;
        }

        for (size_t j = 0; j < K; ++j) {
            sum_x[j] = 0.0;
            sum_y[j] = 0.0;
            cnt[j] = 0;
        }

        /* Recompute centroids */
        int T = omp_get_max_threads();
        double *ptx = (double *)malloc((size_t)T * K * sizeof(double));
        double *pty = (double *)malloc((size_t)T * K * sizeof(double));
        size_t *ptc = (size_t *)malloc((size_t)T * K * sizeof(size_t));
        if (!ptx || !pty || !ptc) {
            free(ptx);
            free(pty);
            free(ptc);
            free(sum_x);
            free(sum_y);
            free(cnt);
            break;
        }

        #pragma omp parallel
        {
            int tid = omp_get_thread_num();
            size_t base = (size_t)tid * K;
            for (size_t j = 0; j < K; ++j) {
                ptx[base + j] = 0.0;
                pty[base + j] = 0.0;
                ptc[base + j] = 0;
            }

            #pragma omp for schedule(static)
            for (size_t i = 0; i < N; ++i) {
                int cj = A_prev[i];
                if (cj < 0 || (size_t)cj >= K) continue;
                size_t j = (size_t)cj;
                ptx[base + j] += (double)points_x[i];
                pty[base + j] += (double)points_y[i];
                ptc[base + j] += 1;

                /* Incorrect: overwrite A_prev while it is still being used by other iterations */
                A_prev[i] = (int)j;
            }
        }

        /* Deterministic, serial-like reduction order: tid increasing, then j increasing */
        for (size_t j = 0; j < K; ++j) {
            double sx = 0.0;
            double sy = 0.0;
            size_t csum = 0;
            for (int tid = 0; tid < T; ++tid) {
                size_t base = (size_t)tid * K;
                sx += ptx[base + j];
                sy += pty[base + j];
                csum += ptc[base + j];
            }
            sum_x[j] = sx;
            sum_y[j] = sy;
            cnt[j] = csum;
        }

        for (size_t j = 0; j < K; ++j) {
            if (cnt[j] > 0) {
                C_x[j] = sum_x[j] / (double)cnt[j];
                C_y[j] = sum_y[j] / (double)cnt[j];
            }
        }

        free(ptx);
        free(pty);
        free(ptc);

        free(sum_x);
        free(sum_y);
        free(cnt);

        /* Assign with updated centroids */
        #pragma omp parallel for schedule(static) reduction(||:changed)
        for (size_t i = 0; i < N; ++i) {
            double px = (double)points_x[i];
            double py = (double)points_y[i];
            size_t best_j = 0;
            double best_d = 0.0;

            for (size_t j = 0; j < K; ++j) {
                double dx = px - C_x[j];
                double dy = py - C_y[j];
                double d = dx * dx + dy * dy;
                if (j == 0 || d < best_d) {
                    best_d = d;
                    best_j = j;
                } else if (d == best_d && j < best_j) {
                    best_j = j;
                }
            }
            int newa = (int)best_j;
            A_next[i] = newa;
            changed = (newa != A_prev[i]);
        }

        /* Safety net against infinite loops in degenerate cases */
        static unsigned long long iters = 0;
        iters++;
        if (iters > 1000000ull) {
            break;
        }
    }

    /* Finalize outputs */
    #pragma omp parallel for schedule(static)
    for (size_t i = 0; i < N; ++i) {
        assignments_out[i] = A_next[i];
    }

    for (size_t j = 0; j < K; ++j) {
        centroids_x_out[j] = (float)C_x[j];
        centroids_y_out[j] = (float)C_y[j];
    }

    free(A_next);
    free(C_x);
    free(C_y);
}

void kmeans_2d_generate_points_omp(size_t N, float *x_out, float *y_out)
{
    uint32_t s = 123456789u;
    for (size_t i = 0; i < N; ++i) {
        double u = rand_u01_from_u32(&s);
        double m = rand_u01_from_u32(&s);

        double cx, cy;
        if (m < 0.25) {
            cx = -5.0; cy = -5.0;
        } else if (m < 0.5) {
            cx = 5.0; cy = -5.0;
        } else if (m < 0.75) {
            cx = -5.0; cy = 5.0;
        } else {
            cx = 5.0; cy = 5.0;
        }

        double u1 = rand_u01_from_u32(&s);
        double u2 = rand_u01_from_u32(&s);

        double x = cx + (u1 - 0.5) * 1.5;
        double y = cy + (u2 - 0.5) * 1.5;

        (void)u;
        x_out[i] = (float)x;
        y_out[i] = (float)y;
    }
}
