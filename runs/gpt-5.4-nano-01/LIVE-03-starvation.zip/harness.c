/* harness.c — timeout driver for bfs_parent_distance (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>
#include <time.h>
#include <signal.h>
#include <unistd.h>

// Forward declarations matching the real signatures.
void bfs_parent_distance_serial(int32_t *distance_out,
                                int32_t *parent_out,
                                uint32_t n,
                                uint32_t m,
                                uint32_t S,
                                uint32_t Kmax);

void bfs_parent_distance_serial_omp(int32_t *distance_out,
                                     int32_t *parent_out,
                                     uint32_t n,
                                     uint32_t m,
                                     uint32_t S,
                                     uint32_t Kmax);

static volatile sig_atomic_t g_timed_out = 0;
static void alarm_handler(int sig) {
    (void)sig;
    g_timed_out = 1;
}

static uint64_t lcg_step(uint64_t s) {
    return (6364136223846793005ULL * s + 1ULL);
}

static uint32_t rand_u32_lcg(uint64_t *state) {
    *state = lcg_step(*state);
    return (uint32_t)(*state >> 32);
}

// Returns an integer k in [1..Kmax] via the spec's "geometric-like" sampling.
static uint32_t sample_k(uint64_t *state, uint32_t Kmax) {
    // Choose k as smallest such that rand()%2==0 after at most Kmax trials.
    for (uint32_t trials = 1; trials <= Kmax; trials++) {
        uint32_t r = rand_u32_lcg(state);
        if ((r & 1U) == 0U) return trials;
    }
    return Kmax;
}

// Deterministically generate sources and graph parameters; the BFS kernels
// are expected to generate the same graph internally based on n, m, S, Kmax.
// We still select S sources deterministically for our buffers, though the
// kernels themselves generate and use their own sources consistent with n,m,S.

int main(int argc, char **argv) {
    uint32_t n = 310000; // default: largest in spec that's likely to show liveness failure quickly
    uint32_t m = 5000000;
    uint32_t S = 20;
    uint32_t Kmax = 50;
    int timeout_sec = 5; // wall-clock timeout for the parallel kernel

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            n = (uint32_t)strtoul(argv[++i], NULL, 10);
        } else if (strcmp(argv[i], "--timeout") == 0 && i + 1 < argc) {
            timeout_sec = (int)strtol(argv[++i], NULL, 10);
        } else if (strcmp(argv[i], "--threads") == 0 && i + 1 < argc) {
            omp_set_num_threads((int)strtol(argv[++i], NULL, 10));
        } else {
            fprintf(stderr, "Usage: %s [--n N] [--timeout SEC] [--threads T]\n", argv[0]);
            return 1;
        }
    }

    size_t total = (size_t)S * (size_t)n;
    int32_t *dist_serial = (int32_t *)malloc(total * sizeof(int32_t));
    int32_t *par_serial  = (int32_t *)malloc(total * sizeof(int32_t));
    int32_t *dist_par    = (int32_t *)malloc(total * sizeof(int32_t));
    int32_t *par_par     = (int32_t *)malloc(total * sizeof(int32_t));
    if (!dist_serial || !par_serial || !dist_par || !par_par) {
        fprintf(stderr, "Allocation failed for n=%u S=%u\n", n, S);
        free(dist_serial); free(par_serial); free(dist_par); free(par_par);
        return 1;
    }

    // Compute reference once so any issues with graph semantics are surfaced,
    // but don't overrun our timeout budget.
    bfs_parent_distance_serial(dist_serial, par_serial, n, m, S, Kmax);

    // Run the parallel kernel under a hard wall-clock timeout.
    g_timed_out = 0;
    signal(SIGALRM, alarm_handler);
    alarm(timeout_sec);

    bfs_parent_distance_serial_omp(dist_par, par_par, n, m, S, Kmax);

    alarm(0);

    int failures = g_timed_out ? 1 : 0;

    if (!failures) {
        // Light correctness sanity check: verify the array entries for sources.
        // We don't re-derive sources here; we just check the contract properties
        // that should always hold for a valid BFS: distance[src]=0 and parent=-1.
        // Since kernels generate sources deterministically based on the spec,
        // we can check for each source i that at index source[i] holds those values
        // by reconstructing sources using the PRNG described.
        uint64_t st = 987654321ULL;
        int ok = 1;
        for (uint32_t si = 0; si < S; si++) {
            // source[i] = rand()%n using the PRNG.
            uint32_t r = rand_u32_lcg(&st);
            uint32_t srcv = (uint32_t)(r % n);
            size_t idx = (size_t)si * (size_t)n + (size_t)srcv;
            if (dist_par[idx] != 0 || par_par[idx] != -1) {
                ok = 0;
                break;
            }
        }
        failures = ok ? 0 : 1;
    }

    printf("[verdict] %s\n", failures ? "LIVE-01 exposed" : "LIVE-01 not triggered");

    free(dist_serial);
    free(par_serial);
    free(dist_par);
    free(par_par);
    return failures ? 1 : 0;
}
