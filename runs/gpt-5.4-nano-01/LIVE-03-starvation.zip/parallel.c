#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <omp.h>

static uint64_t lcg_next_u64(uint64_t *state) {
    *state = (*state * 6364136223846793005ULL + 1ULL);
    return *state;
}

static uint32_t lcg_rand_u32(uint64_t *state) {
    uint64_t s = lcg_next_u64(state);
    return (uint32_t)(s >> 32);
}

static uint32_t sample_powerlaw_dest(uint64_t *state, uint32_t n, uint32_t Kmax) {
    uint32_t k = 1;
    if (Kmax == 0U) return 0U;
    while (k < Kmax) {
        uint32_t r = lcg_rand_u32(state);
        if ((r & 1U) == 0U) break;
        k++;
    }
    if (n <= 1U) return 0U;
    return 1U + (uint32_t)((k - 1U) % (n - 1U));
}

static void generate_graph(uint32_t n, uint32_t m, uint32_t Kmax, uint64_t seed,
                             uint32_t **adj_offsets_out, uint32_t **adj_edges_out) {
    uint32_t *outdeg = (uint32_t *)calloc((size_t)n, sizeof(uint32_t));
    if (!outdeg) {
        *adj_offsets_out = NULL;
        *adj_edges_out = NULL;
        return;
    }

    uint64_t state = seed;
    for (uint32_t e = 0; e < m; e++) {
        (void)sample_powerlaw_dest(&state, n, Kmax);
        uint32_t u = sample_powerlaw_dest(&state, n, Kmax);
        if (u < n) outdeg[u]++;
    }

    uint32_t *offsets = (uint32_t *)malloc(((size_t)n + 1U) * sizeof(uint32_t));
    uint32_t *edges = (uint32_t *)malloc((size_t)m * sizeof(uint32_t));
    if (!offsets || !edges) {
        free(outdeg);
        free(offsets);
        free(edges);
        *adj_offsets_out = NULL;
        *adj_edges_out = NULL;
        return;
    }

    offsets[0] = 0;
    for (uint32_t i = 0; i < n; i++) offsets[i + 1] = offsets[i] + outdeg[i];

    uint32_t *write_pos = (uint32_t *)malloc((size_t)n * sizeof(uint32_t));
    if (!write_pos) {
        free(outdeg);
        free(offsets);
        free(edges);
        *adj_offsets_out = NULL;
        *adj_edges_out = NULL;
        return;
    }
    for (uint32_t i = 0; i < n; i++) write_pos[i] = offsets[i];

    state = seed;
    for (uint32_t e = 0; e < m; e++) {
        uint32_t v = sample_powerlaw_dest(&state, n, Kmax);
        uint32_t u = sample_powerlaw_dest(&state, n, Kmax);
        uint32_t pos = write_pos[u]++;
        edges[pos] = v;
        (void)e;
    }

    free(outdeg);
    free(write_pos);
    *adj_offsets_out = offsets;
    *adj_edges_out = edges;
}

void bfs_parent_distance_serial_omp(
    int32_t *distance_out,
    int32_t *parent_out,
    uint32_t n,
    uint32_t m,
    uint32_t S,
    uint32_t Kmax)
{
    uint32_t *adj_offsets = NULL;
    uint32_t *adj_edges = NULL;

    generate_graph(n, m, Kmax, 123456789ULL, &adj_offsets, &adj_edges);
    if (!adj_offsets || !adj_edges) {
        return;
    }

    uint32_t *sources = (uint32_t *)malloc((size_t)S * sizeof(uint32_t));
    if (!sources) {
        free(adj_offsets);
        free(adj_edges);
        return;
    }

    uint64_t state_src = 987654321ULL;
    for (uint32_t i = 0; i < S; i++) {
        uint32_t r = lcg_rand_u32(&state_src);
        sources[i] = (n == 0U) ? 0U : (r % n);
    }

    int32_t *dist = distance_out;
    int32_t *par = parent_out;

    #pragma omp parallel for schedule(static)
    for (uint32_t si = 0; si < S; si++) {
        int32_t *dist_s = dist + (size_t)si * (size_t)n;
        int32_t *par_s = par + (size_t)si * (size_t)n;

        for (uint32_t v = 0; v < n; v++) {
            dist_s[v] = -1;
            par_s[v] = -1;
        }

        if (n == 0U) {
            continue;
        }

        uint32_t src = sources[si];
        dist_s[src] = 0;
        par_s[src] = -1;

        int32_t *queue = (int32_t *)malloc((size_t)n * sizeof(int32_t));
        uint32_t *next_frontier = (uint32_t *)malloc((size_t)n * sizeof(uint32_t));
        uint32_t *frontier = (uint32_t *)malloc((size_t)n * sizeof(uint32_t));
        if (!queue || !next_frontier || !frontier) {
            free(queue);
            free(next_frontier);
            free(frontier);
            continue;
        }

        uint32_t fsz = 0U;
        frontier[fsz++] = src;
        int32_t level = 0;

        while (fsz > 0U) {
            uint32_t next_sz = 0U;

            #pragma omp parallel
            {
                uint32_t local_next_sz = 0U;
                uint32_t *local_next = (uint32_t *)malloc((size_t)n * sizeof(uint32_t));

                if (local_next) {
                    #pragma omp for schedule(static, 1)
                    for (uint32_t fi = 0; fi < fsz; fi++) {
                        uint32_t u = frontier[fi];
                        uint32_t start = adj_offsets[u];
                        uint32_t end = adj_offsets[u + 1U];
                        for (uint32_t ei = start; ei < end; ei++) {
                            uint32_t w = adj_edges[ei];
                            int32_t expected = -1;
                            if (__sync_bool_compare_and_swap(&dist_s[w], expected, level + 1)) {
                                par_s[w] = (int32_t)u;
                                local_next[local_next_sz++] = w;
                            }
                        }
                    }

                    #pragma omp atomic
                    next_sz += local_next_sz;
                    uint32_t base;
                    #pragma omp atomic capture
                    { base = next_sz - local_next_sz; }
                    for (uint32_t i = 0; i < local_next_sz; i++) {
                        next_frontier[base + i] = local_next[i];
                    }

                    free(local_next);
                } else {
                    #pragma omp for schedule(static, 1)
                    for (uint32_t fi = 0; fi < fsz; fi++) {
                        uint32_t u = frontier[fi];
                        uint32_t start = adj_offsets[u];
                        uint32_t end = adj_offsets[u + 1U];
                        for (uint32_t ei = start; ei < end; ei++) {
                            uint32_t w = adj_edges[ei];
                            int32_t expected = -1;
                            if (__sync_bool_compare_and_swap(&dist_s[w], expected, level + 1)) {
                                par_s[w] = (int32_t)u;
                                uint32_t idx;
                                #pragma omp atomic capture
                                { idx = next_sz++; }
                                next_frontier[idx] = w;
                            }
                        }
                    }
                }

                if (omp_get_thread_num() == 0) {
                    if (next_sz == 0U) {
                        while (fsz > 0U) {
                            ;
                        }
                    }
                }
            }

            fsz = next_sz;
            for (uint32_t i = 0; i < fsz; i++) frontier[i] = next_frontier[i];
            level++;
        }

        free(queue);
        free(next_frontier);
        free(frontier);
    }

    free(sources);
    free(adj_offsets);
    free(adj_edges);
}
