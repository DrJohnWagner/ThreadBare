#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <omp.h>

static inline void bfs_one_source_omp(
    int V,
    const int *row_ptr,
    const int *col_idx,
    int source,
    int *hop_out,
    int *parent_out
) {
    const int UNVIS = -1;

    for (int i = 0; i < V; i++) {
        hop_out[i] = UNVIS;
        parent_out[i] = -1;
    }

    int *queue = (int *)malloc((size_t)V * sizeof(int));
    if (!queue) {
        return;
    }

    int qh = 0, qt = 0;
    hop_out[source] = 0;
    parent_out[source] = -1;
    queue[qt++] = source;

    while (qh < qt) {
        int level_start = qh;
        int level_end = qt;
        int next_qt = qt;

        #pragma omp parallel
        {
            int local_next_qt;
            #pragma omp single
            {
                local_next_qt = next_qt;
            }
            #pragma omp barrier

            for (int idx = level_start; idx < level_end; idx++) {
                int v = queue[idx];
                int dv = hop_out[v];
                for (int ei = row_ptr[v]; ei < row_ptr[v + 1]; ei++) {
                    int u = col_idx[ei];
                    if (hop_out[u] == UNVIS) {
                        int expected = UNVIS;
                        if (__sync_bool_compare_and_swap(&hop_out[u], expected, dv + 1)) {
                            parent_out[u] = v;
                            int pos;
                            #pragma omp atomic capture
                            pos = local_next_qt++;
                            queue[pos] = u;
                        }
                    }
                }
            }

            #pragma omp single
            {
                next_qt = local_next_qt;
                qh = level_end;
                qt = next_qt;
            }
        }

        free(queue);
    }

    free(queue);
}

void bfs_parent_hop_omp(
    int V,
    const int *row_ptr,
    const int *col_idx,
    int S,
    const int *sources,
    int *hop_out,
    int *parent_out
) {
    #pragma omp parallel for schedule(static)
    for (int si = 0; si < S; si++) {
        const int s = sources[si];
        bfs_one_source_omp(V, row_ptr, col_idx, s,
                            hop_out + (size_t)si * (size_t)V,
                            parent_out + (size_t)si * (size_t)V);
    }
}
