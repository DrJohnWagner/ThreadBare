/* harness.c — differential driver for bfs_parent_hop (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <omp.h>

#include <errno.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Forward declarations (signatures must match serial.c / parallel.c)
void bfs_parent_hop_serial(int V, const int *row_ptr, const int *col_idx, int S,
                            const int *sources, int *hop_out, int *parent_out);
void bfs_parent_hop_omp(int V, const int *row_ptr, const int *col_idx, int S,
                        const int *sources, int *hop_out, int *parent_out);

// Simple 64-bit xorshift RNG
static inline uint64_t xorshift64(uint64_t *state) {
    uint64_t x = *state;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    *state = x;
    return x;
}

static inline double rand_real_01(uint64_t *state) {
    // Convert to (0,1)
    // Use 53 bits mantissa; ensure not exactly 0.
    uint64_t r = xorshift64(state);
    uint64_t mant = r & ((1ULL << 53) - 1);
    double u = (double)mant / (double)((1ULL << 53) );
    if (u <= 0.0) u = 1e-16;
    if (u >= 1.0) u = 1.0 - 1e-16;
    return u;
}

static inline uint64_t splitmix64(uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

typedef struct {
    uint64_t *keys;
    size_t cap;
    size_t size;
} EdgeHashSet;

static void edgehash_init(EdgeHashSet *hs, size_t cap) {
    hs->cap = cap;
    hs->size = 0;
    hs->keys = (uint64_t*)malloc(sizeof(uint64_t) * cap);
    if (!hs->keys) {
        fprintf(stderr, "edgehash_init: out of memory\n");
        exit(1);
    }
    // 0 means empty; ensure keys never equal 0 by offsetting.
    memset(hs->keys, 0, sizeof(uint64_t) * cap);
}

static void edgehash_free(EdgeHashSet *hs) {
    free(hs->keys);
    hs->keys = NULL;
    hs->cap = 0;
    hs->size = 0;
}

static int edgehash_contains(EdgeHashSet *hs, uint64_t key) {
    size_t cap = hs->cap;
    uint64_t h = splitmix64(key);
    size_t idx = (size_t)(h % cap);
    for (;;) {
        uint64_t cur = hs->keys[idx];
        if (cur == 0) return 0;
        if (cur == key) return 1;
        idx++;
        if (idx == cap) idx = 0;
    }
}

static int edgehash_insert_if_absent(EdgeHashSet *hs, uint64_t key) {
    size_t cap = hs->cap;
    uint64_t h = splitmix64(key);
    size_t idx = (size_t)(h % cap);
    for (;;) {
        uint64_t cur = hs->keys[idx];
        if (cur == 0) {
            hs->keys[idx] = key;
            hs->size++;
            return 1;
        }
        if (cur == key) return 0;
        idx++;
        if (idx == cap) idx = 0;
    }
}

// Key for undirected edge (a,b) with a!=b
static inline uint64_t edge_key(uint32_t a, uint32_t b) {
    if (a > b) { uint32_t t = a; a = b; b = t; }
    // Pack into 64-bit. Offset by +1 so 0 is reserved for empty.
    uint64_t k = ((uint64_t)a << 32) | (uint64_t)b;
    return k + 1ULL;
}

static void usage(const char *prog) {
    fprintf(stderr, "Usage: %s [--n V] [--reps R] [--seed SEED] [--omp nthreads]\n", prog);
}

int main(int argc, char **argv) {
    int V = 310000;
    int E = 5000000;
    int S = 20;
    int reps = 20;
    uint64_t seed = 123456789ULL;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--n") && i + 1 < argc) {
            V = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--reps") && i + 1 < argc) {
            reps = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--seed") && i + 1 < argc) {
            seed = (uint64_t)strtoull(argv[++i], NULL, 10);
        } else if (!strcmp(argv[i], "--help")) {
            usage(argv[0]);
            return 0;
        } else {
            fprintf(stderr, "Unknown/invalid arg: %s\n", argv[i]);
            usage(argv[0]);
            return 1;
        }
    }

    if (V <= 1 || E <= 0 || S <= 0) {
        fprintf(stderr, "Invalid parameters\n");
        return 1;
    }

    // Allocate graph structures
    // Generate degree sequence and stub list; may be memory heavy, but harness targets benchmark scale.
    double deg_avg = 2.0 * (double)E / (double)V;
    (void)deg_avg;

    // Degree sequence
    int *deg = (int*)malloc(sizeof(int) * (size_t)V);
    if (!deg) { fprintf(stderr, "deg alloc failed\n"); return 1; }

    // Build stub list; we don't know exact sum(deg) until adjusted, but target is 2E.
    // We'll generate initial degrees, then adjust to make sum exactly 2E.

    uint64_t rng = seed;
    const double gamma = 2.5;

    double *dtemp = (double*)malloc(sizeof(double) * (size_t)V);
    if (!dtemp) { fprintf(stderr, "dtemp alloc failed\n"); return 1; }

    // Initial weights
    long double sumd = 0.0L;
    for (int i = 0; i < V; i++) {
        double u = rand_real_01(&rng);
        double w = pow(u + 1e-12, -gamma);
        dtemp[i] = w;
        sumd += (long double)w;
    }
    long double target_sum = (long double)(2LL * (long long)E);
    long double scale = target_sum / sumd;

    long long sumdeg = 0;
    for (int i = 0; i < V; i++) {
        long double di = (long double)dtemp[i] * scale;
        long long idi = llround((double)di);
        if (idi < 1) idi = 1;
        deg[i] = (int)idi;
        sumdeg += idi;
    }

    // Adjust sum to exactly 2E.
    // Use deterministic random vertices.
    while (sumdeg != 2LL * (long long)E) {
        // step size 1
        if (sumdeg < 2LL * (long long)E) {
            // increment random vertex
            uint64_t r = xorshift64(&rng);
            int idx = (int)(r % (uint64_t)V);
            deg[idx]++;
            sumdeg++;
        } else {
            // decrement random vertex with deg>=1 (bounded)
            // ensure we don't get stuck: try a few candidates.
            int dec_done = 0;
            for (int t = 0; t < 8 && !dec_done; t++) {
                uint64_t r = xorshift64(&rng);
                int idx = (int)(r % (uint64_t)V);
                if (deg[idx] >= 1) {
                    if (deg[idx] > 1) { deg[idx]--; sumdeg--; dec_done = 1; }
                    else {
                        // keep at 1
                    }
                }
            }
            if (!dec_done) {
                // deterministic scan fallback
                for (int idx = 0; idx < V && sumdeg != 2LL * (long long)E; idx++) {
                    if (deg[idx] > 1) { deg[idx]--; sumdeg--; }
                }
            }
        }
    }
    free(dtemp);

    // Build stub list length 2E
    long long stubN = 2LL * (long long)E;
    int *stubs = (int*)malloc(sizeof(int) * (size_t)stubN);
    if (!stubs) { fprintf(stderr, "stubs alloc failed\n"); return 1; }
    long long pos = 0;
    for (int i = 0; i < V; i++) {
        for (int k = 0; k < deg[i]; k++) stubs[pos++] = i;
    }
    if (pos != stubN) {
        fprintf(stderr, "stub fill mismatch: %lld vs %lld\n", pos, stubN);
        return 1;
    }

    // Shuffle stubs (Fisher-Yates)
    for (long long i = stubN - 1; i > 0; i--) {
        uint64_t r = xorshift64(&rng);
        long long j = (long long)(r % (uint64_t)(i + 1));
        int tmp = stubs[i];
        stubs[i] = stubs[j];
        stubs[j] = tmp;
    }

    // Create edges with uniqueness check
    int *edgeA = (int*)malloc(sizeof(int) * (size_t)E);
    int *edgeB = (int*)malloc(sizeof(int) * (size_t)E);
    if (!edgeA || !edgeB) { fprintf(stderr, "edge alloc failed\n"); return 1; }

    // Hash set with load factor ~0.7
    size_t cap = (size_t)((double)E * 1.7 + 16);
    EdgeHashSet hs;
    edgehash_init(&hs, cap);

    long long added = 0;
    long long k = 0;
    // We will walk through stub pairs and, on invalid edges, advance to next pair positions.
    // Since this is deterministic but may require more attempts, use a while loop over pair indices.
    long long pairIdx = 0;
    while (added < E) {
        long long i1 = 2LL * pairIdx;
        long long i2 = i1 + 1;
        // If out of bounds, restart shuffle with further RNG to avoid infinite loops.
        if (i2 >= stubN) {
            // re-shuffle deterministically
            for (long long i = stubN - 1; i > 0; i--) {
                uint64_t r = xorshift64(&rng);
                long long j = (long long)(r % (uint64_t)(i + 1));
                int tmp = stubs[i];
                stubs[i] = stubs[j];
                stubs[j] = tmp;
            }
            // reset
            edgehash_free(&hs);
            edgehash_init(&hs, cap);
            added = 0;
            pairIdx = 0;
            continue;
        }

        int a = stubs[i1];
        int b = stubs[i2];
        if (a != b) {
            uint64_t key = edge_key((uint32_t)a, (uint32_t)b);
            if (edgehash_insert_if_absent(&hs, key)) {
                edgeA[added] = a;
                edgeB[added] = b;
                added++;
            }
        }

        pairIdx++;
        k++;
        (void)k;
    }

    edgehash_free(&hs);
    free(stubs);

    // Build CSR adjacency from edges
    // Count degrees
    int *deg2 = (int*)calloc((size_t)V, sizeof(int));
    if (!deg2) { fprintf(stderr, "deg2 alloc failed\n"); return 1; }
    for (long long e = 0; e < E; e++) {
        deg2[edgeA[e]]++;
        deg2[edgeB[e]]++;
    }

    int *row_ptr = (int*)malloc(sizeof(int) * (size_t)(V + 1));
    int *col_idx = (int*)malloc(sizeof(int) * (size_t)(2LL * (long long)E));
    if (!row_ptr || !col_idx) { fprintf(stderr, "csr alloc failed\n"); return 1; }

    row_ptr[0] = 0;
    for (int i = 0; i < V; i++) row_ptr[i + 1] = row_ptr[i] + deg2[i];
    long long totalAdj = row_ptr[V];
    if (totalAdj != 2LL * (long long)E) {
        fprintf(stderr, "adj total mismatch: %lld vs %lld\n", totalAdj, 2LL * (long long)E);
        return 1;
    }

    int *offs = (int*)malloc(sizeof(int) * (size_t)V);
    if (!offs) { fprintf(stderr, "offs alloc failed\n"); return 1; }
    for (int i = 0; i < V; i++) offs[i] = row_ptr[i];

    for (long long e = 0; e < E; e++) {
        int a = edgeA[e], b = edgeB[e];
        col_idx[offs[a]++] = b;
        col_idx[offs[b]++] = a;
    }

    free(offs);
    free(edgeA);
    free(edgeB);
    free(deg2);

    // Generate sources (S=20 distinct) deterministically
    int *sources = (int*)malloc(sizeof(int) * (size_t)S);
    if (!sources) { fprintf(stderr, "sources alloc failed\n"); return 1; }
    uint64_t rng2 = seed ^ 0x9e3779b97f4a7c15ULL;
    int count = 0;
    // Use a simple bitset since V is large but manageable; for speed, use array of bytes.
    unsigned char *chosen = (unsigned char*)calloc((size_t)V, 1);
    if (!chosen) { fprintf(stderr, "chosen alloc failed\n"); return 1; }
    while (count < S) {
        int cand = (int)(xorshift64(&rng2) % (uint64_t)V);
        if (!chosen[cand]) {
            chosen[cand] = 1;
            sources[count++] = cand;
        }
    }
    free(chosen);

    // Output arrays: hop_out and parent_out are likely sized S*V
    size_t outN = (size_t)S * (size_t)V;
    int *hop_ref = (int*)malloc(sizeof(int) * outN);
    int *parent_ref = (int*)malloc(sizeof(int) * outN);
    int *hop_par = (int*)malloc(sizeof(int) * outN);
    int *parent_par = (int*)malloc(sizeof(int) * outN);
    if (!hop_ref || !parent_ref || !hop_par || !parent_par) {
        fprintf(stderr, "output alloc failed\n");
        return 1;
    }

    // Ground truth once (serial)
    bfs_parent_hop_serial(V, row_ptr, col_idx, S, sources, hop_ref, parent_ref);

    // Repeat parallel and compare
    int failures = 0;
    int reps_done = 0;
    for (int r = 0; r < reps; r++) {
        memset(hop_par, 0, sizeof(int) * outN);
        memset(parent_par, 0, sizeof(int) * outN);
        bfs_parent_hop_omp(V, row_ptr, col_idx, S, sources, hop_par, parent_par);
        reps_done++;

        // Compare full output arrays
        int mismatch = 0;
        size_t idx = 0;
        for (idx = 0; idx < outN; idx++) {
            if (hop_par[idx] != hop_ref[idx] || parent_par[idx] != parent_ref[idx]) {
                mismatch = 1;
                break;
            }
        }
        if (mismatch) {
            failures = 1;
            int src = (int)(idx / (size_t)V);
            int v = (int)(idx % (size_t)V);
            int svertex = sources[src];
            printf("[check] divergence at rep %d: srcIndex=%d (s=%d) vertex=%d hop(par)=%d hop(ref)=%d parent(par)=%d parent(ref)=%d\n",
                   r, src, svertex, v, hop_par[idx], hop_ref[idx], parent_par[idx], parent_ref[idx]);
            break;
        }
    }

    if (!failures) {
        // lightweight note
        printf("[check] no divergence in %d reps\n", reps_done);
    }

    free(hop_ref);
    free(parent_ref);
    free(hop_par);
    free(parent_par);
    free(row_ptr);
    free(col_idx);
    free(sources);

    printf("[verdict] %s\n", failures ? "SAFE-01 exposed" : "SAFE-01 not triggered");
    return failures ? 1 : 0;
}
