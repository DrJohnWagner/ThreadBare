#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

static inline void bfs_one_source_serial(
    int V,
    const int *row_ptr,
    const int *col_idx,
    int source,
    int *hop_out,
    int *parent_out
) {
    const int UNVIS = -1;

    for (int i = 0; i < V; i++) {
        hop_out[i] = UNVIS;
        parent_out[i] = -1;
    }

    int *queue = (int *)malloc((size_t)V * sizeof(int));
    if (!queue) {
        return;
    }

    int qh = 0, qt = 0;
    hop_out[source] = 0;
    parent_out[source] = -1;
    queue[qt++] = source;

    while (qh < qt) {
        int v = queue[qh++];
        int dv = hop_out[v];

        for (int ei = row_ptr[v]; ei < row_ptr[v + 1]; ei++) {
            int u = col_idx[ei];
            if (hop_out[u] == UNVIS) {
                hop_out[u] = dv + 1;
                parent_out[u] = v;
                queue[qt++] = u;
            }
        }
    }

    free(queue);
}

void bfs_parent_hop_serial(
    int V,
    const int *row_ptr,
    const int *col_idx,
    int S,
    const int *sources,
    int *hop_out,
    int *parent_out
) {
    for (int si = 0; si < S; si++) {
        const int s = sources[si];
        bfs_one_source_serial(V, row_ptr, col_idx, s,
                              hop_out + (size_t)si * (size_t)V,
                              parent_out + (size_t)si * (size_t)V);
    }
}
