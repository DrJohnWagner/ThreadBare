/* harness.c — scaling driver for kmeans_2d (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <math.h>

/* Forward declarations (signatures must match the real ones exactly) */
void kmeans_2d_serial(int N, float *centroids_out, int *assignments_out);
void kmeans_2d_omp(int N, float *centroids_out, int *assignments_out);

static double now_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

static void usage(const char *prog) {
    fprintf(stderr,
            "Usage: %s [--n N] [--threads-max T] [--warmup] [--check] [--eff-thr X]\n"
            "  --n N            problem size (default: 2000000)\n"
            "  --threads-max T max thread count to test (default: omp_get_max_threads())\n"
            "  --warmup        perform a warmup pass (default: on)\n"
            "  --check         do one correctness check against serial (default: on)\n"
            "  --eff-thr X     efficiency threshold at max threads (default: 0.40)\n",
            prog);
}

int main(int argc, char **argv) {
    int N = 2000000; /* largest in problemSizes */
    int threads_max = 0;
    int do_warmup = 1;
    int do_check = 1;
    double eff_thr = 0.40; /* memory-bottleneck slowdown should reduce efficiency */

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            N = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--threads-max") == 0 && i + 1 < argc) {
            threads_max = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--warmup") == 0) {
            do_warmup = 1;
        } else if (strcmp(argv[i], "--check") == 0) {
            do_check = 1;
        } else if (strcmp(argv[i], "--no-check") == 0) {
            do_check = 0;
        } else if (strcmp(argv[i], "--no-warmup") == 0) {
            do_warmup = 0;
        } else if (strcmp(argv[i], "--eff-thr") == 0 && i + 1 < argc) {
            eff_thr = atof(argv[++i]);
        } else {
            usage(argv[0]);
            return 2;
        }
    }

    int max_threads_avail = omp_get_max_threads();
    if (threads_max <= 0 || threads_max > max_threads_avail) threads_max = max_threads_avail;

    const int K = 64;
    float *c_serial = (float *)malloc((size_t)K * 2 * sizeof(float));
    float *c_parallel = (float *)malloc((size_t)K * 2 * sizeof(float));
    int *a_serial = (int *)malloc((size_t)N * sizeof(int));
    int *a_parallel = (int *)malloc((size_t)N * sizeof(int));
    if (!c_serial || !c_parallel || !a_serial || !a_parallel) {
        fprintf(stderr, "Allocation failed\n");
        return 2;
    }

    omp_set_dynamic(0);

    if (do_warmup) {
        omp_set_num_threads(1);
        kmeans_2d_omp(N, c_parallel, a_parallel);
    }

    /* Timed serial once */
    omp_set_num_threads(1);
    double t_serial_start = now_sec();
    kmeans_2d_serial(N, c_serial, a_serial);
    double t_serial = now_sec() - t_serial_start;

    /* One light correctness check (parallel at 1 thread matches serial) */
    if (do_check) {
        omp_set_num_threads(1);
        kmeans_2d_omp(N, c_parallel, a_parallel);
        for (int i = 0; i < N; i++) {
            if (a_parallel[i] != a_serial[i]) {
                printf("[check] assignment mismatch at i=%d: parallel=%d serial=%d\n", i, a_parallel[i], a_serial[i]);
                free(c_serial); free(c_parallel); free(a_serial); free(a_parallel);
                printf("[verdict] PERF-00 not triggered\n");
                return 0;
            }
        }
    }

    int t = 1;
    double best_eff = 1.0;
    double best_speedup = 1.0;
    double best_t = 1.0;

    while (t <= threads_max) {
        omp_set_num_threads(t);
        double t0 = now_sec();
        kmeans_2d_omp(N, c_parallel, a_parallel);
        double dt = now_sec() - t0;

        double speedup = (t_serial > 0.0) ? (t_serial / dt) : 0.0;
        double eff = speedup / (double)t;
        printf("[scale] threads=%d time=%g speedup=%g eff=%g\n", t, dt, speedup, eff);

        if (t == threads_max) {
            best_eff = eff;
            best_speedup = speedup;
            best_t = dt;
        }

        if (t == threads_max) break;
        /* Grow as powers of two, but don't overshoot */
        if (t <= threads_max / 2) t *= 2;
        else t = threads_max;
    }

    int failures = (best_eff < eff_thr);

    free(c_serial); free(c_parallel); free(a_serial); free(a_parallel);

    if (failures) {
        printf("[verdict] PERF-01 exposed\n");
        return 1;
    } else {
        printf("[verdict] PERF-01 not triggered\n");
        return 0;
    }
}
