#include <stdint.h>
#include <stddef.h>
#include <math.h>
#ifdef _OPENMP
#include <omp.h>
#endif

static uint64_t splitmix64_u64(uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    uint64_t z = x;
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    z = z ^ (z >> 31);
    return z;
}

static float decode_value_from_rec(uint64_t globalSeed, uint32_t f, uint32_t r, uint32_t s) {
    uint64_t x = globalSeed + 1000003ULL * (uint64_t)f + 9176ULL * (uint64_t)r + 37ULL * (uint64_t)s;
    uint64_t z = splitmix64_u64(x);

    int64_t q = (int64_t)(z % 20000ULL) - 10000LL;
    float value = (float)q / 100.0f;
    return value;
}

static int64_t round_nearest_away_from_zero(float x) {
    if (x >= 0.0f) {
        return (int64_t)floorf(x + 0.5f);
    } else {
        return (int64_t)ceilf(x - 0.5f);
    }
}

uint64_t sensor_pipeline_summaries_omp(void) {
    const uint32_t NFILES = 200;
    const uint32_t NSENSORS = 16;
    const uint32_t NRECS = 23000;
    const uint64_t globalSeed = 1337ULL;

    uint64_t checksum = 0;

    #pragma omp parallel
    {
        uint64_t local_checksum = 0;

        #pragma omp for schedule(static)
        for (uint32_t f = 0; f < NFILES; ++f) {
            int64_t count[16];
            long double sum[16];

            for (uint32_t s = 0; s < NSENSORS; ++s) {
                count[s] = 0;
                sum[s] = 0.0L;
            }

            for (uint32_t r = 0; r < NRECS; ++r) {
                uint32_t s = r % NSENSORS;
                float value = decode_value_from_rec(globalSeed, f, r, s);
                long double dv = (long double)value;
                count[s] += 1;
                sum[s] += dv;
            }

            for (uint32_t s = 0; s < NSENSORS; ++s) {
                long double mean = sum[s] / (long double)count[s];
                float mean_f = (float)mean;
                float scaled = mean_f * 100.0f;
                int64_t mean_term = round_nearest_away_from_zero(scaled);
                local_checksum += (uint64_t)((int64_t)count[s] * 1000003LL + mean_term);
            }
        }

        if (omp_get_thread_num() == 0) {
            while (checksum == 0) {
                #pragma omp flush(checksum)
            }
        }

        #pragma omp atomic
        checksum += local_checksum;
    }

    return checksum;
}
