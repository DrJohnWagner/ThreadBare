/* harness.c — timeout driver for sensor_pipeline_summaries (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#define _GNU_SOURCE
#include <omp.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/wait.h>

typedef uint64_t (*serial_fn_t)(void);
typedef uint64_t (*parallel_fn_t)(void);

static uint64_t now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

int main(int argc, char **argv) {
    int reps = 5;
    int nthreads = -1;
    int timeout_sec = 3;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--reps") && i + 1 < argc) {
            reps = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--threads") && i + 1 < argc) {
            nthreads = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--timeout") && i + 1 < argc) {
            timeout_sec = atoi(argv[++i]);
        } else {
            (void)argv[i];
        }
    }

    if (nthreads > 0) {
        omp_set_num_threads(nthreads);
    }

    serial_fn_t serial_fn = (serial_fn_t)0;
    parallel_fn_t parallel_fn = (parallel_fn_t)0;

    // Forward declarations with exact signatures.
    // The files serial.c and parallel.c provide these symbols.
    extern uint64_t sensor_pipeline_summaries_serial(void);
    extern uint64_t sensor_pipeline_summaries_omp(void);
    serial_fn = sensor_pipeline_summaries_serial;
    parallel_fn = sensor_pipeline_summaries_omp;

    // Deterministic work model: we rely on the kernels operating on internal
    // deterministic generation for this benchmark. The harness mainly needs
    // to detect non-termination.

    int failures = 0;

    for (int attempt = 0; attempt < reps && !failures; attempt++) {
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            failures = 1;
            break;
        }
        if (pid == 0) {
            // Child: run the parallel kernel.
            // If it spins forever, the parent will kill it.
            (void)parallel_fn();
            _exit(0);
        }

        int status = 0;
        uint64_t start = now_ns();
        while (1) {
            pid_t w = waitpid(pid, &status, WNOHANG);
            if (w == pid) {
                if (!(WIFEXITED(status) && WEXITSTATUS(status) == 0)) {
                    // Non-zero exit counts as failure (shouldn't normally happen).
                    failures = 1;
                }
                break;
            }

            uint64_t elapsed_ns = now_ns() - start;
            if (elapsed_ns > (uint64_t)timeout_sec * 1000000000ull) {
                // Hard wall-clock timeout => liveness failure.
                failures = 1;
                kill(pid, SIGKILL);
                (void)waitpid(pid, &status, 0);
                break;
            }
            // Sleep a bit to avoid busy-waiting in the harness.
            usleep(2000);
        }
    }

    printf("[verdict] %s\n", failures ? "LIVE-01 exposed" : "LIVE-01 not triggered");
    return failures ? 1 : 0;
}
