#include <stdint.h>
#include <stddef.h>
#include <math.h>
#include <omp.h>

static uint64_t splitmix64(uint64_t x) {
    x += 0x9E3779B97F4A7C15ULL;
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ULL;
    x = (x ^ (x >> 27)) * 0x94D049BB133111EBULL;
    return x ^ (x >> 31);
}

static uint64_t hash3(uint64_t a, uint64_t b, uint64_t c) {
    uint64_t x = a ^ (b * 0x9E3779B97F4A7C15ULL) ^ (c * 0xBF58476D1CE4E5B9ULL);
    return splitmix64(x);
}

static void generate_record(uint64_t seed, uint32_t f, uint32_t r,
                             uint16_t *sensorId, uint32_t *deltaTs,
                             int32_t *value_q, uint32_t baseTs) {
    const uint32_t numSensors = 32;

    uint64_t h_s = hash3(seed, (uint64_t)f, (uint64_t)r);
    uint32_t s = (uint32_t)(h_s % numSensors);

    uint32_t ts = baseTs + r;
    uint32_t delta = ts - baseTs;

    uint64_t h_v = hash3(seed + 1ULL, (uint64_t)f, (uint64_t)r);
    int32_t quant = (int32_t)((h_v % 20000ULL) - 10000ULL);

    *sensorId = (uint16_t)s;
    *deltaTs = delta;
    *value_q = quant;
}

void sensor_ingest_pipeline_omp(
    uint32_t numFiles,
    uint32_t recordsPerFile,
    uint32_t numSensors,
    uint64_t seed,
    uint32_t baseTs0,
    uint32_t baseTsStep,
    size_t out_capacity_rows,
    uint32_t *out_fileId,
    uint32_t *out_sensorId,
    uint32_t *out_count,
    double *out_sum,
    double *out_sumsq,
    uint32_t *out_firstTs,
    uint32_t *out_lastTs,
    uint64_t *out_checksum,
    double *out_totalSum,
    uint64_t *out_totalCount)
{
    const size_t expectedRows = (size_t)numFiles * (size_t)numSensors;
    if (out_capacity_rows < expectedRows) {
        return;
    }

    const int maxThreads = omp_get_max_threads();
    double *threadTotalSum = NULL;
    uint64_t *threadTotalCount = NULL;
    uint64_t *threadChecksumXor = NULL;

    if (maxThreads > 0) {
        threadTotalSum = (double *)malloc((size_t)maxThreads * sizeof(double));
        threadTotalCount = (uint64_t *)malloc((size_t)maxThreads * sizeof(uint64_t));
        threadChecksumXor = (uint64_t *)malloc((size_t)maxThreads * sizeof(uint64_t));
        if (!threadTotalSum || !threadTotalCount || !threadChecksumXor) {
            free(threadTotalSum);
            free(threadTotalCount);
            free(threadChecksumXor);
            return;
        }
        for (int t = 0; t < maxThreads; ++t) {
            threadTotalSum[t] = 0.0;
            threadTotalCount[t] = 0ULL;
            threadChecksumXor[t] = 0ULL;
        }
    }

    const size_t baseIndex = expectedRows;

#pragma omp parallel
    {
        const int tid = omp_get_thread_num();
        double totalSum = 0.0;
        uint64_t totalCount = 0ULL;
        uint64_t checksum_xor = 0ULL;

#pragma omp for schedule(static)
        for (uint32_t f = 0; f < numFiles; ++f) {
            uint32_t baseTs = baseTs0 + baseTsStep * f;

            uint32_t *cnt = (uint32_t *)malloc((size_t)numSensors * sizeof(uint32_t));
            double *sum = (double *)malloc((size_t)numSensors * sizeof(double));
            double *sumsq = (double *)malloc((size_t)numSensors * sizeof(double));
            uint32_t *firstTs = (uint32_t *)malloc((size_t)numSensors * sizeof(uint32_t));
            uint32_t *lastTs = (uint32_t *)malloc((size_t)numSensors * sizeof(uint32_t));

            if (!cnt || !sum || !sumsq || !firstTs || !lastTs) {
                if (cnt) free(cnt);
                if (sum) free(sum);
                if (sumsq) free(sumsq);
                if (firstTs) free(firstTs);
                if (lastTs) free(lastTs);
                continue;
            }

            for (uint32_t s = 0; s < numSensors; ++s) {
                cnt[s] = 0U;
                sum[s] = 0.0;
                sumsq[s] = 0.0;
                firstTs[s] = 0U;
                lastTs[s] = 0U;
            }

            for (uint32_t r = 0; r < recordsPerFile; ++r) {
                uint16_t s16;
                uint32_t delta;
                int32_t value_q;

                generate_record(seed, f, r, &s16, &delta, &value_q, baseTs);

                uint32_t s = (uint32_t)s16;
                double v = ((double)value_q) / 100.0;
                uint32_t ts = baseTs + delta;

                uint32_t c = cnt[s];
                cnt[s] = c + 1U;
                sum[s] += v;
                sumsq[s] += v * v;

                if (c == 0U) {
                    firstTs[s] = ts;
                }
                lastTs[s] = ts;
            }

            const size_t row0 = (size_t)f * (size_t)numSensors;
            for (uint32_t s = 0; s < numSensors; ++s) {
                const size_t row = row0 + (size_t)s;
                if (row >= baseIndex) {
                    break;
                }

                double ssum = sum[s];
                double ssq = sumsq[s];

                uint64_t llround_term = (uint64_t)llround(ssum * 1e6);
                uint64_t term = llround_term ^ (uint64_t)(cnt[s] << 1)
                                ^ (uint64_t)((uint64_t)s * 1315423911ULL + (uint64_t)f);
                checksum_xor ^= term;

                totalSum += ssum;
                totalCount += (uint64_t)cnt[s];

                out_fileId[row] = f;
                out_sensorId[row] = s;
                out_count[row] = cnt[s];
                out_sum[row] = ssum;
                out_sumsq[row] = ssq;
                out_firstTs[row] = firstTs[s];
                out_lastTs[row] = lastTs[s];
            }

            free(cnt);
            free(sum);
            free(sumsq);
            free(firstTs);
            free(lastTs);
        }

        if (threadTotalSum) threadTotalSum[tid] = totalSum;
        if (threadTotalCount) threadTotalCount[tid] = totalCount;
        if (threadChecksumXor) threadChecksumXor[tid] = checksum_xor;
    }

    if (out_checksum || out_totalSum || out_totalCount) {
        double totalSum = 0.0;
        uint64_t totalCount = 0ULL;
        uint64_t checksum_xor = 0ULL;

        if (maxThreads > 0 && threadTotalSum && threadTotalCount && threadChecksumXor) {
            for (int t = 0; t < maxThreads; ++t) {
                totalSum += threadTotalSum[t];
                totalCount += threadTotalCount[t];
                checksum_xor ^= threadChecksumXor[t];
            }
        }

        if (out_checksum) *out_checksum = checksum_xor;
        if (out_totalSum) *out_totalSum = totalSum;
        if (out_totalCount) *out_totalCount = totalCount;
    }

    free(threadTotalSum);
    free(threadTotalCount);
    free(threadChecksumXor);
}
