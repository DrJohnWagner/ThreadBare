/* harness.c — differential driver for sensor_ingest_pipeline (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <omp.h>

// Forward declarations matching the real signatures.
void sensor_ingest_pipeline_serial(
    uint32_t numFiles,
    uint32_t recordsPerFile,
    uint32_t numSensors,
    uint64_t seed,
    uint32_t baseTs0,
    uint32_t baseTsStep,
    size_t out_capacity_rows,
    uint32_t* out_fileId,
    uint32_t* out_sensorId,
    uint32_t* out_count,
    double* out_sum,
    double* out_sumsq,
    uint32_t* out_firstTs,
    uint32_t* out_lastTs,
    uint64_t* out_checksum,
    double* out_totalSum,
    uint64_t* out_totalCount
);

void sensor_ingest_pipeline_omp(
    uint32_t numFiles,
    uint32_t recordsPerFile,
    uint32_t numSensors,
    uint64_t seed,
    uint32_t baseTs0,
    uint32_t baseTsStep,
    size_t out_capacity_rows,
    uint32_t* out_fileId,
    uint32_t* out_sensorId,
    uint32_t* out_count,
    double* out_sum,
    double* out_sumsq,
    uint32_t* out_firstTs,
    uint32_t* out_lastTs,
    uint64_t* out_checksum,
    double* out_totalSum,
    uint64_t* out_totalCount
);

static uint64_t splitmix64(uint64_t x) {
    x += 0x9E3779B97F4A7C15ULL;
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ULL;
    x = (x ^ (x >> 27)) * 0x94D049BB133111EBULL;
    return x ^ (x >> 31);
}

// hash(a,b,c) = splitmix64(a ^ b*0x9E... ^ c*0xBF...)
static uint64_t hash3(uint64_t a, uint64_t b, uint64_t c) {
    uint64_t x = a ^ (b * 0x9E3779B97F4A7C15ULL) ^ (c * 0xBF58476D1CE4E5B9ULL);
    return splitmix64(x);
}

static void gen_synthetic_inputs(
    uint32_t numFiles,
    uint32_t recordsPerFile,
    uint32_t numSensors,
    uint64_t seed,
    uint32_t baseTs0,
    uint32_t baseTsStep,
    // outputs filled for optional sanity checks / constraints
    // (not directly consumed by the kernel; kept to ensure harness is self-contained)
    volatile uint32_t* scratch_u32,
    volatile uint64_t* scratch_u64,
    size_t scratch_len
) {
    // Touch deterministic pseudo-random values derived from the spec.
    // This ensures the harness is self-contained and exercises the same generator
    // path regardless of kernel internal behavior.
    uint32_t idx = 0;
    uint64_t acc = 0;
    for (uint32_t f = 0; f < numFiles; ++f) {
        uint32_t baseTs = baseTs0 + baseTsStep * f;
        (void)baseTs;
        for (uint32_t r = 0; r < recordsPerFile; ++r) {
            uint32_t s = (uint32_t)(hash3(seed, f, r) % numSensors);
            uint64_t h = hash3(seed + 1, f, r);
            double v = ((double)((int64_t)(h % 20000ULL) - 10000LL)) / 100.0;
            // Use v to perturb accumulator in a deterministic way.
            uint64_t vi = (uint64_t)llround(v * 1e3);
            acc ^= splitmix64((uint64_t)s * 1315423911ULL ^ vi ^ (uint64_t)f * 2654435761ULL ^ (uint64_t)r);
            if (idx < scratch_len) scratch_u32[idx] = s;
            idx++;
            if (idx >= scratch_len) idx = 0;
            // Keep it lightweight: sample only a subset of records.
            if ((r & 0x3FFFu) == 0) {
                // occasional break to reduce harness overhead
                break;
            }
        }
        if (f >= 3) break;
    }
    if (scratch_len > 0) scratch_u64[0] = acc;
}

static int cmp_double_tol(double a, double b) {
    double diff = fabs(a - b);
    double scale = fmax(1.0, fmax(fabs(a), fabs(b)));
    // Spec suggests tolerance only if needed; harness uses strict equality
    // first, but accepts tolerance-equivalent mismatches.
    if (diff == 0.0) return 1;
    return diff <= 1e-9 * scale;
}

static void usage(const char* prog) {
    fprintf(stderr,
            "Usage: %s [--n numFiles] [--reps reps] [--threads n]\n"
            "Defaults: --n 200 --reps 20\n",
            prog);
}

int main(int argc, char** argv) {
    uint32_t numFiles = 200;
    uint32_t recordsPerFile = 23000;
    uint32_t numSensors = 32;
    uint64_t seed = 1337;
    uint32_t baseTs0 = 1700000000u;
    uint32_t baseTsStep = 10u;

    int reps = 20;

    for (int i = 1; i < argc; ++i) {
        if (!strcmp(argv[i], "--n") && i + 1 < argc) {
            numFiles = (uint32_t)strtoul(argv[++i], NULL, 10);
        } else if (!strcmp(argv[i], "--reps") && i + 1 < argc) {
            reps = (int)strtol(argv[++i], NULL, 10);
        } else if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) {
            usage(argv[0]);
            return 0;
        } else {
            fprintf(stderr, "Unknown arg: %s\n", argv[i]);
            usage(argv[0]);
            return 2;
        }
    }

    size_t rows = (size_t)numFiles * (size_t)numSensors;
    size_t out_capacity_rows = rows; // exact required size

    uint32_t* ref_fileId = (uint32_t*)malloc(rows * sizeof(uint32_t));
    uint32_t* ref_sensorId = (uint32_t*)malloc(rows * sizeof(uint32_t));
    uint32_t* ref_count = (uint32_t*)malloc(rows * sizeof(uint32_t));
    double* ref_sum = (double*)malloc(rows * sizeof(double));
    double* ref_sumsq = (double*)malloc(rows * sizeof(double));
    uint32_t* ref_firstTs = (uint32_t*)malloc(rows * sizeof(uint32_t));
    uint32_t* ref_lastTs = (uint32_t*)malloc(rows * sizeof(uint32_t));
    uint64_t* ref_checksum = (uint64_t*)malloc(rows * sizeof(uint64_t));
    double* ref_totalSum = (double*)malloc(sizeof(double));
    uint64_t* ref_totalCount = (uint64_t*)malloc(sizeof(uint64_t));

    uint32_t* par_fileId = (uint32_t*)malloc(rows * sizeof(uint32_t));
    uint32_t* par_sensorId = (uint32_t*)malloc(rows * sizeof(uint32_t));
    uint32_t* par_count = (uint32_t*)malloc(rows * sizeof(uint32_t));
    double* par_sum = (double*)malloc(rows * sizeof(double));
    double* par_sumsq = (double*)malloc(rows * sizeof(double));
    uint32_t* par_firstTs = (uint32_t*)malloc(rows * sizeof(uint32_t));
    uint32_t* par_lastTs = (uint32_t*)malloc(rows * sizeof(uint32_t));
    uint64_t* par_checksum = (uint64_t*)malloc(rows * sizeof(uint64_t));
    double* par_totalSum = (double*)malloc(sizeof(double));
    uint64_t* par_totalCount = (uint64_t*)malloc(sizeof(uint64_t));

    if (!ref_fileId || !ref_sensorId || !ref_count || !ref_sum || !ref_sumsq || !ref_firstTs || !ref_lastTs ||
        !ref_checksum || !ref_totalSum || !ref_totalCount || !par_fileId || !par_sensorId || !par_count ||
        !par_sum || !par_sumsq || !par_firstTs || !par_lastTs || !par_checksum || !par_totalSum || !par_totalCount) {
        fprintf(stderr, "Allocation failed\n");
        return 2;
    }

    // Touch deterministic synthetic generator scratch (self-contained harness).
    volatile uint32_t scratch_u32[16];
    volatile uint64_t scratch_u64[1];
    gen_synthetic_inputs(numFiles, recordsPerFile, numSensors, seed, baseTs0, baseTsStep,
                          scratch_u32, scratch_u64, 16);

    // Reference run
    memset(ref_fileId, 0, rows * sizeof(uint32_t));
    memset(ref_sensorId, 0, rows * sizeof(uint32_t));
    memset(ref_count, 0, rows * sizeof(uint32_t));
    memset(ref_sum, 0, rows * sizeof(double));
    memset(ref_sumsq, 0, rows * sizeof(double));
    memset(ref_firstTs, 0, rows * sizeof(uint32_t));
    memset(ref_lastTs, 0, rows * sizeof(uint32_t));
    memset(ref_checksum, 0, rows * sizeof(uint64_t));
    *ref_totalSum = 0.0;
    *ref_totalCount = 0;

    sensor_ingest_pipeline_serial(
        numFiles, recordsPerFile, numSensors, seed, baseTs0, baseTsStep, out_capacity_rows,
        ref_fileId, ref_sensorId, ref_count, ref_sum, ref_sumsq,
        ref_firstTs, ref_lastTs, ref_checksum, ref_totalSum, ref_totalCount
    );

    int failures = 0;

    for (int rep = 0; rep < reps; ++rep) {
        memset(par_fileId, 0, rows * sizeof(uint32_t));
        memset(par_sensorId, 0, rows * sizeof(uint32_t));
        memset(par_count, 0, rows * sizeof(uint32_t));
        memset(par_sum, 0, rows * sizeof(double));
        memset(par_sumsq, 0, rows * sizeof(double));
        memset(par_firstTs, 0, rows * sizeof(uint32_t));
        memset(par_lastTs, 0, rows * sizeof(uint32_t));
        memset(par_checksum, 0, rows * sizeof(uint64_t));
        *par_totalSum = 0.0;
        *par_totalCount = 0;

        sensor_ingest_pipeline_omp(
            numFiles, recordsPerFile, numSensors, seed, baseTs0, baseTsStep, out_capacity_rows,
            par_fileId, par_sensorId, par_count, par_sum, par_sumsq,
            par_firstTs, par_lastTs, par_checksum, par_totalSum, par_totalCount
        );

        // Compare full output.
        for (size_t i = 0; i < rows; ++i) {
            if (par_fileId[i] != ref_fileId[i] || par_sensorId[i] != ref_sensorId[i] ||
                par_count[i] != ref_count[i] || par_firstTs[i] != ref_firstTs[i] || par_lastTs[i] != ref_lastTs[i] ||
                par_checksum[i] != ref_checksum[i]) {
                printf("[check] mismatch at row %zu (rep %d): "
                       "fileId %u/%u sensorId %u/%u count %u/%u firstTs %u/%u lastTs %u/%u checksum %llu/%llu\n",
                       i, rep,
                       (unsigned)par_fileId[i], (unsigned)ref_fileId[i],
                       (unsigned)par_sensorId[i], (unsigned)ref_sensorId[i],
                       (unsigned)par_count[i], (unsigned)ref_count[i],
                       (unsigned)par_firstTs[i], (unsigned)ref_firstTs[i],
                       (unsigned)par_lastTs[i], (unsigned)ref_lastTs[i],
                       (unsigned long long)par_checksum[i], (unsigned long long)ref_checksum[i]);
                failures = 1;
                break;
            }
            // Floating compares: try exact, otherwise tolerance.
            if (!(par_sum[i] == ref_sum[i] || cmp_double_tol(par_sum[i], ref_sum[i]))) {
                printf("[check] mismatch at row %zu (rep %d): sum %0.17g/%0.17g\n", i, rep, par_sum[i], ref_sum[i]);
                failures = 1;
                break;
            }
            if (!(par_sumsq[i] == ref_sumsq[i] || cmp_double_tol(par_sumsq[i], ref_sumsq[i]))) {
                printf("[check] mismatch at row %zu (rep %d): sumsq %0.17g/%0.17g\n", i, rep, par_sumsq[i], ref_sumsq[i]);
                failures = 1;
                break;
            }
        }
        if (failures) break;

        if (!(*par_totalCount == *ref_totalCount) || !(*par_totalSum == *ref_totalSum)) {
            double d = fabs(*par_totalSum - *ref_totalSum);
            double scale = fmax(1.0, fabs(*ref_totalSum));
            if (!(*par_totalCount == *ref_totalCount) || !(d <= 1e-9 * scale)) {
                printf("[check] mismatch totals (rep %d): totalCount %llu/%llu totalSum %0.17g/%0.17g\n",
                       rep,
                       (unsigned long long)*par_totalCount, (unsigned long long)*ref_totalCount,
                       *par_totalSum, *ref_totalSum);
                failures = 1;
                break;
            }
        }
    }

    printf("[verdict] %s\n", failures ? "SAFE-01 exposed" : "SAFE-01 not triggered");

    free(ref_fileId); free(ref_sensorId); free(ref_count); free(ref_sum); free(ref_sumsq);
    free(ref_firstTs); free(ref_lastTs); free(ref_checksum); free(ref_totalSum); free(ref_totalCount);
    free(par_fileId); free(par_sensorId); free(par_count); free(par_sum); free(par_sumsq);
    free(par_firstTs); free(par_lastTs); free(par_checksum); free(par_totalSum); free(par_totalCount);

    return failures ? 1 : 0;
}
