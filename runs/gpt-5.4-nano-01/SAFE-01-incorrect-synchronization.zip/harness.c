/* harness.c — differential driver for kmeans_assign_update_converge (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

// Forward declarations matching the real signatures.
void kmeans_assign_update_converge_serial(int numPoints, int maxIters,
                                          const float *X_in, const float *Y_in,
                                          int *A_out, float *C_out);
void kmeans_assign_update_converge_omp(int numPoints, int maxIters,
                                       const float *X_in, const float *Y_in,
                                       int *A_out, float *C_out);

static uint64_t splitmix64(uint64_t x) {
  x += 0x9e3779b97f4a7c15ULL;
  x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
  x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
  return x ^ (x >> 31);
}

static uint64_t hash64(uint64_t a, uint64_t b) {
  return splitmix64(a ^ (b * 0x9e3779b97f4a7c15ULL));
}

static double det_gauss(int i, int centerID) {
  // u and v are in [0,1)
  uint64_t hu = hash64((uint64_t)i, (uint64_t)centerID);
  uint64_t hv = hash64((uint64_t)(i + 17), (uint64_t)centerID);
  const uint64_t mask = (1ULL << 53) - 1ULL;
  double u = (double)(hu & mask) / (double)(1ULL << 53);
  double v = (double)(hv & mask) / (double)(1ULL << 53);
  double uu = u < 1e-12 ? 1e-12 : u;
  double r = sqrt(-2.0 * log(uu));
  double theta = 2.0 * 3.14159265358979323846 * v;
  return r * cos(theta);
}

static void parse_args(int argc, char **argv, int *outN, int *outT, int *outReps) {
  int N = 2000000;
  int T = 50;
  int reps = 25;
  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--n") && i + 1 < argc) {
      N = atoi(argv[++i]);
    } else if (!strcmp(argv[i], "--maxIters") && i + 1 < argc) {
      T = atoi(argv[++i]);
    } else if (!strcmp(argv[i], "--reps") && i + 1 < argc) {
      reps = atoi(argv[++i]);
    } else {
      // ignore unknown flags
    }
  }
  *outN = N;
  *outT = T;
  *outReps = reps;
}

typedef struct {
  uint64_t state;
} PRNG;

static inline uint64_t nextRand64(PRNG *p) {
  // 64-bit linear congruential generator
  p->state = p->state * 6364136223846793005ULL + 1442695040888963407ULL;
  return p->state;
}

static inline double nextRandUnit(PRNG *p) {
  // nextRand()/2^64, in [0,1)
  uint64_t r = nextRand64(p);
  // divide by 2^64 using double
  return (double)r / 18446744073709551616.0; // 2^64
}

static void generate_dataset(int N, float *X, float *Y) {
  const int K = 64;
  (void)K;

  PRNG pr;
  pr.state = 123456789ULL;

  // Base fill with randoms in [0,1)
  for (int i = 0; i < N; i++) {
    double r1 = nextRandUnit(&pr);
    double r2 = nextRandUnit(&pr);
    X[i] = (float)r1;
    Y[i] = (float)r2;
  }

  // Deterministic mixture into four Gaussian centers
  const float cx[4] = {0.2f, 0.8f, 0.2f, 0.8f};
  const float cy[4] = {0.2f, 0.2f, 0.8f, 0.8f};

  for (int i = 0; i < N; i++) {
    double r = nextRandUnit(&pr);
    if (r < 0.6) {
      uint64_t idr = nextRand64(&pr);
      int centerID = (int)(idr % 4ULL);
      double g = det_gauss(i, centerID);
      double g2 = det_gauss(i + N/7, centerID); // decorrelate X/Y offsets deterministically
      X[i] = (float)(cx[centerID] + 0.05 * g);
      Y[i] = (float)(cy[centerID] + 0.05 * g2);
    }
    // clamp to [0,1]
    if (X[i] < 0.0f) X[i] = 0.0f;
    if (X[i] > 1.0f) X[i] = 1.0f;
    if (Y[i] < 0.0f) Y[i] = 0.0f;
    if (Y[i] > 1.0f) Y[i] = 1.0f;
  }
}

static int max_abs_diff(const float *a, const float *b, size_t n, float *outMax) {
  float m = 0.0f;
  for (size_t i = 0; i < n; i++) {
    float d = fabsf(a[i] - b[i]);
    if (d > m) m = d;
  }
  if (outMax) *outMax = m;
  return (int)m;
}

int main(int argc, char **argv) {
  int N, T, reps;
  parse_args(argc, argv, &N, &T, &reps);

  const int K = 64;
  // C_out format: K*2 floats (x then y) assumed by the kernel
  // (matches typical benchmark conventions: C[k*2], C[k*2+1])

  float *X = (float *)malloc((size_t)N * sizeof(float));
  float *Y = (float *)malloc((size_t)N * sizeof(float));
  int *Aref = (int *)malloc((size_t)N * sizeof(int));
  int *Apar = (int *)malloc((size_t)N * sizeof(int));
  float *Cref = (float *)malloc((size_t)K * 2 * sizeof(float));
  float *Cpar = (float *)malloc((size_t)K * 2 * sizeof(float));

  if (!X || !Y || !Aref || !Apar || !Cref || !Cpar) {
    fprintf(stderr, "allocation failed\n");
    return 2;
  }

  generate_dataset(N, X, Y);

  // Reference once
  kmeans_assign_update_converge_serial(N, T, X, Y, Aref, Cref);

  const float tol = 1e-5f;

  int failures = 0;
  for (int r = 0; r < reps; r++) {
    memset(Apar, 0, (size_t)N * sizeof(int));
    memset(Cpar, 0, (size_t)K * 2 * sizeof(float));

    kmeans_assign_update_converge_omp(N, T, X, Y, Apar, Cpar);

    // Check assignments first for early exit
    int firstMismatch = -1;
    for (int i = 0; i < N; i++) {
      if (Apar[i] != Aref[i]) {
        firstMismatch = i;
        break;
      }
    }

    if (firstMismatch != -1) {
      failures = 1;
      printf("[check] divergence at assignment index %d (rep %d): got %d ref %d\n",
             firstMismatch, r, Apar[firstMismatch], Aref[firstMismatch]);
      break;
    }

    // Then check centroid coordinates within tolerance
    float maxd = 0.0f;
    int maxidx = -1;
    for (int i = 0; i < K * 2; i++) {
      float d = fabsf(Cpar[i] - Cref[i]);
      if (d > maxd) {
        maxd = d;
        maxidx = i;
      }
    }

    if (maxd > tol) {
      failures = 1;
      printf("[check] divergence at centroid coord %d (rep %d): max abs diff %.8g (tol %.8g)\n",
             maxidx, r, (double)maxd, (double)tol);
      break;
    }
  }

  free(X);
  free(Y);
  free(Aref);
  free(Apar);
  free(Cref);
  free(Cpar);

  if (failures) {
    printf("[verdict] SAFE-01 exposed\n");
    return 1;
  } else {
    printf("[verdict] SAFE-01 not triggered\n");
    return 0;
  }
}
