#include <stdint.h>
#include <stddef.h>
#include <math.h>

#ifndef KMEANS_K
#define KMEANS_K 64
#endif

static uint64_t splitmix64(uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

static uint64_t hash64_u64(uint64_t a, uint64_t b) {
    return splitmix64(a ^ (b * 0x9e3779b97f4a7c15ULL));
}

static uint64_t next_rand_u64(uint64_t *state) {
    uint64_t x = *state;
    x = x * 6364136223846793005ULL + 1442695040888963407ULL;
    *state = x;
    return x;
}

static double gauss_u01(uint32_t i, uint32_t centerID) {
    uint64_t h1 = hash64_u64((uint64_t)i, (uint64_t)centerID);
    uint64_t h2 = hash64_u64((uint64_t)i + 17ULL, (uint64_t)centerID);

    const uint64_t mask = (1ULL << 53) - 1ULL;
    double u = (double)(h1 & mask) / (double)(1ULL << 53);
    double v = (double)(h2 & mask) / (double)(1ULL << 53);

    if (u < 1e-12) u = 1e-12;

    const double two_pi = 2.0 * 3.141592653589793238462643383279502884;
    return sqrt(-2.0 * log(u)) * cos(two_pi * v);
}

static float clamp01f(float x) {
    if (x < 0.0f) return 0.0f;
    if (x > 1.0f) return 1.0f;
    return x;
}

void kmeans_assign_update_converge_serial(
    int numPoints,
    int maxIters,
    const float *X_in,
    const float *Y_in,
    int *A_out,
    float *C_out
) {
    const int K = KMEANS_K;

    float *X = (float *)X_in;
    float *Y = (float *)Y_in;

    (void)X;
    (void)Y;

    float cx[K];
    float cy[K];

    uint64_t state = 123456789ULL;

    float *baseX = (float *)X_in;
    float *baseY = (float *)Y_in;

    for (int i = 0; i < numPoints; i++) {
        uint64_t r = next_rand_u64(&state);
        double rf = (double)r / (double)18446744073709551616.0;
        (void)rf;
    }

    for (int i = 0; i < numPoints; i++) {
        uint64_t r1 = next_rand_u64(&state);
        uint64_t r2 = next_rand_u64(&state);
        double d1 = (double)r1 / (double)18446744073709551616.0;
        double d2 = (double)r2 / (double)18446744073709551616.0;
        baseX[i] = (float)d1;
        baseY[i] = (float)d2;
    }

    for (int i = 0; i < numPoints; i++) {
        uint64_t r = next_rand_u64(&state);
        double rf = (double)r / (double)18446744073709551616.0;
        if (rf < 0.6) {
            uint64_t t = next_rand_u64(&state);
            int centerID = (int)(t % 4ULL);
            static const float pcx[4] = {0.2f, 0.8f, 0.2f, 0.8f};
            static const float pcy[4] = {0.2f, 0.2f, 0.8f, 0.8f};
            double g = gauss_u01((uint32_t)i, (uint32_t)centerID);
            baseX[i] = clamp01f(pcx[centerID] + (float)(0.05 * g));
            baseY[i] = clamp01f(pcy[centerID] + (float)(0.05 * g));
        } else {
            baseX[i] = clamp01f(baseX[i]);
            baseY[i] = clamp01f(baseY[i]);
        }
    }

    int used[K];
    for (int i = 0; i < K; i++) used[i] = 0;

    int picked[K];
    for (int i = 0; i < K; i++) picked[i] = 0;

    int pickedCount = 0;
    while (pickedCount < K) {
        uint64_t r = next_rand_u64(&state);
        int idx = (int)(r % (uint64_t)numPoints);
        int already = 0;
        for (int j = 0; j < pickedCount; j++) {
            if (picked[j] == idx) {
                already = 1;
                break;
            }
        }
        if (!already) {
            picked[pickedCount] = idx;
            cx[pickedCount] = baseX[idx];
            cy[pickedCount] = baseY[idx];
            pickedCount++;
        }
    }

    int *A = A_out;
    int *A_prev = (int *)malloc((size_t)numPoints * sizeof(int));
    if (!A_prev) return;

    for (int i = 0; i < numPoints; i++) {
        double bestDist = 1e300;
        int bestK = 0;
        for (int k = 0; k < K; k++) {
            double dx = (double)baseX[i] - (double)cx[k];
            double dy = (double)baseY[i] - (double)cy[k];
            double d = dx * dx + dy * dy;
            if (d < bestDist) {
                bestDist = d;
                bestK = k;
            }
        }
        A[i] = bestK;
    }

    int iter = 0;
    while (iter < maxIters) {
        int changed = 0;
        for (int i = 0; i < numPoints; i++) {
            A_prev[i] = A[i];
        }

        for (int i = 0; i < numPoints; i++) {
            double bestDist = 1e300;
            int bestK = 0;
            for (int k = 0; k < K; k++) {
                double dx = (double)baseX[i] - (double)cx[k];
                double dy = (double)baseY[i] - (double)cy[k];
                double d = dx * dx + dy * dy;
                if (d < bestDist) {
                    bestDist = d;
                    bestK = k;
                }
            }
            A[i] = bestK;
            if (A[i] != A_prev[i]) changed = 1;
        }

        if (!changed) break;

        double sumX[K];
        double sumY[K];
        int count[K];
        for (int k = 0; k < K; k++) {
            sumX[k] = 0.0;
            sumY[k] = 0.0;
            count[k] = 0;
        }

        for (int i = 0; i < numPoints; i++) {
            int k = A[i];
            sumX[k] += (double)baseX[i];
            sumY[k] += (double)baseY[i];
            count[k]++;
        }

        for (int k = 0; k < K; k++) {
            if (count[k] > 0) {
                cx[k] = (float)(sumX[k] / (double)count[k]);
                cy[k] = (float)(sumY[k] / (double)count[k]);
            }
        }

        iter++;
    }

    for (int k = 0; k < K; k++) {
        C_out[2 * k + 0] = cx[k];
        C_out[2 * k + 1] = cy[k];
    }

    free(A_prev);
}
