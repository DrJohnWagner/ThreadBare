#include <math.h>
#include <stddef.h>
#include <omp.h>

typedef struct {
    double x;
    double y;
} point2d_t;

static double frac_sin_scaled(double x, double scale) {
    double s = sin(x);
    double p = s * scale;
    double f = p - floor(p);
    return f;
}

void kmeans_2d_omp(
    int n,
    int k,
    int max_iter,
    point2d_t *centroids_out,
    int *assign_out
) {
    const int K = 64;
    (void)k; /* k is always 64 per specification */
    if (n <= 0 || centroids_out == NULL || assign_out == NULL) return;

    point2d_t *points = (point2d_t *)malloc((size_t)n * sizeof(point2d_t));
    point2d_t *centroids = (point2d_t *)malloc((size_t)K * sizeof(point2d_t));
    int *assign = (int *)malloc((size_t)n * sizeof(int));
    int *prev_assign = (int *)malloc((size_t)n * sizeof(int));

    if (!points || !centroids || !assign || !prev_assign) {
        free(points);
        free(centroids);
        free(assign);
        free(prev_assign);
        return;
    }

    const int seed = 12345;
    for (int i = 0; i < n; i++) {
        double u = frac_sin_scaled((double)(i + 1) * 12.9898 + (double)seed, 43758.5453);
        double v = frac_sin_scaled((double)(i + 1) * 78.233 + (double)seed, 9631.123);
        double w = frac_sin_scaled((double)(i + 1) * 45.164 + (double)seed, 3412.987);

        int t = (int)floor(3.0 * w);
        if (t < 0) t = 0;
        if (t > 2) t = 2;

        double cx, cy;
        if (t == 0) { cx = 0.0; cy = 0.0; }
        else if (t == 1) { cx = 5.0; cy = 5.0; }
        else { cx = -5.0; cy = 5.0; }

        double x = cx + 1.0 * ((u - 0.5) * 2.0);
        double y = cy + 1.0 * ((v - 0.5) * 2.0);

        points[i].x = x;
        points[i].y = y;
    }

    if (n < K) {
        for (int j = 0; j < K; j++) {
            int idx = j % n;
            centroids[j] = points[idx];
        }
    } else {
        for (int j = 0; j < K; j++) {
            centroids[j] = points[j];
        }
    }

    /* Initial assignment */
    #pragma omp parallel for schedule(static)
    for (int i = 0; i < n; i++) {
        double best_d = 0.0;
        int best_j = 0;
        for (int j = 0; j < K; j++) {
            double dx = points[i].x - centroids[j].x;
            double dy = points[i].y - centroids[j].y;
            double d = dx * dx + dy * dy;
            if (j == 0 || d < best_d) {
                best_d = d;
                best_j = j;
            }
        }
        assign[i] = best_j;
    }

    for (int iter = 0; iter < max_iter; iter++) {
        int changed = 0;

        #pragma omp parallel for schedule(static)
        for (int i = 0; i < n; i++) {
            prev_assign[i] = assign[i];
        }

        /* Phase A: re-assign points + detect any change (global OR). */
        #pragma omp parallel for reduction(| : changed) schedule(static)
        for (int i = 0; i < n; i++) {
            double best_d = 0.0;
            int best_j = 0;
            for (int j = 0; j < K; j++) {
                double dx = points[i].x - centroids[j].x;
                double dy = points[i].y - centroids[j].y;
                double d = dx * dx + dy * dy;
                if (j == 0 || d < best_d) {
                    best_d = d;
                    best_j = j;
                }
            }
            assign[i] = best_j;
            if (assign[i] != prev_assign[i]) changed = 1;
        }

        if (!changed) break;

        /* Phase B: recompute centroids. */
        double sum_x[K];
        double sum_y[K];
        int count[K];
        for (int j = 0; j < K; j++) {
            sum_x[j] = 0.0;
            sum_y[j] = 0.0;
            count[j] = 0;
        }

        /* Parallel accumulation with per-thread local buffers to match sequential order-insensitive semantics. */
        int max_threads = 1;
        #pragma omp parallel
        {
            #pragma omp single
            max_threads = omp_get_num_threads();
        }

        double *tls_sum_x = (double *)calloc((size_t)max_threads * (size_t)K, sizeof(double));
        double *tls_sum_y = (double *)calloc((size_t)max_threads * (size_t)K, sizeof(double));
        int *tls_count = (int *)calloc((size_t)max_threads * (size_t)K, sizeof(int));

        if (tls_sum_x && tls_sum_y && tls_count) {
            #pragma omp parallel
            {
                int tid = omp_get_thread_num();
                double *lpx = tls_sum_x + (size_t)tid * (size_t)K;
                double *lpy = tls_sum_y + (size_t)tid * (size_t)K;
                int *lcnt = tls_count + (size_t)tid * (size_t)K;

                #pragma omp for schedule(static)
                for (int i = 0; i < n; i++) {
                    int j = assign[i];
                    if (j < 0) j = 0;
                    if (j >= K) j = K - 1;
                    lpx[j] += points[i].x;
                    lpy[j] += points[i].y;
                    lcnt[j] += 1;
                }
            }

            for (int j = 0; j < K; j++) {
                double sx = 0.0, sy = 0.0;
                int c = 0;
                for (int t = 0; t < max_threads; t++) {
                    sx += tls_sum_x[(size_t)t * (size_t)K + (size_t)j];
                    sy += tls_sum_y[(size_t)t * (size_t)K + (size_t)j];
                    c += tls_count[(size_t)t * (size_t)K + (size_t)j];
                }
                sum_x[j] = sx;
                sum_y[j] = sy;
                count[j] = c;
            }
        } else {
            /* Fallback: still parallel, using atomics. */
            #pragma omp parallel for schedule(static)
            for (int i = 0; i < n; i++) {
                int j = assign[i];
                if (j < 0) j = 0;
                if (j >= K) j = K - 1;
                #pragma omp atomic
                sum_x[j] += points[i].x;
                #pragma omp atomic
                sum_y[j] += points[i].y;
                #pragma omp atomic
                count[j] += 1;
            }
        }

        free(tls_sum_x);
        free(tls_sum_y);
        free(tls_count);

        for (int j = 0; j < K; j++) {
            if (count[j] > 0) {
                centroids[j].x = sum_x[j] / (double)count[j];
                centroids[j].y = sum_y[j] / (double)count[j];
            }
        }
    }

    for (int j = 0; j < K; j++) {
        centroids_out[j] = centroids[j];
    }
    #pragma omp parallel for schedule(static)
    for (int i = 0; i < n; i++) {
        assign_out[i] = assign[i];
    }

    free(points);
    free(centroids);
    free(assign);
    free(prev_assign);
}
