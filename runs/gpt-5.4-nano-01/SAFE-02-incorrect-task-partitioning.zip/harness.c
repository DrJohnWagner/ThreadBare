/* harness.c — differential driver for kmeans_2d (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

typedef struct { double x; double y; } point2d_t;

void kmeans_2d_serial(int n, int k, int max_iter, point2d_t *centroids_out, int *assign_out);
void kmeans_2d_omp(int n, int k, int max_iter, point2d_t *centroids_out, int *assign_out);

static void usage(const char *prog) {
  fprintf(stderr,
          "Usage: %s [--n <points>] [--reps <repetitions>] [--k <k>] [--max_iter <iters>] [--threads <t>]\n",
          prog);
}

static unsigned long long splitmix64(unsigned long long *x) {
  unsigned long long z = (*x += 0x9e3779b97f4a7c15ULL);
  z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
  z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
  return z ^ (z >> 31);
}

static double frac(double a) {
  double f = a - floor(a);
  if (f < 0) f += 1.0;
  return f;
}

int main(int argc, char **argv) {
  int n = 2000000;          /* default: largest in spec */
  int k = 64;
  int max_iter = 50;       /* safety cap; both versions should honor it */
  int reps = 20;           /* multiple runs to catch nondeterminism; also catches early termination issues */

  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--n") && i + 1 < argc) {
      n = atoi(argv[++i]);
    } else if (!strcmp(argv[i], "--k") && i + 1 < argc) {
      k = atoi(argv[++i]);
    } else if (!strcmp(argv[i], "--max_iter") && i + 1 < argc) {
      max_iter = atoi(argv[++i]);
    } else if (!strcmp(argv[i], "--reps") && i + 1 < argc) {
      reps = atoi(argv[++i]);
    } else if (!strcmp(argv[i], "--threads") && i + 1 < argc) {
      int t = atoi(argv[++i]);
      if (t > 0) omp_set_num_threads(t);
    } else if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) {
      usage(argv[0]);
      return 0;
    } else {
      usage(argv[0]);
      return 2;
    }
  }

  if (k != 64) {
    /* Spec fixes k=64; keep harness aligned with planted failure scenario. */
    fprintf(stderr, "[warn] this harness is designed for k=64; got k=%d\n", k);
  }

  /* The serial/parallel kernels are expected to use the same synthetic input generation internally
     as in the course benchmark. We only need to drive them and compare outputs. */

  point2d_t *centroids_ref = (point2d_t*)malloc((size_t)k * sizeof(point2d_t));
  point2d_t *centroids_par = (point2d_t*)malloc((size_t)k * sizeof(point2d_t));
  int *assign_ref = (int*)malloc((size_t)n * sizeof(int));
  int *assign_par = (int*)malloc((size_t)n * sizeof(int));
  if (!centroids_ref || !centroids_par || !assign_ref || !assign_par) {
    fprintf(stderr, "allocation failed\n");
    return 2;
  }

  /* Ground truth */
  kmeans_2d_serial(n, k, max_iter, centroids_ref, assign_ref);

  int failures = 0;
  for (int r = 0; r < reps; r++) {
    memset(centroids_par, 0, (size_t)k * sizeof(point2d_t));
    memset(assign_par, 0, (size_t)n * sizeof(int));
    kmeans_2d_omp(n, k, max_iter, centroids_par, assign_par);

    int first_i = -1;
    for (int i = 0; i < n; i++) {
      if (assign_par[i] != assign_ref[i]) {
        first_i = i;
        break;
      }
    }

    if (first_i != -1) {
      failures = 1;
      printf("[check] rep=%d divergence at i=%d ref=%d par=%d\n", r, first_i, assign_ref[first_i], assign_par[first_i]);
      break;
    }
  }

  /* Optionally validate centroids if assignments match; but primary criterion is assignments.
     If it mismatched, centroid mismatch is likely as well, so skip to keep runtime low. */
  if (!failures) {
    /* Do one extra centroid check for completeness on the last parallel run. */
    /* Since assignment matches, centroid should match closely (or exactly if deterministic arithmetic is used). */
    for (int j = 0; j < k; j++) {
      double dx = fabs(centroids_par[j].x - centroids_ref[j].x);
      double dy = fabs(centroids_par[j].y - centroids_ref[j].y);
      if (dx > 1e-9 || dy > 1e-9) {
        failures = 1;
        printf("[check] centroid mismatch at j=%d ref=(%.17g,%.17g) par=(%.17g,%.17g)\n",
               j,
               centroids_ref[j].x, centroids_ref[j].y,
               centroids_par[j].x, centroids_par[j].y);
        break;
      }
    }
  }

  free(centroids_ref);
  free(centroids_par);
  free(assign_ref);
  free(assign_par);

  printf("[verdict] %s\n", failures ? "SAFE-01 exposed" : "SAFE-01 not triggered");
  return failures ? 1 : 0;
}
