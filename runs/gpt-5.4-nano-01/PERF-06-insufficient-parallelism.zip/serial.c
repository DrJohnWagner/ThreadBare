#include <stddef.h>
#include <stdint.h>
#include <math.h>

void kmeans_lloyd_serial(int N, int k,
                         const float *x, const float *y,
                         float *cx, float *cy,
                         int *a)
{
    if (N <= 0 || k <= 0) {
        return;
    }

    int maxIter = 1000;
    int iter = 0;

    int *new_a = (int *)malloc((size_t)N * sizeof(int));
    if (!new_a) {
        return;
    }

    float *sumx = (float *)malloc((size_t)k * sizeof(float));
    float *sumy = (float *)malloc((size_t)k * sizeof(float));
    int *count = (int *)malloc((size_t)k * sizeof(int));
    if (!sumx || !sumy || !count) {
        free(new_a);
        free(sumx);
        free(sumy);
        free(count);
        return;
    }

    for (int i = 0; i < N; i++) {
        a[i] = 0;
        new_a[i] = 0;
    }

    while (iter < maxIter) {
        int anyChange = 0;

        for (int j = 0; j < N; j++) {
            float bestDist = (x[j] - cx[0]) * (x[j] - cx[0]) + (y[j] - cy[0]) * (y[j] - cy[0]);
            int bestIdx = 0;
            for (int i = 1; i < k; i++) {
                float dx = x[j] - cx[i];
                float dy = y[j] - cy[i];
                float d = dx * dx + dy * dy;
                if (d < bestDist) {
                    bestDist = d;
                    bestIdx = i;
                }
            }
            new_a[j] = bestIdx;
            if (new_a[j] != a[j]) {
                anyChange = 1;
            }
        }

        for (int i = 0; i < k; i++) {
            sumx[i] = 0.0f;
            sumy[i] = 0.0f;
            count[i] = 0;
        }

        for (int j = 0; j < N; j++) {
            int idx = new_a[j];
            sumx[idx] += x[j];
            sumy[idx] += y[j];
            count[idx] += 1;
        }

        for (int i = 0; i < k; i++) {
            if (count[i] > 0) {
                cx[i] = sumx[i] / (float)count[i];
                cy[i] = sumy[i] / (float)count[i];
            }
        }

        for (int j = 0; j < N; j++) {
            a[j] = new_a[j];
        }

        if (!anyChange) {
            break;
        }

        iter++;
    }

    free(new_a);
    free(sumx);
    free(sumy);
    free(count);
}
