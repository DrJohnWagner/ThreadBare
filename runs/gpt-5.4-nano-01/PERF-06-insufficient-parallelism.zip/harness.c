/* harness.c — scaling driver for kmeans_lloyd (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

// Forward declarations matching serial.c / parallel.c real signatures
void kmeans_lloyd_serial(int N, int k, const float *x, const float *y, float *cx, float *cy, int *a);
void kmeans_lloyd_omp(int N, int k, const float *x, const float *y, float *cx, float *cy, int *a);

static void usage(const char *prog) {
  printf("Usage: %s [--n N] [--k K] [--warmup-iters W] [--seed S]\n", prog);
}

static unsigned int lcg_next(unsigned int *s) {
  // state s = (1103515245*s + 12345) mod 2^31
  // use uint32, then mask to 31 bits
  unsigned int x = *s;
  x = (1103515245u * x + 12345u) & 0x7fffffffu;
  *s = x;
  return x;
}

static float lcg_uniform01(unsigned int *s) {
  unsigned int v = lcg_next(s); // [0, 2^31)
  return (float)((double)v / 2147483648.0);
}

static void generate_input(int N, int k, float *x, float *y, float *cx0, float *cy0, int *a_dummy) {
  (void)a_dummy;
  const unsigned int S = 1234567u;
  unsigned int st = S;

  // Latent cluster centers
  float *center_x = (float*)malloc((size_t)k * sizeof(float));
  float *center_y = (float*)malloc((size_t)k * sizeof(float));
  if (!center_x || !center_y) {
    fprintf(stderr, "malloc failed\n");
    exit(2);
  }

  for (int i = 0; i < k; i++) {
    float u1 = lcg_uniform01(&st);
    float u2 = lcg_uniform01(&st);
    center_x[i] = 100.0f * (u1 * 2.0f - 1.0f);
    center_y[i] = 100.0f * (u2 * 2.0f - 1.0f);
  }

  // Points
  const float sigma = 5.0f;
  for (int j = 0; j < N; j++) {
    float u3 = lcg_uniform01(&st);
    int t = (int)floorf(u3 * (float)k);
    if (t < 0) t = 0;
    if (t >= k) t = k - 1;

    // Box-Muller using two LCG draws mapped to [0,1)
    // z0 = sqrt(-2 ln u1) cos(2pi u2)
    // z1 = sqrt(-2 ln u1) sin(2pi u2)
    float u1 = lcg_uniform01(&st);
    float u2 = lcg_uniform01(&st);
    // Avoid log(0)
    if (u1 < 1e-7f) u1 = 1e-7f;

    float r = sqrtf(-2.0f * logf(u1));
    float theta = 2.0f * (float)M_PI * u2;
    float z0 = r * cosf(theta);
    float z1 = r * sinf(theta);

    float dx = sigma * z0;
    float dy = sigma * z1;

    x[j] = center_x[t] + dx;
    y[j] = center_y[t] + dy;
  }

  // Initial centroid positions from points: idx = (i * 9973) mod N
  for (int i = 0; i < k; i++) {
    long long idx = (long long)i * 9973LL;
    idx %= (long long)N;
    cx0[i] = x[idx];
    cy0[i] = y[idx];
  }

  free(center_x);
  free(center_y);
}

static double now_sec(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

static int check_correctness(int N, int k, const float *x, const float *y, float *cx_ref, float *cy_ref, int *a_ref,
                               float *cx_par, float *cy_par, int *a_par) {
  const float tol = 1e-4f;

  // Verify assignment array exactly matches argmin over centroids for the parallel result,
  // and centroids equal means of assigned points.
  // Also compare parallel outputs against reference.

  for (int i = 0; i < k; i++) {
    if (fabsf(cx_par[i] - cx_ref[i]) > tol || fabsf(cy_par[i] - cy_ref[i]) > tol) {
      printf("[check] centroid mismatch at i=%d cx %.8g vs %.8g cy %.8g vs %.8g\n",
             i, cx_par[i], cx_ref[i], cy_par[i], cy_ref[i]);
      return 1;
    }
  }

  for (int j = 0; j < N; j++) {
    if (a_par[j] != a_ref[j]) {
      printf("[check] assignment mismatch at j=%d par=%d ref=%d\n", j, a_par[j], a_ref[j]);
      return 1;
    }
  }

  // Extra verification of centroid means for the parallel outputs (more diagnostic).
  // Compute sequentially with deterministic order.
  float *sumx = (float*)calloc((size_t)k, sizeof(float));
  float *sumy = (float*)calloc((size_t)k, sizeof(float));
  int *cnt = (int*)calloc((size_t)k, sizeof(int));
  if (!sumx || !sumy || !cnt) {
    fprintf(stderr, "calloc failed\n");
    exit(3);
  }

  for (int j = 0; j < N; j++) {
    int c = a_par[j];
    cnt[c]++;
    sumx[c] += x[j];
    sumy[c] += y[j];
  }

  // If count==0, centroid remains unchanged from its previous recomputation step.
  // We don't have those intermediate values here; but since we already compared against
  // reference output and assignments, this should be consistent. Still, we enforce means for non-empty.
  for (int i = 0; i < k; i++) {
    if (cnt[i] > 0) {
      float meanx = sumx[i] / (float)cnt[i];
      float meany = sumy[i] / (float)cnt[i];
      if (fabsf(cx_par[i] - meanx) > tol || fabsf(cy_par[i] - meany) > tol) {
        printf("[check] mean mismatch at i=%d got(cx,cy)=(%.8g,%.8g) exp=(%.8g,%.8g) cnt=%d\n",
               i, cx_par[i], cy_par[i], meanx, meany, cnt[i]);
        free(sumx); free(sumy); free(cnt);
        return 1;
      }
    }
  }

  free(sumx); free(sumy); free(cnt);
  return 0;
}

int main(int argc, char **argv) {
  int N = 262144; // default to largest manageable size from spec
  int k = 64;
  int reps = 1;
  int warmup_passes = 1;

  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--n") && i + 1 < argc) {
      N = atoi(argv[++i]);
    } else if (!strcmp(argv[i], "--k") && i + 1 < argc) {
      k = atoi(argv[++i]);
    } else if (!strcmp(argv[i], "--warmup-iters") && i + 1 < argc) {
      warmup_passes = atoi(argv[++i]);
    } else if (!strcmp(argv[i], "--reps") && i + 1 < argc) {
      reps = atoi(argv[++i]);
    } else if (!strcmp(argv[i], "--help")) {
      usage(argv[0]);
      return 0;
    } else {
      usage(argv[0]);
      return 1;
    }
  }

  if (N <= 0 || k <= 0) {
    fprintf(stderr, "Invalid N or k\n");
    return 1;
  }

  float *x = (float*)malloc((size_t)N * sizeof(float));
  float *y = (float*)malloc((size_t)N * sizeof(float));
  float *cx0 = (float*)malloc((size_t)k * sizeof(float));
  float *cy0 = (float*)malloc((size_t)k * sizeof(float));
  int *a0 = (int*)malloc((size_t)N * sizeof(int));
  if (!x || !y || !cx0 || !cy0 || !a0) {
    fprintf(stderr, "malloc failed\n");
    return 2;
  }

  // Generate deterministic input
  generate_input(N, k, x, y, cx0, cy0, a0);

  // Warmup: touch + run one untimed pass to page-fault/cache-fill outside measurement
  // Use single thread to avoid mixing timing effects.
  omp_set_num_threads(1);
  for (int j = 0; j < N; j += 4096) {
    a0[j] = 0;
  }

  float *cx_tmp = (float*)malloc((size_t)k * sizeof(float));
  float *cy_tmp = (float*)malloc((size_t)k * sizeof(float));
  int *a_tmp = (int*)malloc((size_t)N * sizeof(int));
  if (!cx_tmp || !cy_tmp || !a_tmp) {
    fprintf(stderr, "malloc failed\n");
    return 2;
  }

  for (int w = 0; w < warmup_passes; w++) {
    memcpy(cx_tmp, cx0, (size_t)k * sizeof(float));
    memcpy(cy_tmp, cy0, (size_t)k * sizeof(float));
    kmeans_lloyd_omp(N, k, x, y, cx_tmp, cy_tmp, a_tmp);
  }

  // Baseline serial (measured once)
  float *cx_ser = (float*)malloc((size_t)k * sizeof(float));
  float *cy_ser = (float*)malloc((size_t)k * sizeof(float));
  int *a_ser = (int*)malloc((size_t)N * sizeof(int));
  float *cx_par = (float*)malloc((size_t)k * sizeof(float));
  float *cy_par = (float*)malloc((size_t)k * sizeof(float));
  int *a_par = (int*)malloc((size_t)N * sizeof(int));
  if (!cx_ser || !cy_ser || !a_ser || !cx_par || !cy_par || !a_par) {
    fprintf(stderr, "malloc failed\n");
    return 2;
  }

  memcpy(cx_ser, cx0, (size_t)k * sizeof(float));
  memcpy(cy_ser, cy0, (size_t)k * sizeof(float));

  double t_ser;
  {
    double t0 = now_sec();
    kmeans_lloyd_serial(N, k, x, y, cx_ser, cy_ser, a_ser);
    t_ser = now_sec() - t0;
  }

  // Light correctness check at max threads (just one run)
  int max_threads = omp_get_max_threads();

  // Build thread count list: 1,2,4,... <= max
  int lastT = 1;
  int pow2 = 1;
  while (pow2 * 2 <= max_threads) pow2 *= 2;
  lastT = pow2;

  // Ensure at least 1 thread
  if (lastT < 1) lastT = 1;

  double best_eff = 1e100;
  double best_speedup = 1.0;
  int best_threads = 1;

  for (int T = 1; T <= max_threads; T <<= 1) {
    if (T > lastT) break;
    omp_set_num_threads(T);

    memcpy(cx_par, cx0, (size_t)k * sizeof(float));
    memcpy(cy_par, cy0, (size_t)k * sizeof(float));

    double t_par = 0.0;
    // reps can be used for stability; keep default 1 in this course-style harness
    for (int r = 0; r < reps; r++) {
      double t0 = now_sec();
      kmeans_lloyd_omp(N, k, x, y, cx_par, cy_par, a_par);
      t_par += now_sec() - t0;
    }
    t_par /= (double)reps;

    double speedup = t_ser / t_par;
    double eff = speedup / (double)T;

    printf("[scale] threads=%d time=%.6f speedup=%.3f eff=%.4f\n", T, t_par, speedup, eff);

    if (T == lastT) {
      best_eff = eff;
      best_speedup = speedup;
      best_threads = T;
    }
  }

  int failures = 0;

  // Correctness check once at highest threads
  omp_set_num_threads(best_threads);
  memcpy(cx_par, cx0, (size_t)k * sizeof(float));
  memcpy(cy_par, cy0, (size_t)k * sizeof(float));
  kmeans_lloyd_omp(N, k, x, y, cx_par, cy_par, a_par);

  failures |= check_correctness(N, k, x, y, cx_ser, cy_ser, a_ser, cx_par, cy_par, a_par);

  // Performance verdict: expected to scale poorly when insufficient parallelism is planted.
  // We flag failure when efficiency at max threads is too low.
  // Threshold chosen to be robust: ideal eff ~ 1.0; heavily bottlenecked eff often < 0.2.
  const double eff_threshold = 0.20;
  if (!failures) {
    if (best_eff < eff_threshold) {
      failures = 1;
    }
  }

  printf("[verdict] %s\n", failures ? "PERF-01 exposed" : "PERF-01 not triggered");

  free(x); free(y); free(cx0); free(cy0); free(a0);
  free(cx_tmp); free(cy_tmp); free(a_tmp);
  free(cx_ser); free(cy_ser); free(a_ser);
  free(cx_par); free(cy_par); free(a_par);

  return failures ? 1 : 0;
}
