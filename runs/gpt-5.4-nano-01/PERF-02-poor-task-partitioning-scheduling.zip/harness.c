/* harness.c — scaling driver for bfs_parent_hops (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

// Forward declarations matching the real signatures
int bfs_parent_hops_serial(int N, int M, int S,
                           int **row_ptr_out,
                           int **col_idx_out,
                           int *sources_out,
                           int **dist_out,
                           int **parent_out);

int bfs_parent_hops_omp(int N, int M, int S,
                       int **row_ptr_out,
                       int **col_idx_out,
                       int *sources_out,
                       int **dist_out,
                       int **parent_out);

static inline uint64_t splitmix64(uint64_t *x) {
    uint64_t z = (*x += 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}

typedef struct { int v; int deg; } KV;

static int cmp_int(const void *a, const void *b) {
    int ia = *(const int*)a;
    int ib = *(const int*)b;
    return (ia>ib) - (ia<ib);
}

static void generate_graph_powerlaw_csr(
    int N, int M, uint64_t seed,
    int **row_ptr_ptr, int **col_idx_ptr)
{
    // We will generate edges and build CSR.
    // First pass: compute out-degree.
    int *outdeg = (int*)calloc((size_t)N, sizeof(int));
    if (!outdeg) { fprintf(stderr, "OOM outdeg\n"); exit(1); }

    uint64_t rng = seed;
    const double alpha = 2.5;
    const double kmin = 1.0;
    const double kmax = (double)N - 1.0;
    const double inv_exp = 1.0/(1.0 - alpha); // 1/(1-alpha)
    const double c1 = pow(kmin, (1.0 - alpha));
    const double c2 = pow(kmax, (1.0 - alpha));

    // Temporary arrays for degree proxy? no, compute u once per edge and count outdeg.
    for (int e = 0; e < M; ++e) {
        uint64_t r1 = splitmix64(&rng);
        double U01 = (double)(r1 >> 11) * (1.0/9007199254740992.0); // 53-bit

        double inner = c1 - U01 * (c1 - c2);
        double k = pow(inner, inv_exp);
        if (k < 1.0) k = 1.0;
        int u = (int)((uint64_t)k % (uint64_t)N);

        uint64_t r2 = splitmix64(&rng);
        int next_u = (int)(r2 % (uint64_t)N);
        int pv = (int)(splitmix64(&rng) % 1000ULL);
        (void)next_u; (void)pv;

        // v generation consumes more RNG even if unused. Match the spec closely.
        uint64_t r3 = splitmix64(&rng);
        (void)r3;

        // The spec's v uses next_u and another draw next_u% (N-1), plus condition pv=0.15.
        // We'll reproduce without storing v here (second pass will regenerate full edge list).
        outdeg[u]++;

        // To keep RNG consumption consistent with second pass we must mimic exactly.
        // We already consumed 3 splitmix64 calls above; second pass will do same sequence.
        // Let's ensure we used r1 (U01), r2(next_u), r3(dummy). Need also the Bernoulli draw pv.
        // We used pv from splitmix64 already, and r3 as additional draw; still missing one more for next_u%(N-1).
        // Correct approach: implement v generation exactly in both passes.
    }

    // The above attempt for RNG consumption got messy. Let's instead regenerate degrees with exact spec
    // using a single deterministic generation that also matches the second pass.
    // We'll redo the degree pass properly.
    free(outdeg);
    outdeg = (int*)calloc((size_t)N, sizeof(int));
    if (!outdeg) { fprintf(stderr, "OOM outdeg2\n"); exit(1); }

    rng = seed;
    for (int e = 0; e < M; ++e) {
        uint64_t rU = splitmix64(&rng);
        double U01 = (double)(rU >> 11) * (1.0/9007199254740992.0);
        double inner = c1 - U01 * (c1 - c2);
        double k = pow(inner, inv_exp);
        if (k < 1.0) k = 1.0;
        int u = (int)((uint64_t)k % (uint64_t)N);

        uint64_t rNext = splitmix64(&rng);
        int next_u = (int)(rNext % (uint64_t)N);

        uint64_t rBern = splitmix64(&rng);
        int pv_draw = (int)(rBern % 1000ULL);
        // if pv=0.15 then pv_draw < 150
        int v;
        if (pv_draw < 150) {
            uint64_t rExtra = splitmix64(&rng);
            v = (u + 1 + (int)(rExtra % (uint64_t)(N - 1))) % N;
        } else {
            v = next_u % N;
        }
        (void)v;
        outdeg[u]++;
    }

    // Build CSR row_ptr
    int *row_ptr = (int*)malloc((size_t)(N + 1) * sizeof(int));
    if (!row_ptr) { fprintf(stderr, "OOM row_ptr\n"); exit(1); }
    row_ptr[0] = 0;
    for (int i = 0; i < N; ++i) row_ptr[i+1] = row_ptr[i] + outdeg[i];
    if (row_ptr[N] != M) {
        // Should match by construction; if not, something is wrong.
        fprintf(stderr, "CSR edge count mismatch: got %d expected %d\n", row_ptr[N], M);
        exit(1);
    }

    int *col_idx = (int*)malloc((size_t)M * sizeof(int));
    if (!col_idx) { fprintf(stderr, "OOM col_idx\n"); exit(1); }

    // Fill CSR using second pass with same RNG consumption pattern
    int *cursor = (int*)malloc((size_t)N * sizeof(int));
    if (!cursor) { fprintf(stderr, "OOM cursor\n"); exit(1); }
    memcpy(cursor, row_ptr, (size_t)N * sizeof(int));

    rng = seed;
    for (int e = 0; e < M; ++e) {
        uint64_t rU = splitmix64(&rng);
        double U01 = (double)(rU >> 11) * (1.0/9007199254740992.0);
        double inner = c1 - U01 * (c1 - c2);
        double k = pow(inner, inv_exp);
        if (k < 1.0) k = 1.0;
        int u = (int)((uint64_t)k % (uint64_t)N);

        uint64_t rNext = splitmix64(&rng);
        int next_u = (int)(rNext % (uint64_t)N);

        uint64_t rBern = splitmix64(&rng);
        int pv_draw = (int)(rBern % 1000ULL);
        int v;
        if (pv_draw < 150) {
            uint64_t rExtra = splitmix64(&rng);
            v = (u + 1 + (int)(rExtra % (uint64_t)(N - 1))) % N;
        } else {
            v = next_u % N;
        }

        int pos = cursor[u]++;
        col_idx[pos] = v;

        (void)e;
    }

    free(cursor);
    free(outdeg);

    // API expects int**: likely pointers to arrays. We'll allocate wrapper pointers.
    int **row_ptr_out = (int**)malloc(sizeof(int*));
    int **col_idx_out = (int**)malloc(sizeof(int*));
    if (!row_ptr_out || !col_idx_out) { fprintf(stderr, "OOM wrappers\n"); exit(1); }
    row_ptr_out[0] = row_ptr;
    col_idx_out[0] = col_idx;

    *row_ptr_ptr = row_ptr_out[0];
    *col_idx_ptr = col_idx_out[0];

    // But signatures above declare int**. We'll pass the pointers directly by allocating arrays of size 1.
    // To keep simple, caller will treat them as int** with index 0.
    free(row_ptr_out);
    free(col_idx_out);
}

static void choose_sources(int N, int S, uint64_t seed, int *sources_out) {
    uint64_t rng = seed;
    int count = 0;
    int *seen = (int*)calloc((size_t)N, sizeof(int));
    if (!seen) { fprintf(stderr, "OOM seen\n"); exit(1); }
    while (count < S) {
        uint64_t r = splitmix64(&rng);
        int s = (int)(r % (uint64_t)N);
        if (!seen[s]) {
            seen[s] = 1;
            sources_out[count++] = s;
        }
    }
    free(seen);
}

static void bfs_level_order_single(const int N, const int *row_ptr, const int *col_idx,
                                    int source, int *dist)
{
    int *queue = (int*)malloc((size_t)N * sizeof(int));
    int *front = (int*)malloc((size_t)N * sizeof(int));
    int *next = (int*)malloc((size_t)N * sizeof(int));
    if (!queue || !front || !next) { fprintf(stderr, "OOM bfs tmp\n"); exit(1); }

    for (int i = 0; i < N; ++i) dist[i] = -1;
    int fsz = 1;
    front[0] = source;
    dist[source] = 0;

    int d = 0;
    while (fsz > 0) {
        int nsz = 0;
        for (int i = 0; i < fsz; ++i) {
            int u = front[i];
            int start = row_ptr[u];
            int end = row_ptr[u+1];
            for (int ei = start; ei < end; ++ei) {
                int v = col_idx[ei];
                if (dist[v] == -1) {
                    dist[v] = d + 1;
                    next[nsz++] = v;
                }
            }
        }
        ++d;
        int *tmp = front; front = next; next = tmp;
        fsz = nsz;
    }

    free(queue); free(front); free(next);
}

static double now_seconds(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + 1e-9 * (double)ts.tv_nsec;
}

int main(int argc, char **argv) {
    int N = 310000;
    int M = 5000000;
    int S = 20;
    int reps = 1; // scaling requires only light correctness check

    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            N = atoi(argv[++i]);
            if (N == 50000) M = 500000;
            else if (N == 100000) M = 1000000;
            else M = 5000000;
        } else if (strcmp(argv[i], "--reps") == 0 && i + 1 < argc) {
            reps = atoi(argv[++i]);
        }
    }

    // Generate deterministic graph
    uint64_t seed_graph = 123456789ULL;
    int *row_ptr = NULL;
    int *col_idx = NULL;

    // Use CSR generator but since the function above allocates wrappers oddly,
    // we'll implement CSR here directly with correct allocation.
    // (Keep minimal: call generator and then treat returned row_ptr/col_idx via wrappers approach.)

    // Re-implement CSR generation cleanly here for correct pointer passing.
    int *outdeg = (int*)calloc((size_t)N, sizeof(int));
    if (!outdeg) { fprintf(stderr, "OOM outdeg\n"); return 1; }

    uint64_t rng = seed_graph;
    const double alpha = 2.5;
    const double kmin = 1.0;
    const double kmax = (double)N - 1.0;
    const double inv_exp = 1.0/(1.0 - alpha);
    const double c1 = pow(kmin, (1.0 - alpha));
    const double c2 = pow(kmax, (1.0 - alpha));

    for (int e = 0; e < M; ++e) {
        uint64_t rU = splitmix64(&rng);
        double U01 = (double)(rU >> 11) * (1.0/9007199254740992.0);
        double inner = c1 - U01 * (c1 - c2);
        double k = pow(inner, inv_exp);
        if (k < 1.0) k = 1.0;
        int u = (int)((uint64_t)k % (uint64_t)N);

        uint64_t rNext = splitmix64(&rng);
        int next_u = (int)(rNext % (uint64_t)N);

        uint64_t rBern = splitmix64(&rng);
        int pv_draw = (int)(rBern % 1000ULL);
        if (pv_draw < 150) {
            (void)next_u;
            uint64_t rExtra = splitmix64(&rng);
            (void)rExtra;
        }
        outdeg[u]++;
    }

    int *row_ptr_clean = (int*)malloc((size_t)(N + 1) * sizeof(int));
    if (!row_ptr_clean) { fprintf(stderr, "OOM row_ptr\n"); return 1; }
    row_ptr_clean[0] = 0;
    for (int i = 0; i < N; ++i) row_ptr_clean[i+1] = row_ptr_clean[i] + outdeg[i];
    if (row_ptr_clean[N] != M) {
        fprintf(stderr, "Edge count mismatch N=%d M=%d got=%d\n", N, M, row_ptr_clean[N]);
        return 1;
    }

    int *col_idx_clean = (int*)malloc((size_t)M * sizeof(int));
    if (!col_idx_clean) { fprintf(stderr, "OOM col_idx\n"); return 1; }
    int *cursor = (int*)malloc((size_t)N * sizeof(int));
    if (!cursor) { fprintf(stderr, "OOM cursor\n"); return 1; }
    memcpy(cursor, row_ptr_clean, (size_t)N * sizeof(int));

    rng = seed_graph;
    for (int e = 0; e < M; ++e) {
        uint64_t rU = splitmix64(&rng);
        double U01 = (double)(rU >> 11) * (1.0/9007199254740992.0);
        double inner = c1 - U01 * (c1 - c2);
        double k = pow(inner, inv_exp);
        if (k < 1.0) k = 1.0;
        int u = (int)((uint64_t)k % (uint64_t)N);

        uint64_t rNext = splitmix64(&rng);
        int next_u = (int)(rNext % (uint64_t)N);

        uint64_t rBern = splitmix64(&rng);
        int pv_draw = (int)(rBern % 1000ULL);
        int v;
        if (pv_draw < 150) {
            uint64_t rExtra = splitmix64(&rng);
            v = (u + 1 + (int)(rExtra % (uint64_t)(N - 1))) % N;
        } else {
            v = next_u % N;
        }

        int pos = cursor[u]++;
        col_idx_clean[pos] = v;

        (void)e;
    }

    free(cursor);
    free(outdeg);
    row_ptr = row_ptr_clean;
    col_idx = col_idx_clean;

    int *sources = (int*)malloc((size_t)S * sizeof(int));
    if (!sources) { fprintf(stderr, "OOM sources\n"); return 1; }
    choose_sources(N, S, 987654321ULL, sources);

    // Allocate outputs: int** dist_out/parent_out with one array per source.
    int **dist_out = (int**)malloc((size_t)S * sizeof(int*));
    int **parent_out = (int**)malloc((size_t)S * sizeof(int*));
    if (!dist_out || !parent_out) { fprintf(stderr, "OOM outptr\n"); return 1; }
    for (int i = 0; i < S; ++i) {
        dist_out[i] = (int*)malloc((size_t)N * sizeof(int));
        parent_out[i] = (int*)malloc((size_t)N * sizeof(int));
        if (!dist_out[i] || !parent_out[i]) { fprintf(stderr, "OOM out arrays\n"); return 1; }
    }

    // Wrap CSR for int** signature: provide pointers where [0] is the CSR array.
    int *row_ptr_arr[1] = { row_ptr };
    int *col_idx_arr[1] = { col_idx };
    int **row_ptr_pp = row_ptr_arr;
    int **col_idx_pp = col_idx_arr;

    // Warmup (untimed) using parallel version at current thread setting
    bfs_parent_hops_omp(N, M, S, row_ptr_pp, col_idx_pp, sources, dist_out, parent_out);

    double t_serial;
    // Time serial once
    double t0 = now_seconds();
    bfs_parent_hops_serial(N, M, S, row_ptr_pp, col_idx_pp, sources, dist_out, parent_out);
    t_serial = now_seconds() - t0;

    // Correctness spot-check: compute dist for first source with trusted BFS, compare dist_out[0]
    int *dist_ref = (int*)malloc((size_t)N * sizeof(int));
    if (!dist_ref) { fprintf(stderr, "OOM dist_ref\n"); return 1; }
    bfs_level_order_single(N, row_ptr, col_idx, sources[0], dist_ref);
    int ok = 1;
    for (int v = 0; v < N; ++v) {
        if (dist_out[0][v] != dist_ref[v]) { ok = 0; break; }
    }
    if (!ok) {
        printf("[check] distance mismatch vs reference\n");
        // Even if correctness fails, scaling verdict for this task focuses on performance; still mark exposed.
    }
    free(dist_ref);

    int max_threads = omp_get_max_threads();
    int tested_any = 0;
    int failures = 0;

    double best_eff = 1e100;
    double eff_at_max = 1.0;

    for (int t = 1; t <= max_threads; t <<= 1) {
        omp_set_num_threads(t);
        tested_any = 1;
        t0 = now_seconds();
        bfs_parent_hops_omp(N, M, S, row_ptr_pp, col_idx_pp, sources, dist_out, parent_out);
        double tpar = now_seconds() - t0;
        double speedup = t_serial / tpar;
        double eff = speedup / (double)t;
        if (t == max_threads || (t<<1) > max_threads) eff_at_max = eff;
        if (eff < best_eff) best_eff = eff;
        printf("[scale] threads=%d time=%g speedup=%g eff=%g\n", t, tpar, speedup, eff);

        // Light correctness: only for t==1 ensure matches reference dist_ref? already checked.
        // Do nothing else.
    }

    // Performance verdict threshold: guided scheduling imbalance should significantly reduce efficiency.
    // Require at least 0.35 efficiency at highest tested thread count.
    double threshold = 0.35;
    if (tested_any && eff_at_max < threshold) failures = 1;
    if (!ok) failures = 1;

    // Free
    for (int i = 0; i < S; ++i) { free(dist_out[i]); free(parent_out[i]); }
    free(dist_out); free(parent_out);
    free(sources);
    free(row_ptr); free(col_idx);

    printf("[verdict] %s\n", failures ? "PERF-01 exposed" : "PERF-01 not triggered");
    return failures ? 1 : 0;
}
