#include <stdint.h>
#include <stdlib.h>
#include <string.h>

static uint64_t splitmix64_next(uint64_t *state) {
    uint64_t z = (*state += 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}

static double splitmix64_u01(uint64_t *state) {
    /* Return U in [0,1). Use top 53 bits. */
    uint64_t x = splitmix64_next(state);
    const uint64_t top53 = x >> (64 - 53);
    return (double)top53 * (1.0 / 9007199254740992.0);
}

static uint32_t next_u32(uint64_t *state) {
    return (uint32_t)splitmix64_next(state);
}

static void bfs_single_source(
    int N,
    const int *row_ptr,
    const int *col_idx,
    int s,
    int *dist_out,
    int *parent_out)
{
    int *queue = (int *)malloc((size_t)N * sizeof(int));
    if (!queue) {
        /* Allocation failure is not expected in the intended harness; avoid undefined behavior. */
        return;
    }

    for (int i = 0; i < N; i++) {
        dist_out[i] = -1;
        parent_out[i] = -1;
    }

    int head = 0, tail = 0;
    dist_out[s] = 0;
    parent_out[s] = -1;
    queue[tail++] = s;

    while (head < tail) {
        int v = queue[head++];
        int dv = dist_out[v];
        for (int ei = row_ptr[v]; ei < row_ptr[v + 1]; ei++) {
            int u = col_idx[ei];
            if (dist_out[u] == -1) {
                dist_out[u] = dv + 1;
                parent_out[u] = v;
                queue[tail++] = u;
            }
        }
    }

    free(queue);
}

/*
  Computes BFS (hop distances) and parent (predecessor) on the deterministic
  generated directed power-law multigraph in CSR form.
*/
int bfs_parent_hops_serial(
    int N,
    int M,
    int S,
    int **row_ptr_out,
    int **col_idx_out,
    int *sources_out,
    int **dist_out,
    int **parent_out)
{
    if (N <= 0 || M < 0 || S <= 0) {
        return -1;
    }

    const uint64_t seed_graph = 123456789ULL;
    const double alpha = 2.5;
    const double kmin = 1.0;
    const double kmax = (double)N - 1.0;
    const double kmin_pow = pow(kmin, 1.0 - alpha);
    const double kmax_pow = pow(kmax, 1.0 - alpha);

    /* Generate edges and build CSR */
    int *row_ptr = (int *)calloc((size_t)N + 1, sizeof(int));
    int *col_idx = (int *)malloc((size_t)M * sizeof(int));
    int *offsets = (int *)malloc((size_t)N * sizeof(int));
    if (!row_ptr || !col_idx || !offsets) {
        free(row_ptr);
        free(col_idx);
        free(offsets);
        return -2;
    }

    uint64_t rng = seed_graph;

    /* First pass: count out-degrees */
    for (int e = 0; e < M; e++) {
        double r = splitmix64_u01(&rng);
        double inner = kmin_pow - r * (kmin_pow - kmax_pow);
        double k = pow(inner, 1.0 / (1.0 - alpha));
        uint32_t u = (uint32_t)((uint64_t)k % (uint64_t)N);

        uint32_t nextu = next_u32(&rng);
        double pv = 0.15;
        double ru = splitmix64_u01(&rng);
        uint32_t v;
        if (ru < pv) {
            v = (uint32_t)((u + 1u + (nextu % (uint32_t)(N - 1))) % (uint32_t)N);
        } else {
            v = (uint32_t)(nextu % (uint32_t)N);
        }

        row_ptr[u + 1]++;
        (void)v; /* silence unused warning in this pass */
    }

    for (int i = 0; i < N; i++) {
        row_ptr[i + 1] += row_ptr[i];
    }
    memcpy(offsets, row_ptr, (size_t)N * sizeof(int));

    /* Second pass: fill edges */
    rng = seed_graph;
    for (int e = 0; e < M; e++) {
        double r = splitmix64_u01(&rng);
        double inner = kmin_pow - r * (kmin_pow - kmax_pow);
        double k = pow(inner, 1.0 / (1.0 - alpha));
        uint32_t u = (uint32_t)((uint64_t)k % (uint64_t)N);

        uint32_t nextu = next_u32(&rng);
        double pv = 0.15;
        double ru = splitmix64_u01(&rng);
        uint32_t v;
        if (ru < pv) {
            v = (uint32_t)((u + 1u + (nextu % (uint32_t)(N - 1))) % (uint32_t)N);
        } else {
            v = (uint32_t)(nextu % (uint32_t)N);
        }

        int pos = offsets[u]++;
        col_idx[pos] = (int)v;
    }

    /* Generate distinct sources */
    uint64_t rng2 = 987654321ULL;
    int *sources = (int *)malloc((size_t)S * sizeof(int));
    unsigned char *used = (unsigned char *)calloc((size_t)N, sizeof(unsigned char));
    if (!sources || !used) {
        free(row_ptr);
        free(col_idx);
        free(offsets);
        free(sources);
        free(used);
        return -3;
    }

    int chosen = 0;
    while (chosen < S) {
        uint32_t s = next_u32(&rng2) % (uint32_t)N;
        if (!used[s]) {
            used[s] = 1;
            sources[chosen++] = (int)s;
        }
    }

    /* Run BFS for each source */
    int **dist_arr = (int **)malloc((size_t)S * sizeof(int *));
    int **parent_arr = (int **)malloc((size_t)S * sizeof(int *));
    if (!dist_arr || !parent_arr) {
        free(row_ptr);
        free(col_idx);
        free(offsets);
        free(sources);
        free(used);
        free(dist_arr);
        free(parent_arr);
        return -4;
    }

    for (int i = 0; i < S; i++) {
        dist_arr[i] = (int *)malloc((size_t)N * sizeof(int));
        parent_arr[i] = (int *)malloc((size_t)N * sizeof(int));
        if (!dist_arr[i] || !parent_arr[i]) {
            for (int j = 0; j <= i; j++) {
                free(dist_arr[j]);
                free(parent_arr[j]);
            }
            free(dist_arr);
            free(parent_arr);
            free(row_ptr);
            free(col_idx);
            free(offsets);
            free(sources);
            free(used);
            return -5;
        }
        bfs_single_source(N, row_ptr, col_idx, sources[i], dist_arr[i], parent_arr[i]);
    }

    free(offsets);
    free(used);

    *row_ptr_out = row_ptr;
    *col_idx_out = col_idx;
    if (sources_out) {
        memcpy(sources_out, sources, (size_t)S * sizeof(int));
    }
    free(sources);

    *dist_out = dist_arr;
    *parent_out = parent_arr;

    return 0;
}
