/* harness.c — scaling driver for kmeans_lloyd (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <time.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

typedef struct { double x; double y; } Point2D;

// Forward declarations (match real signatures)
void kmeans_lloyd_serial(size_t N, Point2D *points_storage, Point2D centroids_out[64], int *assign_out);
void kmeans_lloyd_omp(size_t N, Point2D *points_storage, Point2D centroids_out[64], int *assign_out);

static double urand01(uint64_t *state) {
    *state = (*state) * 6364136223846793005ULL + 1442695040888963407ULL; // mod 2^64
    // u in [0,1): use top 53 bits
    uint64_t x = (*state) >> 11;
    const double inv = 1.0 / 9007199254740992.0; // 2^53
    return (double)x * inv;
}

static double gauss01_box_muller(uint64_t *state) {
    // One Gaussian using Box-Muller with two uniforms
    double u1 = urand01(state);
    double u2 = urand01(state);
    // Avoid log(0)
    if (u1 < 1e-300) u1 = 1e-300;
    double r = sqrt(-2.0 * log(u1));
    double theta = 2.0 * M_PI * u2;
    return r * cos(theta);
}

static double wall_seconds(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + 1e-9 * (double)ts.tv_nsec;
}

int main(int argc, char **argv) {
    size_t N = 2097152; // largest in spec
    int reps = 1;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--n") && i + 1 < argc) {
            N = (size_t)strtoull(argv[++i], NULL, 10);
        } else if (!strcmp(argv[i], "--reps") && i + 1 < argc) {
            reps = atoi(argv[++i]);
            if (reps < 1) reps = 1;
        } else {
            fprintf(stderr, "Unknown/invalid arg: %s\n", argv[i]);
            return 2;
        }
    }

    // Allocate
    Point2D *points = (Point2D *)malloc(sizeof(Point2D) * N);
    Point2D centroids_serial[64];
    Point2D centroids_parallel[64];
    int *assign_serial = (int *)malloc(sizeof(int) * N);
    int *assign_parallel = (int *)malloc(sizeof(int) * N);
    if (!points || !assign_serial || !assign_parallel) {
        fprintf(stderr, "Allocation failed\n");
        return 3;
    }

    // Generate deterministic points per spec
    // 8 fixed 2D cluster centers radius 50
    double cx[8], cy[8];
    for (int j = 0; j < 8; j++) {
        double ang = 2.0 * M_PI * (double)j / 8.0;
        cx[j] = 50.0 * cos(ang);
        cy[j] = 50.0 * sin(ang);
    }

    uint64_t state = 1337ULL;
    for (size_t i = 0; i < N; i++) {
        double u = urand01(&state);
        // Fixed 8-cluster mixture: choose uniform over 8 to stay deterministic.
        int c = (int)(u * 8.0);
        if (c < 0) c = 0;
        if (c > 7) c = 7;

        double g1 = gauss01_box_muller(&state);
        double g2 = gauss01_box_muller(&state);
        points[i].x = cx[c] + 10.0 * g1;
        points[i].y = cy[c] + 10.0 * g2;
    }

    // Warmup: touch input and run one untimed pass through both kernels.
    // Touch input to reduce first-touch artifacts.
    double checksum = 0.0;
    for (size_t i = 0; i < N; i += (N / 256 + 1)) checksum += points[i].x + points[i].y;
    (void)checksum;

    kmeans_lloyd_serial(N, points, centroids_serial, assign_serial);
    // Reset outputs before parallel warmup
    kmeans_lloyd_omp(N, points, centroids_parallel, assign_parallel);

    // One light correctness check: parallel at current thread count vs serial baseline.
    // Compare assignment bitwise and centroid means within 1e-12.
    // (We will still do scaling measurements below.)
    int ok = 1;
    // centroids_parallel already computed in warmup.
    for (size_t i = 0; i < N; i++) {
        if (assign_parallel[i] != assign_serial[i]) { ok = 0; break; }
    }
    if (ok) {
        for (int k = 0; k < 64; k++) {
            double dx = fabs(centroids_parallel[k].x - centroids_serial[k].x);
            double dy = fabs(centroids_parallel[k].y - centroids_serial[k].y);
            if (dx > 1e-12 || dy > 1e-12) { ok = 0; break; }
        }
    }
    if (!ok) {
        printf("[check] parallel appears incorrect; aborting scaling verdict\n");
        printf("[verdict] PERF-01 exposed\n");
        free(points);
        free(assign_serial);
        free(assign_parallel);
        return 1;
    }

    // Timing
    int max_threads = omp_get_max_threads();
    if (max_threads < 1) max_threads = 1;

    // Time serial once (at thread count 1)
    omp_set_num_threads(1);
    double t_serial = 0.0;
    for (int r = 0; r < reps; r++) {
        double t0 = wall_seconds();
        kmeans_lloyd_serial(N, points, centroids_serial, assign_serial);
        double t1 = wall_seconds();
        t_serial += (t1 - t0);
    }
    t_serial /= (double)reps;

    int prev = 0;
    double best_eff = -1.0;
    int best_t = 1;

    // Scale over powers of two up to max_threads
    for (int t = 1; t <= max_threads; t = (t == 1 ? 2 : t * 2)) {
        if (t > max_threads) t = max_threads;
        if (t == prev) break;
        prev = t;

        omp_set_num_threads(t);
        double t_par = 0.0;
        for (int r = 0; r < reps; r++) {
            double t0 = wall_seconds();
            kmeans_lloyd_omp(N, points, centroids_parallel, assign_parallel);
            double t1 = wall_seconds();
            t_par += (t1 - t0);
        }
        t_par /= (double)reps;

        double speedup = t_serial / (t_par > 0 ? t_par : 1e-18);
        double eff = speedup / (double)t;
        printf("[scale] threads=%d time=%.6f speedup=%.3f efficiency=%.3f\n", t, t_par, speedup, eff);

        best_eff = eff;
        best_t = t;
        if (t == max_threads) break;
    }

    // Verdict: excessive synchronization should reduce efficiency at high thread count.
    // Threshold chosen to be strict enough to catch large coordination overhead.
    // In practice, broken-with-critical-section patterns often fall well below ~0.15.
    const double eff_threshold = 0.15;
    int failure = (best_eff < eff_threshold);

    if (failure) {
        printf("[verdict] PERF-01 exposed\n");
    } else {
        printf("[verdict] PERF-01 not triggered\n");
    }

    free(points);
    free(assign_serial);
    free(assign_parallel);
    (void)best_t;
    return failure ? 1 : 0;
}
