#include <stddef.h>
#include <stdint.h>
#include <math.h>
#include <omp.h>

typedef struct {
    double x;
    double y;
} Point2D;

static inline uint64_t lcg_next(uint64_t *state) {
    *state = (*state) * 6364136223846793005ULL + 1442695040888963407ULL;
    return *state;
}

static inline double lcg_uniform01(uint64_t *state) {
    uint64_t s = lcg_next(state);
    return (double)(s >> 11) * (1.0 / 9007199254740992.0); /* 2^53 */
}

static inline void box_muller_gaussian2(uint64_t *state, double *out1, double *out2) {
    double u1 = lcg_uniform01(state);
    double u2 = lcg_uniform01(state);
    if (u1 <= 0.0) {
        u1 = 1.0 / 9007199254740992.0;
    }
    double r = sqrt(-2.0 * log(u1));
    double ang = 2.0 * 3.14159265358979323846 * 2.0 * u2;
    *out1 = r * cos(ang);
    *out2 = r * sin(ang);
}

static inline int nearest_centroid_2d(const Point2D *centroids, int K, double px, double py) {
    int best = 0;
    double bestd = (centroids[0].x - px) * (centroids[0].x - px) + (centroids[0].y - py) * (centroids[0].y - py);
    for (int j = 1; j < K; j++) {
        double dx = centroids[j].x - px;
        double dy = centroids[j].y - py;
        double d = dx * dx + dy * dy;
        if (d < bestd) {
            bestd = d;
            best = j;
        }
    }
    return best;
}

void kmeans_lloyd_omp(
    size_t N,
    Point2D *points_storage,
    Point2D centroids_out[64],
    int *assign_out)
{
    const int K = 64;
    const int Cmix = 8;

    double center_x[Cmix];
    double center_y[Cmix];
    for (int j = 0; j < Cmix; j++) {
        double ang = 2.0 * 3.14159265358979323846 * (double)j / (double)Cmix;
        center_x[j] = 50.0 * cos(ang);
        center_y[j] = 50.0 * sin(ang);
    }

    uint64_t state = 1337ULL;

    for (size_t i = 0; i < N; i++) {
        double u = lcg_uniform01(&state);
        int c = (int)(u * (double)Cmix);
        if (c < 0) c = 0;
        if (c >= Cmix) c = Cmix - 1;

        double g1, g2;
        box_muller_gaussian2(&state, &g1, &g2);

        points_storage[i].x = center_x[c] + 10.0 * g1;
        points_storage[i].y = center_y[c] + 10.0 * g2;

        if (i < (size_t)K) {
            centroids_out[i].x = points_storage[i].x;
            centroids_out[i].y = points_storage[i].y;
        }
    }

    if (N < (size_t)K) {
        for (int j = (int)N; j < K; j++) {
            size_t idx = (size_t)j % N;
            centroids_out[j].x = points_storage[idx].x;
            centroids_out[j].y = points_storage[idx].y;
        }
    }

    int *prev = assign_out;
    int *curr = assign_out;

    int changed;
    do {
        changed = 0;

        #pragma omp parallel for schedule(static) reduction(|:changed)
        for (size_t i = 0; i < N; i++) {
            int a = nearest_centroid_2d(centroids_out, K, points_storage[i].x, points_storage[i].y);
            if (a != prev[i]) {
                changed = 1;
            }
            curr[i] = a;
        }

        double sumx[K];
        double sumy[K];
        long long cnt[K];
        for (int j = 0; j < K; j++) {
            sumx[j] = 0.0;
            sumy[j] = 0.0;
            cnt[j] = 0;
        }

        #pragma omp parallel
        {
            double t_sumx[K];
            double t_sumy[K];
            long long t_cnt[K];
            for (int j = 0; j < K; j++) {
                t_sumx[j] = 0.0;
                t_sumy[j] = 0.0;
                t_cnt[j] = 0;
            }

            #pragma omp for schedule(static)
            for (size_t i = 0; i < N; i++) {
                int a = curr[i];
                t_sumx[a] += points_storage[i].x;
                t_sumy[a] += points_storage[i].y;
                t_cnt[a] += 1;
            }

            for (int j = 0; j < K; j++) {
                #pragma omp critical
                {
                    sumx[j] += t_sumx[j];
                    sumy[j] += t_sumy[j];
                    cnt[j] += t_cnt[j];
                }
            }
        }

        for (int j = 0; j < K; j++) {
            if (cnt[j] > 0) {
                centroids_out[j].x = sumx[j] / (double)cnt[j];
                centroids_out[j].y = sumy[j] / (double)cnt[j];
            }
        }

    } while (changed);
}
