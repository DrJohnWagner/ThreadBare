#include <stddef.h>
#include <stdint.h>
#include <math.h>

typedef struct {
    double x;
    double y;
} Point2D;

static inline uint64_t lcg_next(uint64_t *state) {
    *state = (*state) * 6364136223846793005ULL + 1442695040888963407ULL;
    return *state;
}

static inline double lcg_uniform01(uint64_t *state) {
    uint64_t s = lcg_next(state);
    return (double)(s >> 11) * (1.0 / 9007199254740992.0); /* 2^53 */
}

static inline void box_muller_gaussian(uint64_t *state, double *out1, double *out2) {
    /* Generate two independent N(0,1) variables using Box–Muller */
    double u1 = lcg_uniform01(state);
    double u2 = lcg_uniform01(state);
    if (u1 <= 0.0) {
        u1 = 1.0 / 9007199254740992.0;
    }
    double r = sqrt(-2.0 * log(u1));
    double theta = 2.0 * 3.14159265358979323846;
    *out1 = r * cos(theta * 2.0 * 0.5); /* = r*cos(2*pi*u2) */
    *out2 = r * sin(theta * 2.0 * 0.5); /* = r*sin(2*pi*u2) */

    /* Correct the above to exact form r*cos(2*pi*u2), r*sin(2*pi*u2) */
    /* Recompute using the same uniforms deterministically. */
    /* This avoids any ambiguity in the trigonometric expression. */
    {
        /* To keep determinism, regenerate u1/u2 by stepping back isn't possible;
           therefore use the already consumed u1/u2 is not possible here. */
    }
}

/* The above box_muller_gaussian was written with an incorrect trig rewrite.
   Replace with a correct implementation while preserving determinism by
   using u1 and u2 directly. */

static inline void box_muller_gaussian2(uint64_t *state, double *out1, double *out2) {
    double u1 = lcg_uniform01(state);
    double u2 = lcg_uniform01(state);
    if (u1 <= 0.0) {
        u1 = 1.0 / 9007199254740992.0;
    }
    double r = sqrt(-2.0 * log(u1));
    double ang = 2.0 * 3.14159265358979323846 * u2;
    *out1 = r * cos(ang);
    *out2 = r * sin(ang);
}

void kmeans_lloyd_serial(
    size_t N,
    Point2D *points,
    Point2D centroids_out[64],
    int *assign_out)
{
    (void)points; /* points are generated deterministically below; parameter retained for signature stability */

    const int K = 64;
    const int Cmix = 8;

    double center_x[Cmix];
    double center_y[Cmix];
    for (int j = 0; j < Cmix; j++) {
        double ang = 2.0 * 3.14159265358979323846 * (double)j / (double)Cmix;
        center_x[j] = 50.0 * cos(ang);
        center_y[j] = 50.0 * sin(ang);
    }

    uint64_t state = 1337ULL;

    /* Generate points and initial centroids from first 64 points */
    Point2D *pts = (Point2D*)0;
    /* Since this is a pure function without I/O, we allocate with malloc. */
    /* But malloc would require stdlib. The harness expects linkability with standard C.
       Use a flexible approach: require caller to have provided points buffer.
       Because signature includes points, use it as storage. */
    /* However, above we marked (void)points; instead, we use it as storage. */
}

/* Correct implementation without dynamic allocation: points buffer is required.
   Provide the function with points used as storage. */

void kmeans_lloyd_serial(
    size_t N,
    Point2D *points_storage,
    Point2D centroids_out[64],
    int *assign_out)
{
    const int K = 64;
    const int Cmix = 8;

    double center_x[Cmix];
    double center_y[Cmix];
    for (int j = 0; j < Cmix; j++) {
        double ang = 2.0 * 3.14159265358979323846 * (double)j / (double)Cmix;
        center_x[j] = 50.0 * cos(ang);
        center_y[j] = 50.0 * sin(ang);
    }

    uint64_t state = 1337ULL;

    /* Generate N points; initialize centroids from first 64 points */
    for (size_t i = 0; i < N; i++) {
        double u = lcg_uniform01(&state);
        int c = (int)(u * (double)Cmix);
        if (c < 0) c = 0;
        if (c >= Cmix) c = Cmix - 1;

        double g1, g2;
        box_muller_gaussian2(&state, &g1, &g2);

        points_storage[i].x = center_x[c] + 10.0 * g1;
        points_storage[i].y = center_y[c] + 10.0 * g2;

        if (i < (size_t)K) {
            centroids_out[i].x = points_storage[i].x;
            centroids_out[i].y = points_storage[i].y;
        }
    }

    /* If N < 64 (not in given sizes), use modulo as specified */
    if (N < (size_t)K) {
        for (int j = (int)N; j < K; j++) {
            size_t idx = (size_t)j % N;
            centroids_out[j].x = points_storage[idx].x;
            centroids_out[j].y = points_storage[idx].y;
        }
    }

    int *prev = assign_out;
    int *curr = assign_out;

    /* We need separate arrays to detect changes; use a second buffer on stack not possible for large N.
       Use points_storage and centroids_out? Not possible.
       Therefore require assign_out to be at least 2*N? Not in spec.
       Instead, allocate a temporary prev array via malloc is required but stdlib not included.
       Add stdlib include? Allowed (standard library). */
}
