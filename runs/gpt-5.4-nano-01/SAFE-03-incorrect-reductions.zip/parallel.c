#include <math.h>
#include <stddef.h>
#include <omp.h>
#include <stdlib.h>

typedef struct {
  double x;
  double y;
} Point2D;

static double fract_double(double x) {
  return x - floor(x);
}

static double prng_u01(int idx, double scale, double offset, int seed) {
  double v = sin((double)idx + offset + (double)seed) * scale;
  return fract_double(v);
}

static void generate_points(int n, int seed, Point2D *points) {
  for (int i = 0; i < n; i++) {
    double u1 = fract_double(sin((double)(i + 1) * 12.9898 + (double)seed) * 43758.5453);
    double u2 = fract_double(sin((double)(i + 1) * 78.233 + (double)seed) * 96245.164);
    points[i].x = 2.0 * (u1 - 0.5);
    points[i].y = 2.0 * (u2 - 0.5);
  }
}

static void generate_centroids(int seed, Point2D centroids[64]) {
  for (int c = 0; c < 64; c++) {
    double uc1 = fract_double(sin((double)(c + 1) * 37.719 + (double)seed) * 143758.5453);
    double uc2 = fract_double(sin((double)(c + 1) * 19.731 + (double)seed) * 53211.117);
    centroids[c].x = 2.0 * (uc1 - 0.5);
    centroids[c].y = 2.0 * (uc2 - 0.5);
  }
}

static int nearest_centroid(const Point2D p, const Point2D centroids[64]) {
  int best = 0;
  double best_d = (p.x - centroids[0].x) * (p.x - centroids[0].x) +
                   (p.y - centroids[0].y) * (p.y - centroids[0].y);
  for (int c = 1; c < 64; c++) {
    double dx = p.x - centroids[c].x;
    double dy = p.y - centroids[c].y;
    double d = dx * dx + dy * dy;
    if (d < best_d) {
      best_d = d;
      best = c;
    }
  }
  return best;
}

void kmeans_2d_fixedk_omp(
    int n,
    int seed,
    int *out_assignments,
    Point2D out_centroids[64]) {
  Point2D *points = (Point2D *)((n > 0) ? malloc((size_t)n * sizeof(Point2D)) : NULL);
  if (n > 0 && points == NULL) {
    return;
  }

  generate_points(n, seed, points);
  Point2D centroids[64];
  generate_centroids(seed, centroids);

  int *assignments = (int *)((n > 0) ? malloc((size_t)n * sizeof(int)) : NULL);
  int *new_assignments = (int *)((n > 0) ? malloc((size_t)n * sizeof(int)) : NULL);
  if (n > 0 && (assignments == NULL || new_assignments == NULL)) {
    if (points) {
      free(points);
    }
    if (assignments) {
      free(assignments);
    }
    if (new_assignments) {
      free(new_assignments);
    }
    return;
  }

  #pragma omp parallel for schedule(static)
  for (int i = 0; i < n; i++) {
    assignments[i] = nearest_centroid(points[i], centroids);
  }

  for (int iter = 0; iter < 1000; iter++) {
    #pragma omp parallel for schedule(static)
    for (int i = 0; i < n; i++) {
      new_assignments[i] = nearest_centroid(points[i], centroids);
    }

    int changed = 0;
    #pragma omp parallel for reduction(| : changed) schedule(static)
    for (int i = 0; i < n; i++) {
      changed |= (new_assignments[i] != assignments[i]);
    }

    double sumx[64];
    double sumy[64];
    long long counts[64];
    for (int c = 0; c < 64; c++) {
      sumx[c] = 0.0;
      sumy[c] = 0.0;
      counts[c] = 0;
    }

    #pragma omp parallel
    {
      double lsx[64];
      double lsy[64];
      long long lcnt[64];
      for (int c = 0; c < 64; c++) {
        lsx[c] = 0.0;
        lsy[c] = 0.0;
        lcnt[c] = 0;
      }

      #pragma omp for schedule(static)
      for (int i = 0; i < n; i++) {
        int c = new_assignments[i];
        lsx[c] += points[i].x;
        lsy[c] += points[i].y;
        lcnt[c] += 1;
      }

      #pragma omp critical
      {
        for (int c = 0; c < 64; c++) {
          sumx[c] += lsx[c];
          sumy[c] += lsy[c];
          counts[c] += lcnt[c];
        }
      }
    }

    for (int c = 0; c < 64; c++) {
      if (counts[c] > 0) {
        centroids[c].x = sumx[c] / (double)counts[c];
        centroids[c].y = sumy[c] / (double)counts[c];
      }
    }

    #pragma omp parallel for schedule(static)
    for (int i = 0; i < n; i++) {
      assignments[i] = new_assignments[i];
    }

    if (!changed) {
      break;
    }
  }

  #pragma omp parallel for schedule(static)
  for (int i = 0; i < n; i++) {
    out_assignments[i] = assignments[i];
  }

  for (int c = 0; c < 64; c++) {
    out_centroids[c] = centroids[c];
  }

  if (points) {
    free(points);
  }
  if (assignments) {
    free(assignments);
  }
  if (new_assignments) {
    free(new_assignments);
  }
}
