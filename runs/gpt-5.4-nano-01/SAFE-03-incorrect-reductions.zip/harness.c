/* harness.c — differential driver for kmeans_2d_fixedk (generated)
    *
    *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
    *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
    */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#ifndef KMEANS_K
#define KMEANS_K 64
#endif

typedef struct { double x; double y; } Point2D;

/* Forward declarations: must match real signatures exactly */
void kmeans_2d_fixedk_serial(int n, int seed, int *out_assignments, Point2D out_centroids[KMEANS_K]);
void kmeans_2d_fixedk_omp(int n, int seed, int *out_assignments, Point2D out_centroids[KMEANS_K]);

static double fractd(double v) {
    return v - floor(v);
}

static void gen_points(int n, int seed, double *px, double *py) {
    for (int i = 0; i < n; i++) {
        double u1 = fractd(sin((double)(i + 1) * 12.9898 + (double)seed) * 43758.5453);
        double u2 = fractd(sin((double)(i + 1) * 78.233 + (double)seed) * 96245.164);
        px[i] = 2.0 * (u1 - 0.5);
        py[i] = 2.0 * (u2 - 0.5);
    }
}

static void gen_centroids_init(int seed, Point2D out_centroids[KMEANS_K]) {
    for (int c = 0; c < KMEANS_K; c++) {
        double uc1 = fractd(sin((double)(c + 1) * 37.719 + (double)seed) * 143758.5453);
        double uc2 = fractd(sin((double)(c + 1) * 19.731 + (double)seed) * 53211.117);
        out_centroids[c].x = 2.0 * (uc1 - 0.5);
        out_centroids[c].y = 2.0 * (uc2 - 0.5);
    }
}

static void usage(const char *prog) {
    fprintf(stderr,
            "Usage: %s [--n N] [--reps R] [--seed S]\n"
            "  --n N     number of points (default: 1600000)\n"
            "  --reps R  repetitions (default: 20)\n"
            "  --seed S  dataset seed (default: 1337)\n",
            prog);
}

int main(int argc, char **argv) {
    int n = 1600000;
    int reps = 20;
    int seed = 1337;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            n = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--reps") == 0 && i + 1 < argc) {
            reps = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--seed") == 0 && i + 1 < argc) {
            seed = atoi(argv[++i]);
        } else {
            usage(argv[0]);
            return 2;
        }
    }

    int *a_serial = (int *)malloc((size_t)n * sizeof(int));
    int *a_par = (int *)malloc((size_t)n * sizeof(int));
    Point2D c_serial[KMEANS_K];
    Point2D c_par[KMEANS_K];
    if (!a_serial || !a_par) {
        fprintf(stderr, "allocation failed\n");
        return 2;
    }

    /* Ground truth */
    kmeans_2d_fixedk_serial(n, seed, a_serial, c_serial);

    /* Differential check across repetitions */
    int failures = 0;
    const double tol = 1e-9;

    for (int r = 0; r < reps && !failures; r++) {
        kmeans_2d_fixedk_omp(n, seed, a_par, c_par);

        /* Compare assignments first (exact) */
        for (int i = 0; i < n; i++) {
            if (a_par[i] != a_serial[i]) {
                printf("[check] assignment divergence at i=%d rep=%d serial=%d parallel=%d\n",
                       i, r, a_serial[i], a_par[i]);
                failures = 1;
                break;
            }
        }
        if (failures) break;

        /* Compare centroids within tolerance */
        for (int c = 0; c < KMEANS_K; c++) {
            double dx = c_par[c].x - c_serial[c].x;
            double dy = c_par[c].y - c_serial[c].y;
            if (fabs(dx) > tol || fabs(dy) > tol) {
                printf("[check] centroid divergence at c=%d rep=%d dx=%0.17g dy=%0.17g\n",
                       c, r, dx, dy);
                failures = 1;
                break;
            }
        }
    }

    free(a_serial);
    free(a_par);

    printf("[verdict] %s\n", failures ? "SAFE-01 exposed" : "SAFE-01 not triggered");
    return failures ? 1 : 0;
}
