#include <stdint.h>
#include <string.h>
#ifdef _OPENMP
#include <omp.h>
#endif

static uint64_t splitmix64(uint64_t x) {
    x += 0x9E3779B97F4A7C15ULL;
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ULL;
    x = (x ^ (x >> 27)) * 0x94D049BB133111EBULL;
    return x ^ (x >> 31);
}

static float decode_value(uint32_t sensor_id, int16_t raw_value) {
    float f = (float)raw_value;
    return f * 0.01f + ((float)sensor_id) * 0.001f;
}

static void compress_decompress_record(uint64_t key, uint16_t timestamp_low, uint32_t sensor_id, uint32_t r, int16_t raw_value,
                                        uint32_t *out_sensor_id, uint32_t *out_timestamp_us, int16_t *out_raw_value) {
    (void)r;

    uint8_t packed[8];

    uint32_t timestamp_us = (uint32_t)timestamp_low;
    uint16_t raw_u = (uint16_t)raw_value;

    uint8_t t0 = (uint8_t)(timestamp_us & 0xFFu);
    uint8_t t1 = (uint8_t)((timestamp_us >> 8) & 0xFFu);
    uint8_t t2 = (uint8_t)((timestamp_us >> 16) & 0xFFu);
    uint8_t t3 = (uint8_t)((timestamp_us >> 24) & 0xFFu);
    uint8_t rv0 = (uint8_t)(raw_u & 0xFFu);
    uint8_t rv1 = (uint8_t)((raw_u >> 8) & 0xFFu);
    uint8_t sid = (uint8_t)(sensor_id & 0x0Fu);

    packed[0] = t0;
    packed[1] = t1;
    packed[2] = t2;
    packed[3] = t3;
    packed[4] = rv0;
    packed[5] = rv1;
    packed[6] = sid;
    packed[7] = (uint8_t)(sid ^ (uint8_t)(raw_u & 0xFFu));

    for (int i = 0; i < 8; i++) {
        uint8_t k = (uint8_t)((key >> (uint32_t)(i * 8)) & 0xFFULL);
        packed[i] ^= k;
    }

    for (int i = 0; i < 8; i++) {
        uint8_t k = (uint8_t)((key >> (uint32_t)(i * 8)) & 0xFFULL);
        packed[i] ^= k;
    }

    uint32_t ts = ((uint32_t)packed[0]) | ((uint32_t)packed[1] << 8) | ((uint32_t)packed[2] << 16) | ((uint32_t)packed[3] << 24);
    uint16_t raw_out_u = ((uint16_t)packed[4]) | ((uint16_t)packed[5] << 8);

    uint32_t sid_out = (uint32_t)(packed[6] & 0x0Fu);
    int16_t raw_out = (int16_t)raw_out_u;

    *out_sensor_id = sid_out;
    *out_timestamp_us = ts;
    *out_raw_value = raw_out;
}

typedef struct {
    uint32_t count;
    float sum;
    float sumsq;
} row_t;

static uint32_t hash32_u32(uint32_t x) {
    x ^= x >> 16;
    x *= 0x7feb352du;
    x ^= x >> 15;
    x *= 0x846ca68bu;
    x ^= x >> 16;
    return x;
}

static uint32_t hash32_file_sensor(uint32_t file_id, uint32_t sensor_id) {
    return hash32_u32(file_id * 1315423911u + sensor_id * 2654435761u);
}

static uint32_t float_bits_u32(float f) {
    uint32_t u;
    memcpy(&u, &f, sizeof(u));
    return u;
}

void sensor_log_pipeline_summary_omp(uint32_t num_files,
                                     uint32_t records_per_file,
                                     uint32_t sensors_per_file,
                                     row_t *out_table,
                                     uint32_t *out_total_rows,
                                     uint32_t *out_checksum) {
    if (!out_table || !out_total_rows || !out_checksum) return;

    uint32_t total_rows = num_files * sensors_per_file;
    *out_total_rows = total_rows;

    #pragma omp parallel for schedule(static)
    for (uint32_t f = 0; f < num_files; f++) {
        for (uint32_t s = 0; s < sensors_per_file; s++) {
            uint32_t idx = f * sensors_per_file + s;
            out_table[idx].count = 0u;
            out_table[idx].sum = 0.0f;
            out_table[idx].sumsq = 0.0f;
        }
    }

    #pragma omp parallel for schedule(static)
    for (uint32_t f = 0; f < num_files; f++) {
        uint64_t key = splitmix64(0xC0FFEE123456789ULL ^ (uint64_t)f * 0x9E3779B97F4A7C15ULL);

        for (uint32_t r = 0; r < records_per_file; r++) {
            uint64_t x = splitmix64(0xC0FFEE123456789ULL ^ ((uint64_t)f * 1000003ULL + (uint64_t)r * 9176ULL));
            uint32_t sensor_id = (uint32_t)(x % 16ULL);
            uint32_t timestamp_us = (uint32_t)((x >> 16) % 1000000000ULL);
            int16_t raw_value = (int16_t)((int)(x % 20001ULL) - 10000);

            uint32_t dec_sensor_id;
            uint32_t dec_timestamp_us;
            int16_t dec_raw_value;
            compress_decompress_record(key, (uint16_t)(timestamp_us & 0xFFFFu), sensor_id, r, raw_value,
                                        &dec_sensor_id, &dec_timestamp_us, &dec_raw_value);

            (void)dec_timestamp_us;
            float v = decode_value(dec_sensor_id, dec_raw_value);

            uint32_t idx = f * sensors_per_file + dec_sensor_id;
            out_table[idx].count += 1u;
            out_table[idx].sum += v;
            out_table[idx].sumsq += v * v;
        }
    }

    uint32_t checksum = 0u;
    for (uint32_t f = 0; f < num_files; f++) {
        for (uint32_t s = 0; s < sensors_per_file; s++) {
            uint32_t idx = f * sensors_per_file + s;
            uint32_t hb = hash32_file_sensor(f, s);
            uint32_t sum_b = float_bits_u32(out_table[idx].sum);
            uint32_t sumsq_b = float_bits_u32(out_table[idx].sumsq);
            checksum ^= (hb ^ sum_b ^ sumsq_b);
        }
    }
    *out_checksum = checksum;
}
