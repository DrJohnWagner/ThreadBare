/* harness.c — timeout driver for sensor_log_ingest_pipeline (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -lm -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <signal.h>
#include <unistd.h>
#include <omp.h>

// Forward declarations (match real signatures exactly)
typedef struct sensor_summary_row sensor_summary_row;

void sensor_log_ingest_pipeline_serial(sensor_summary_row *results,
                                        uint64_t *out_total_count,
                                        uint64_t *out_checksum);

void sensor_log_ingest_pipeline_omp(sensor_summary_row *results,
                                  uint64_t *out_total_count,
                                  uint64_t *out_checksum);

static volatile sig_atomic_t timed_out = 0;

static void alarm_handler(int sig) {
    (void)sig;
    timed_out = 1;
}

static void usage(const char *prog) {
    fprintf(stderr,
            "Usage: %s [--threads N] [--timeout-seconds T] [--n NFILES] [--s NSENSORS] [--r RECORDS_PER_FILE]\n",
            prog);
}

int main(int argc, char **argv) {
    int threads = -1;
    int timeout_seconds = 5;

    // Defaults to specification maxima (but runtime is controlled via timeout)
    uint32_t NFILES = 200;
    uint32_t NSENSORS = 16;
    uint32_t RECORDS_PER_FILE = 23000;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--threads") && i + 1 < argc) {
            threads = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--timeout-seconds") && i + 1 < argc) {
            timeout_seconds = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--n") && i + 1 < argc) {
            NFILES = (uint32_t)strtoul(argv[++i], NULL, 10);
        } else if (!strcmp(argv[i], "--s") && i + 1 < argc) {
            NSENSORS = (uint32_t)strtoul(argv[++i], NULL, 10);
        } else if (!strcmp(argv[i], "--r") && i + 1 < argc) {
            RECORDS_PER_FILE = (uint32_t)strtoul(argv[++i], NULL, 10);
        } else if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) {
            usage(argv[0]);
            return 0;
        } else {
            fprintf(stderr, "Unknown/invalid argument: %s\n", argv[i]);
            usage(argv[0]);
            return 1;
        }
    }

    if (threads > 0) {
        omp_set_num_threads(threads);
    }

    // Allocate outputs. The kernel API only provides results pointer + two scalars.
    // We don't know struct layout, but we can allocate a sufficiently sized buffer.
    // Since harness links against the same serial/omp objects, struct size is known at compile time.
    // However, we don't have the definition here. Use a conservative approach: allocate bytes
    // for the entire results table assuming it contains the needed fields.
    // If the struct is smaller than this, extra bytes are fine.
    // We assume max row needs about 8*2 + 8 bytes for status + double fields: ~32-48 bytes.
    size_t nrows = (size_t)NFILES * (size_t)NSENSORS;
    size_t row_bytes = 64; // conservative
    void *results_buf = calloc(nrows, row_bytes);
    if (!results_buf) {
        fprintf(stderr, "Failed to allocate results buffer\n");
        return 1;
    }

    sensor_summary_row *results = (sensor_summary_row *)results_buf;
    uint64_t total_count = 0;
    uint64_t checksum = 0;

    // Run serial once as a sanity check (should finish well under timeout).
    total_count = 0;
    checksum = 0;
    sensor_log_ingest_pipeline_serial(results, &total_count, &checksum);

    // Clear and run parallel under a hard timeout.
    memset(results_buf, 0, nrows * row_bytes);
    total_count = 0;
    checksum = 0;
    timed_out = 0;

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = alarm_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    if (sigaction(SIGALRM, &sa, NULL) != 0) {
        fprintf(stderr, "sigaction(SIGALRM) failed\n");
        free(results_buf);
        return 1;
    }

    alarm(timeout_seconds);
    sensor_log_ingest_pipeline_omp(results, &total_count, &checksum);
    alarm(0);

    int failures = timed_out ? 1 : 0;

    if (!failures) {
        // One minimal check that the program produced something nontrivial.
        // (If it deadlocked, we would have timed out already.)
        if (total_count == 0) {
            failures = 1;
        }
    }

    printf("[verdict] %s\n", failures ? "LIVE-01 exposed" : "LIVE-01 not triggered");
    free(results_buf);
    return failures ? 1 : 0;
}
