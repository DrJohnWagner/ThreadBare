#include <stdint.h>
#include <stddef.h>
#include <math.h>
#include <string.h>

#define NFILES 200
#define RECORDS_PER_FILE 23000
#define NSENSORS 16
#define RECORD_BYTES 64

typedef struct {
    int64_t count;
    double sum_value;
    double sum_abs_value;
    int64_t sum_status;
} sensor_summary_row;

static uint64_t xorshift64star_next(uint64_t *state) {
    uint64_t x = *state;
    x ^= x >> 12;
    x ^= x << 25;
    x ^= x >> 27;
    *state = x;
    return x * 2685821657736338717ULL;
}

static uint64_t prng_uniform_bounded(uint64_t *state, uint64_t bound) {
    return xorshift64star_next(state) % bound;
}

void sensor_log_ingest_pipeline_serial(sensor_summary_row *results,
                                         uint64_t *out_total_count,
                                         uint64_t *out_checksum) {
    if (!results || !out_total_count || !out_checksum) return;

    const uint64_t base_seed = 0xC0FFEE123456789ULL;
    sensor_summary_row local_rows[NSENSORS];

    int64_t total_count = 0;
    uint64_t checksum = 0;

    for (uint32_t f = 0; f < NFILES; f++) {
        for (uint32_t s = 0; s < NSENSORS; s++) {
            local_rows[s].count = 0;
            local_rows[s].sum_value = 0.0;
            local_rows[s].sum_abs_value = 0.0;
            local_rows[s].sum_status = 0;
        }

        uint64_t state = base_seed ^ ((uint64_t)f * 0x9E3779B97F4A7C15ULL);

        uint64_t base_ts = (uint64_t)f * 1000000ULL;

        for (uint32_t i = 0; i < RECORDS_PER_FILE; i++) {
            uint32_t sensor_id = (uint32_t)prng_uniform_bounded(&state, NSENSORS);
            uint64_t timestamp = base_ts + (uint64_t)i * 10ULL + prng_uniform_bounded(&state, 100ULL);
            (void)timestamp;

            int64_t rv = (int64_t)prng_uniform_bounded(&state, 200000ULL) - 100000;
            double value = (double)rv / 1000.0;

            uint32_t status = (uint32_t)prng_uniform_bounded(&state, 4ULL);

            local_rows[sensor_id].count += 1;
            local_rows[sensor_id].sum_value += value;
            local_rows[sensor_id].sum_abs_value += fabs(value);
            local_rows[sensor_id].sum_status += (int64_t)status;
        }

        for (uint32_t s = 0; s < NSENSORS; s++) {
            size_t idx = (size_t)f * NSENSORS + (size_t)s;
            results[idx] = local_rows[s];

            total_count += local_rows[s].count;

            double scaled = 1e6 * local_rows[s].sum_value;
            long long iv = llrint(scaled);
            uint64_t part = (uint64_t)local_rows[s].count;
            uint32_t rot = (uint32_t)(s + 1);
            uint64_t rotv;
            if (rot == 0) {
                rotv = part;
            } else {
                rotv = (part << rot) | (part >> (64u - rot));
            }
            checksum = (checksum ^ (rotv + (uint64_t)iv));
        }
    }

    *out_total_count = (uint64_t)total_count;
    *out_checksum = checksum;
}
