/* harness.c — scaling driver for bfs_parent_distance (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <math.h>

// Forward declarations (match real signatures)
void bfs_parent_distance_serial(
    int V, int E,
    const int *rowPtr,
    const int *colInd,
    int source_count,
    const int *sources,
    int *dist_out,
    int *parent_out);

void bfs_parent_distance_omp(
    int V, int E,
    const int *rowPtr,
    const int *colInd,
    int source_count,
    const int *sources,
    int *dist_out,
    int *parent_out);

static uint64_t xorshift64(uint64_t *state) {
    uint64_t x = *state;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    *state = x;
    return x;
}

static int floor_pow_inv_alpha_term(int k, double alpha) {
    // Computes floor(1e6 * k^{-alpha} / 1^{-alpha}) = floor(1e6 * k^{-alpha}) since 1^{-alpha}=1
    // Use log/exp for determinism.
    double val = 1e6 * pow((double)k, -alpha);
    long long f = (long long)floor(val);
    if (f < 0) f = 0;
    if (f > 1000000LL) f = 1000000LL;
    return (int)f;
}

static void generate_graph(int V, int E, int **rowPtr_out, int **colInd_out,
                            int *sources_out, int source_count) {
    int *outdeg = (int*)calloc((size_t)V, sizeof(int));
    int *rowPtr = (int*)malloc((size_t)(V + 1) * sizeof(int));
    int *colInd = (int*)malloc((size_t)E * sizeof(int));
    if (!outdeg || !rowPtr || !colInd) {
        fprintf(stderr, "Allocation failed\n");
        exit(1);
    }

    const uint64_t seed = 1337ULL;
    const double alpha = 2.5;

    // Degree counting pass
    uint64_t state = seed;
    // Rejection sampling constants
    // For acceptance: (next_u64() mod 1e6) < floor(1e6 * k^{-alpha})

    // Power-law sampler returning k in [1..V] then u=k-1
    // To avoid recomputing floor each time, precompute accept thresholds.
    int *accThresh = (int*)malloc((size_t)(V + 1) * sizeof(int));
    if (!accThresh) {
        fprintf(stderr, "Allocation failed\n");
        exit(1);
    }
    accThresh[0] = 0;
    for (int k = 1; k <= V; k++) {
        accThresh[k] = floor_pow_inv_alpha_term(k, alpha);
    }

    for (int e = 0; e < E; e++) {
        // draw tail u
        int k_tail = 1;
        while (1) {
            uint64_t r1 = xorshift64(&state);
            k_tail = (int)(r1 % (uint64_t)V) + 1;
            uint64_t r2 = xorshift64(&state);
            int left = (int)(r2 % 1000000ULL);
            if (left < accThresh[k_tail]) break;
        }
        int u = k_tail - 1;

        // draw head v
        int k_head = 1;
        while (1) {
            uint64_t r1 = xorshift64(&state);
            k_head = (int)(r1 % (uint64_t)V) + 1;
            uint64_t r2 = xorshift64(&state);
            int left = (int)(r2 % 1000000ULL);
            if (left < accThresh[k_head]) break;
        }
        int v = k_head - 1;

        (void)u;
        (void)v;
        outdeg[u]++;
    }

    rowPtr[0] = 0;
    for (int i = 0; i < V; i++) rowPtr[i + 1] = rowPtr[i] + outdeg[i];
    // Sanity: rowPtr[V] should equal E
    if (rowPtr[V] != E) {
        // If this happens, it indicates a mismatch in generation logic; fail hard.
        fprintf(stderr, "Graph generation mismatch: rowPtr[V]=%d E=%d\n", rowPtr[V], E);
        exit(1);
    }

    int *writePos = (int*)malloc((size_t)V * sizeof(int));
    if (!writePos) {
        fprintf(stderr, "Allocation failed\n");
        exit(1);
    }
    for (int i = 0; i < V; i++) writePos[i] = rowPtr[i];

    // Second pass: fill edges
    state = seed;
    for (int e = 0; e < E; e++) {
        int k_tail = 1;
        while (1) {
            uint64_t r1 = xorshift64(&state);
            k_tail = (int)(r1 % (uint64_t)V) + 1;
            uint64_t r2 = xorshift64(&state);
            int left = (int)(r2 % 1000000ULL);
            if (left < accThresh[k_tail]) break;
        }
        int u = k_tail - 1;

        int k_head = 1;
        while (1) {
            uint64_t r1 = xorshift64(&state);
            k_head = (int)(r1 % (uint64_t)V) + 1;
            uint64_t r2 = xorshift64(&state);
            int left = (int)(r2 % 1000000ULL);
            if (left < accThresh[k_head]) break;
        }
        int v = k_head - 1;

        int idx = writePos[u]++;
        colInd[idx] = v;
        (void)idx;
    }

    // Sources generation: reseed to seed+1 for i=0..19 and ensure uniqueness.
    // We follow the spec exactly: reseed the PRNG state to seed+1 for each i.
    // Collisions advance by drawing again until unique.
    // Use a simple boolean array.
    char *used = (char*)calloc((size_t)V, sizeof(char));
    if (!used) {
        fprintf(stderr, "Allocation failed\n");
        exit(1);
    }

    for (int i = 0; i < source_count; i++) {
        uint64_t st = seed + 1ULL;
        int s;
        while (1) {
            uint64_t r = xorshift64(&st);
            s = (int)(r % (uint64_t)V);
            if (!used[s]) {
                used[s] = 1;
                break;
            }
            // If collision, advance by drawing again
        }
        sources_out[i] = s;
    }

    free(outdeg);
    free(writePos);
    free(accThresh);
    free(used);

    *rowPtr_out = rowPtr;
    *colInd_out = colInd;
}

static double now_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

static void correctness_light_check(int V, int E, const int *rowPtr, const int *colInd,
                                      int source_count, const int *sources,
                                      int *dist1, int *parent1, int *dist2, int *parent2) {
    // One serial run and one parallel run with current OMP_NUM_THREADS.
    bfs_parent_distance_serial(V, E, rowPtr, colInd, source_count, sources, dist1, parent1);
    bfs_parent_distance_omp(V, E, rowPtr, colInd, source_count, sources, dist2, parent2);

    // Verify dist/parent validity against dist only (parent can differ among shortest paths).
    // Since parallel may run all sources and write into same arrays per spec? The signature suggests dist_out/parent_out
    // are sized for V and overwritten per source; however spec says "for each of 20 sources". In typical implementations,
    // dist_out and parent_out hold results for the last source.
    // We'll still compare full arrays for exact equality as a light check.
    // If exact compare is too strict and legitimate variants exist, we do a validity check for reachable nodes.

    int mism = 0;
    for (int i = 0; i < V; i++) {
        if (dist1[i] != dist2[i] || parent1[i] != parent2[i]) { mism = 1; break; }
    }
    if (mism) {
        // Fall back to checking only dist equality.
        mism = 0;
        for (int i = 0; i < V; i++) {
            if (dist1[i] != dist2[i]) { mism = 1; break; }
        }
        if (mism) {
            printf("[check] mismatch detected (dist differs)\n");
        }
    }
}

int main(int argc, char **argv) {
    int nthreads = 0;
    int reps = 20;
    int V = 310000;
    int E = 5000000;
    int source_count = 20;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            V = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--reps") == 0 && i + 1 < argc) {
            reps = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--threads") == 0 && i + 1 < argc) {
            nthreads = atoi(argv[++i]);
        }
    }

    // If user changes V, keep E fixed as spec assumes fixed sizes.
    // But we still allocate based on given V.
    // For simplicity and determinism: if V != 310000, adjust E proportionally.
    if (V != 310000) {
        double scale = (double)V / 310000.0;
        E = (int)llround(5000000.0 * scale);
    }

    int *rowPtr = NULL;
    int *colInd = NULL;
    int *sources = (int*)malloc((size_t)source_count * sizeof(int));
    if (!sources) {
        fprintf(stderr, "Allocation failed\n");
        return 1;
    }

    generate_graph(V, E, &rowPtr, &colInd, sources, source_count);

    int *dist_serial = (int*)malloc((size_t)V * sizeof(int));
    int *parent_serial = (int*)malloc((size_t)V * sizeof(int));
    int *dist_par = (int*)malloc((size_t)V * sizeof(int));
    int *parent_par = (int*)malloc((size_t)V * sizeof(int));
    if (!dist_serial || !parent_serial || !dist_par || !parent_par) {
        fprintf(stderr, "Allocation failed\n");
        return 1;
    }

    // Warmup pass (untimed). Touch output buffers via calls.
    bfs_parent_distance_serial(V, E, rowPtr, colInd, source_count, sources, dist_serial, parent_serial);
    bfs_parent_distance_omp(V, E, rowPtr, colInd, source_count, sources, dist_par, parent_par);

    // Small correctness spot-check (at current thread setting)
    if (nthreads > 0) omp_set_num_threads(nthreads);
    correctness_light_check(V, E, rowPtr, colInd, source_count, sources,
                             dist_serial, parent_serial, dist_par, parent_par);

    // Timing: serial once (baseline), then parallel at increasing thread counts.
    double t_serial = 0.0;
    {
        double t0 = now_sec();
        bfs_parent_distance_serial(V, E, rowPtr, colInd, source_count, sources, dist_serial, parent_serial);
        double t1 = now_sec();
        t_serial = t1 - t0;
        if (t_serial <= 0) t_serial = 1e-9;
    }

    int max_threads = omp_get_max_threads();
    int tested = 0;
    double worst_eff = 1e100;
    int max_t = 1;
    double max_eff = -1.0;
    double eff_at_max = 0.0;

    // Determine thread counts: 1,2,4,... up to max.
    for (int t = 1; t <= max_threads; t <<= 1) {
        omp_set_num_threads(t);
        tested++;

        // Run reps times and take minimum time to reduce noise.
        double best = 1e100;
        for (int r = 0; r < reps; r++) {
            double t0 = now_sec();
            bfs_parent_distance_omp(V, E, rowPtr, colInd, source_count, sources, dist_par, parent_par);
            double t1 = now_sec();
            double dt = t1 - t0;
            if (dt > 0 && dt < best) best = dt;
        }
        if (best <= 0) best = 1e-9;

        double speedup = t_serial / best;
        double efficiency = speedup / (double)t;
        printf("[scale] threads=%d time=%0.6f speedup=%0.3f eff=%0.3f\n", t, best, speedup, efficiency);

        if (t == max_threads || (t << 1) > max_threads) {
            eff_at_max = efficiency;
            max_t = t;
        }
        if (efficiency > max_eff) max_eff = efficiency;
        if (efficiency < worst_eff) worst_eff = efficiency;

        // Stop at the largest power-of-two <= max_threads.
        if ((t << 1) > max_threads) break;
    }

    // Efficiency threshold: shared global critical section contention should crush scalability.
    // Require at highest tested threads that efficiency is still reasonably high for correct performance.
    // For this planted failure, expect very low efficiency.
    // We'll mark failure if efficiency < 0.10 at the highest tested thread count.
    int failures = (eff_at_max < 0.10);

    if (failures) {
        printf("[verdict] PERF-01 exposed\n");
        free(rowPtr); free(colInd); free(sources);
        free(dist_serial); free(parent_serial); free(dist_par); free(parent_par);
        return 1;
    }

    printf("[verdict] PERF-01 not triggered\n");
    free(rowPtr); free(colInd); free(sources);
    free(dist_serial); free(parent_serial); free(dist_par); free(parent_par);
    return 0;
}
