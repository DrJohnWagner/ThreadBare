#include <stdint.h>
#include <stdlib.h>
#include <string.h>

static uint64_t xorshift64star_next(uint64_t *state) {
    uint64_t x = *state;
    x ^= x >> 12;
    x ^= x << 25;
    x ^= x >> 27;
    *state = x;
    return x * 2685821657736338717ULL;
}

static int64_t bfs_parent_distance_single(
    int V,
    const int *rowPtr,
    const int *colInd,
    int s,
    int *dist_out,
    int *parent_out
) {
    int *queue = (int *)malloc((size_t)V * sizeof(int));
    if (!queue) return -1;

    const int UNVIS = -1;

    for (int i = 0; i < V; i++) {
        dist_out[i] = UNVIS;
        parent_out[i] = -1;
    }

    int qh = 0, qt = 0;
    dist_out[s] = 0;
    parent_out[s] = -1;
    queue[qt++] = s;

    while (qh < qt) {
        int u = queue[qh++];
        int du = dist_out[u];
        for (int ei = rowPtr[u]; ei < rowPtr[u + 1]; ei++) {
            int v = colInd[ei];
            if (dist_out[v] == UNVIS) {
                dist_out[v] = du + 1;
                parent_out[v] = u;
                queue[qt++] = v;
            }
        }
    }

    free(queue);
    return 0;
}

void bfs_parent_distance_serial(
    int V,
    int E,
    const int *rowPtr,
    const int *colInd,
    int source_count,
    const int *sources,
    int *dist_out,
    int *parent_out
) {
    for (int si = 0; si < source_count; si++) {
        int s = sources[si];
        int *dist = dist_out ? (dist_out + (size_t)si * (size_t)V) : NULL;
        int *parent = parent_out ? (parent_out + (size_t)si * (size_t)V) : NULL;
        (void)bfs_parent_distance_single(V, rowPtr, colInd, s, dist, parent);
    }
}
