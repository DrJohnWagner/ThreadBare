#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>

static int bfs_parent_distance_single_omp(
    int V,
    const int *rowPtr,
    const int *colInd,
    int s,
    int *dist_out,
    int *parent_out
) {
    const int UNVIS = -1;

    int *queue = (int *)malloc((size_t)V * sizeof(int));
    int *next_queue = (int *)malloc((size_t)V * sizeof(int));
    if (!queue || !next_queue) {
        free(queue);
        free(next_queue);
        return -1;
    }

    for (int i = 0; i < V; i++) {
        dist_out[i] = UNVIS;
        parent_out[i] = -1;
    }

    int qh = 0, qt = 0;
    dist_out[s] = 0;
    parent_out[s] = -1;
    queue[qt++] = s;

    int level = 0;
    while (qh < qt) {
        int frontier_size = qt - qh;
        int next_qt = 0;

        #pragma omp parallel
        {
            int local_next_size = 0;
            int *local_next = (int *)malloc((size_t)frontier_size * sizeof(int));
            int *local_parents = (int *)malloc((size_t)frontier_size * sizeof(int));

            if (!local_next || !local_parents) {
                free(local_next);
                free(local_parents);
                local_next = NULL;
                local_parents = NULL;
            }

            #pragma omp for schedule(static)
            for (int i = 0; i < frontier_size; i++) {
                int u = queue[qh + i];
                for (int ei = rowPtr[u]; ei < rowPtr[u + 1]; ei++) {
                    int v = colInd[ei];
                    if (__sync_bool_compare_and_swap((int *)&dist_out[v], UNVIS, level + 1)) {
                        parent_out[v] = u;

                        if (local_next) {
                            local_next[local_next_size] = v;
                            local_parents[local_next_size] = u;
                            local_next_size++;
                        } else {
                            #pragma omp critical
                            {
                                next_queue[next_qt++] = v;
                            }
                        }
                    }
                }
            }

            if (local_next) {
                #pragma omp critical
                {
                    int base = next_qt;
                    next_qt += local_next_size;
                    for (int k = 0; k < local_next_size; k++) {
                        next_queue[base + k] = local_next[k];
                    }
                }
            }

            free(local_next);
            free(local_parents);
        }

        qh = qt;
        qt = next_qt;
        for (int i = 0; i < qt; i++) {
            queue[i] = next_queue[i];
        }
        level++;
    }

    free(queue);
    free(next_queue);
    return 0;
}

void bfs_parent_distance_omp(
    int V,
    int E,
    const int *rowPtr,
    const int *colInd,
    int source_count,
    const int *sources,
    int *dist_out,
    int *parent_out
) {
    (void)E;

    #pragma omp parallel for schedule(static)
    for (int si = 0; si < source_count; si++) {
        int s = sources[si];
        int *dist = dist_out ? (dist_out + (size_t)si * (size_t)V) : NULL;
        int *parent = parent_out ? (parent_out + (size_t)si * (size_t)V) : NULL;
        if (bfs_parent_distance_single_omp(V, rowPtr, colInd, s, dist, parent) != 0) {
            // Keep behavior defined: on allocation failure, no additional synchronization required.
            // Dist/parent contents are unspecified in this error path.
        }
    }
}
