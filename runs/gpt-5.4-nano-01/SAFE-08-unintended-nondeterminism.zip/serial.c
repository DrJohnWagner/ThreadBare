#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>

void bfs_parent_hop_serial(
    int32_t n,
    int32_t m,
    const int32_t *from,
    const int32_t *to,
    int32_t s,
    const int32_t *sources,
    int32_t *out_hop,
    int32_t *out_parent)
{
    int32_t *row_start = (int32_t *)malloc((size_t)(n + 1) * sizeof(int32_t));
    int32_t *row_counts = (int32_t *)malloc((size_t)n * sizeof(int32_t));
    int32_t *adj = (int32_t *)malloc((size_t)m * sizeof(int32_t));
    int32_t *cursor = (int32_t *)malloc((size_t)n * sizeof(int32_t));

    if (!row_start || !row_counts || !adj || !cursor) {
        free(row_start);
        free(row_counts);
        free(adj);
        free(cursor);
        return;
    }

    for (int32_t i = 0; i < n; i++) row_counts[i] = 0;
    for (int32_t e = 0; e < m; e++) {
        int32_t u = from[e];
        if (u >= 0 && u < n) row_counts[u]++;
    }

    row_start[0] = 0;
    for (int32_t i = 0; i < n; i++) row_start[i + 1] = row_start[i] + row_counts[i];

    for (int32_t i = 0; i < n; i++) cursor[i] = row_start[i];
    for (int32_t e = 0; e < m; e++) {
        int32_t u = from[e];
        if (u < 0 || u >= n) continue;
        int32_t v = to[e];
        adj[cursor[u]++] = v;
    }

    int32_t *hop = (int32_t *)malloc((size_t)n * sizeof(int32_t));
    int32_t *parent = (int32_t *)malloc((size_t)n * sizeof(int32_t));
    int32_t *queue = (int32_t *)malloc((size_t)n * sizeof(int32_t));

    if (!hop || !parent || !queue) {
        free(row_start);
        free(row_counts);
        free(adj);
        free(cursor);
        free(hop);
        free(parent);
        free(queue);
        return;
    }

    for (int32_t si = 0; si < s; si++) {
        int32_t src = sources[si];

        for (int32_t i = 0; i < n; i++) {
            hop[i] = -1;
            parent[i] = -1;
        }

        int32_t qh = 0, qt = 0;
        if (src >= 0 && src < n) {
            hop[src] = 0;
            parent[src] = -1;
            queue[qt++] = src;
        }

        while (qh < qt) {
            int32_t v = queue[qh++];
            int32_t hv = hop[v];
            int32_t start = row_start[v];
            int32_t end = row_start[v + 1];
            for (int32_t ei = start; ei < end; ei++) {
                int32_t w = adj[ei];
                if (w < 0 || w >= n) continue;
                if (hop[w] == -1) {
                    hop[w] = hv + 1;
                    parent[w] = v;
                    queue[qt++] = w;
                }
            }
        }

        int64_t base = (int64_t)si * (int64_t)n;
        for (int32_t i = 0; i < n; i++) {
            out_hop[base + i] = hop[i];
            out_parent[base + i] = parent[i];
        }
    }

    free(row_start);
    free(row_counts);
    free(adj);
    free(cursor);
    free(hop);
    free(parent);
    free(queue);
}
