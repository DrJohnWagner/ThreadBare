/* harness.c — differential driver for bfs_parent_hop (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <omp.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Forward declarations (signatures must match the real ones exactly)
void bfs_parent_hop_serial(int32_t n, int32_t m, const int32_t *from, const int32_t *to,
                           int32_t s, const int32_t *sources,
                           int32_t *out_hop, int32_t *out_parent);

void bfs_parent_hop_omp(int32_t n, int32_t m, const int32_t *from, const int32_t *to,
                       int32_t s, const int32_t *sources,
                       int32_t *out_hop, int32_t *out_parent);

static uint32_t xorshift32(uint32_t *state) {
    uint32_t x = *state;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    *state = x;
    return x;
}

static int32_t rng_mod(uint32_t *state, int32_t mod) {
    // Deterministic modulo without bias concerns (fine for harness generation)
    return (int32_t)(xorshift32(state) % (uint32_t)mod);
}

static void build_powerlaw_graph(int32_t n, int32_t m, int32_t *from, int32_t *to) {
    // Implements the spec's preferential-attachment-like generator.
    // stake[u] starts at 1 and is incremented on acceptance.
    // Choose u via rejection sampling proportional to stake.
    int32_t *stake = (int32_t*)malloc((size_t)n * sizeof(int32_t));
    if (!stake) {
        fprintf(stderr, "alloc failed\n");
        exit(1);
    }
    for (int32_t i = 0; i < n; i++) stake[i] = 1;

    int32_t stake_max = 1;
    uint32_t st = 123456789u;

    for (int32_t e = 0; e < m; e++) {
        int32_t u;
        while (1) {
            int32_t c = rng_mod(&st, n);
            // accept with probability stake[c] / stake_max
            // Use an exact compare to avoid float:
            // Draw r in [0, stake_max-1] and accept if r < stake[c].
            uint32_t r = xorshift32(&st);
            int32_t rr = (int32_t)(r % (uint32_t)stake_max);
            if (rr < stake[c]) {
                u = c;
                break;
            }
            // otherwise retry
        }

        int32_t v = rng_mod(&st, n);
        from[e] = u;
        to[e] = v;

        // Update stake and stake_max
        stake[u] += 1;
        if (stake[u] > stake_max) stake_max = stake[u];
    }

    free(stake);
}

static void build_sources(int32_t n, int32_t s, int32_t *sources) {
    uint32_t st = 987654321u;
    for (int32_t i = 0; i < s; i++) {
        sources[i] = rng_mod(&st, n);
    }
}

static void usage(const char *prog) {
    fprintf(stderr,
            "Usage: %s [--n N] [--m M] [--reps R] [--threads T]\n"
            "Defaults: N=310000 M=5000000 R=20\n", prog);
}

int main(int argc, char **argv) {
    int32_t n = 310000;
    int32_t m = 5000000;
    int reps = 20;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--n") && i + 1 < argc) {
            n = (int32_t)atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--m") && i + 1 < argc) {
            m = (int32_t)atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--reps") && i + 1 < argc) {
            reps = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) {
            usage(argv[0]);
            return 0;
        } else {
            fprintf(stderr, "Unknown/invalid arg: %s\n", argv[i]);
            usage(argv[0]);
            return 1;
        }
    }

    int32_t s = 20;

    int32_t *from = (int32_t*)malloc((size_t)m * sizeof(int32_t));
    int32_t *to   = (int32_t*)malloc((size_t)m * sizeof(int32_t));
    int32_t *sources = (int32_t*)malloc((size_t)s * sizeof(int32_t));
    int32_t *serial_hop = (int32_t*)malloc((size_t)n * sizeof(int32_t));
    int32_t *serial_parent = (int32_t*)malloc((size_t)n * sizeof(int32_t));
    int32_t *par_hop = (int32_t*)malloc((size_t)n * sizeof(int32_t));
    int32_t *par_parent = (int32_t*)malloc((size_t)n * sizeof(int32_t));

    if (!from || !to || !sources || !serial_hop || !serial_parent || !par_hop || !par_parent) {
        fprintf(stderr, "alloc failed\n");
        return 1;
    }

    build_powerlaw_graph(n, m, from, to);
    build_sources(n, s, sources);

    // Ground truth from serial (once)
    bfs_parent_hop_serial(n, m, from, to, s, sources, serial_hop, serial_parent);

    int failures = 0;
    const int64_t total_elems = (int64_t)n; // compare full arrays

    for (int r = 0; r < reps; r++) {
        bfs_parent_hop_omp(n, m, from, to, s, sources, par_hop, par_parent);

        // Compare hop then parent (parent nondeterminism is expected/likely)
        int first_mismatch = 0;
        int32_t idx = -1;
        int which = 0;

        for (int32_t v = 0; v < n; v++) {
            if (par_hop[v] != serial_hop[v]) {
                first_mismatch = 1;
                idx = v;
                which = 1; // hop
                break;
            }
        }
        if (!first_mismatch) {
            for (int32_t v = 0; v < n; v++) {
                if (par_parent[v] != serial_parent[v]) {
                    first_mismatch = 1;
                    idx = v;
                    which = 2; // parent
                    break;
                }
            }
        }

        if (first_mismatch) {
            failures = 1;
            printf("[check] divergence in %s at v=%d (rep=%d): serial hop/parent=%d/%d, parallel=%d/%d\n",
                   (which==1?"hop":"parent"), (int)idx, r,
                   (int)serial_hop[idx], (int)serial_parent[idx],
                   (int)par_hop[idx], (int)par_parent[idx]);
            break;
        }

        if (r == 0) {
            // mild signal
        }
    }

    free(from);
    free(to);
    free(sources);
    free(serial_hop);
    free(serial_parent);
    free(par_hop);
    free(par_parent);

    // Exactly one line verdict
    printf("[verdict] %s\n", failures ? "SAFE-01 exposed" : "SAFE-01 not triggered");
    return failures ? 1 : 0;
}
