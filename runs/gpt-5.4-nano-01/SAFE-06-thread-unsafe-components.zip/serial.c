#include <stdint.h>
#include <stddef.h>

static inline uint32_t xorshift32(uint32_t state) {
    state ^= state << 13;
    state ^= state >> 17;
    state ^= state << 5;
    return state;
}

static inline double decoded_value(int16_t raw, uint32_t sensor_id) {
    return 0.1 * (double)raw + (double)(sensor_id % 3) * 0.05;
}

void sensor_log_three_stage_ingest_serial(
    uint32_t F, uint32_t R, uint32_t S, uint32_t seed,
    uint32_t *out_count, double *out_sum, double *out_sumsq)
{
    uint32_t f, i, s;

    for (f = 0; f < F; f++) {
        for (s = 0; s < S; s++) {
            out_count[f * S + s] = 0u;
            out_sum[f * S + s] = 0.0;
            out_sumsq[f * S + s] = 0.0;
        }

        uint32_t state = seed ^ (f * 0x9e3779b9u);
        for (i = 0; i < R; i++) {
            state = xorshift32(state);
            uint32_t sensor_id = state % S;

            state = xorshift32(state);
            uint32_t r = state % 65536u;
            int16_t raw = (int16_t)((int32_t)r - 32768);

            double val = decoded_value(raw, sensor_id);
            uint32_t idx = f * S + sensor_id;
            out_count[idx] += 1u;
            out_sum[idx] += val;
            out_sumsq[idx] += val * val;
        }
    }
}
