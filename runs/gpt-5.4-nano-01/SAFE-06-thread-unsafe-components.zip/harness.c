/* harness.c — differential driver for sensor_log_three_stage_ingest (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <omp.h>

// Forward declarations matching serial.c / parallel.c.
void sensor_log_three_stage_ingest_serial(
    uint32_t F, uint32_t R, uint32_t S, uint32_t seed,
    uint32_t *out_count, double *out_sum, double *out_sumsq);

void sensor_log_three_stage_ingest_omp(
    uint32_t F, uint32_t R, uint32_t S, uint32_t seed,
    uint32_t *out_count, double *out_sum, double *out_sumsq);

static uint32_t xorshift32(uint32_t *state) {
    uint32_t x = *state;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    *state = x;
    return x;
}

static void generate_synthetic_inputs(
    uint32_t F, uint32_t R, uint32_t S, uint32_t seed,
    uint32_t *out_count, double *out_sum, double *out_sumsq) {
    // Reference generation for sanity (not used by the kernels since they already
    // generate internally deterministically). Kept here for deterministic
    // allocation sizing / potential future checks.
    // We'll not compute these arrays; we use the serial kernel as ground truth.
    (void)F; (void)R; (void)S; (void)seed;
    (void)out_count; (void)out_sum; (void)out_sumsq;
}

static int diff_check_once(
    uint32_t F, uint32_t R, uint32_t S, uint32_t seed,
    uint32_t *count_ref, double *sum_ref, double *sumsq_ref,
    uint32_t *count_par, double *sum_par, double *sumsq_par,
    double tol) {

    sensor_log_three_stage_ingest_omp(F, R, S, seed, count_par, sum_par, sumsq_par);

    const uint64_t rows = (uint64_t)F * (uint64_t)S;
    for (uint64_t idx = 0; idx < rows; idx++) {
        if (count_par[idx] != count_ref[idx]) {
            uint32_t f = (uint32_t)(idx / S);
            uint32_t s = (uint32_t)(idx % S);
            printf("[check] mismatch at (f=%u,s=%u): count par=%u ref=%u\n",
                   f, s, count_par[idx], count_ref[idx]);
            return 1;
        }
        double ds = fabs(sum_par[idx] - sum_ref[idx]);
        if (ds > tol) {
            uint32_t f = (uint32_t)(idx / S);
            uint32_t s = (uint32_t)(idx % S);
            printf("[check] mismatch at (f=%u,s=%u): sum par=%.17g ref=%.17g diff=%.3g\n",
                   f, s, sum_par[idx], sum_ref[idx], ds);
            return 1;
        }
        double dss = fabs(sumsq_par[idx] - sumsq_ref[idx]);
        if (dss > tol) {
            uint32_t f = (uint32_t)(idx / S);
            uint32_t s = (uint32_t)(idx % S);
            printf("[check] mismatch at (f=%u,s=%u): sumsq par=%.17g ref=%.17g diff=%.3g\n",
                   f, s, sumsq_par[idx], sumsq_ref[idx], dss);
            return 1;
        }
    }
    return 0;
}

int main(int argc, char **argv) {
    uint32_t F = 200;
    uint32_t R = 23000;
    uint32_t S = 16;
    uint32_t seed = 1234567u; // deterministic constant as per spec note

    int reps = 25;
    double tol = 1e-9;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--reps") == 0 && i + 1 < argc) {
            reps = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            // --n maps to F in this benchmark's problemSizes list; spec says default to
            // largest value in problemSizes unless slow. Here safety failure should
            // show with the default. We interpret --n as F scaling for convenience.
            F = (uint32_t)strtoul(argv[++i], NULL, 10);
        } else {
            fprintf(stderr, "Unknown/invalid arg: %s\n", argv[i]);
            return 2;
        }
    }
    if (reps < 1) reps = 1;

    uint64_t rows = (uint64_t)F * (uint64_t)S;
    uint32_t *count_ref = (uint32_t*)calloc((size_t)rows, sizeof(uint32_t));
    uint32_t *count_par = (uint32_t*)calloc((size_t)rows, sizeof(uint32_t));
    double *sum_ref = (double*)calloc((size_t)rows, sizeof(double));
    double *sum_par = (double*)calloc((size_t)rows, sizeof(double));
    double *sumsq_ref = (double*)calloc((size_t)rows, sizeof(double));
    double *sumsq_par = (double*)calloc((size_t)rows, sizeof(double));
    if (!count_ref || !count_par || !sum_ref || !sum_par || !sumsq_ref || !sumsq_par) {
        fprintf(stderr, "Allocation failed\n");
        return 3;
    }

    // Ground truth: serial run once.
    sensor_log_three_stage_ingest_serial(F, R, S, seed, count_ref, sum_ref, sumsq_ref);

    int failures = 0;
    for (int r = 0; r < reps; r++) {
        memset(count_par, 0, (size_t)rows * sizeof(uint32_t));
        memset(sum_par, 0, (size_t)rows * sizeof(double));
        memset(sumsq_par, 0, (size_t)rows * sizeof(double));

        if (diff_check_once(F, R, S, seed, count_ref, sum_ref, sumsq_ref,
                           count_par, sum_par, sumsq_par, tol)) {
            failures = 1;
            break;
        }
    }

    printf("[verdict] %s\n", failures ? "SAFE-01 exposed" : "SAFE-01 not triggered");

    free(count_ref);
    free(count_par);
    free(sum_ref);
    free(sum_par);
    free(sumsq_ref);
    free(sumsq_par);
    return failures ? 1 : 0;
}
