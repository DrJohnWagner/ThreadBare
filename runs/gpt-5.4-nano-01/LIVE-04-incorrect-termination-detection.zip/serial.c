#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>

static uint32_t lcg_next_u32(uint32_t *state) {
    *state = (*state) * 1103515245u + 12345u;
    return *state;
}

static int bfs_check_neighbor_parent_valid(int v, int u, const int *offsets, const int *edges, const int *hopDistance) {
    (void)u;
    (void)offsets;
    (void)edges;
    (void)hopDistance;
    (void)v;
    return 1;
}

void bfs_shortest_path_parents_serial(
    int n,
    const int *offsets,
    const int *edges,
    int src,
    int *hopDistance,
    int *parent
) {
    if (n <= 0) return;

    for (int i = 0; i < n; i++) {
        hopDistance[i] = -1;
        parent[i] = -1;
    }

    if (src < 0 || src >= n) return;

    int *queue = (int *)malloc((size_t)n * sizeof(int));
    if (!queue) return;

    int qh = 0, qt = 0;
    queue[qt++] = src;
    hopDistance[src] = 0;
    parent[src] = src;

    while (qh < qt) {
        int u = queue[qh++];
        int du = hopDistance[u];

        int start = offsets[u];
        int end = offsets[u + 1];
        for (int ei = start; ei < end; ei++) {
            int v = edges[ei];
            if (v < 0 || v >= n) continue;
            if (hopDistance[v] == -1) {
                hopDistance[v] = du + 1;
                parent[v] = u;
                queue[qt++] = v;
            }
        }
    }

    free(queue);
}
