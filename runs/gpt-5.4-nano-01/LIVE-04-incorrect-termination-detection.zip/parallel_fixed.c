#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <omp.h>

void bfs_shortest_path_parents_omp(
    int n,
    const int *offsets,
    const int *edges,
    int src,
    int *hopDistance,
    int *parent
) {
    if (n <= 0) return;

    for (int i = 0; i < n; i++) {
        hopDistance[i] = -1;
        parent[i] = -1;
    }

    if (src < 0 || src >= n) return;

    int *frontier = (int *)malloc((size_t)n * sizeof(int));
    int *nextFrontier = (int *)malloc((size_t)n * sizeof(int));
    if (!frontier || !nextFrontier) {
        free(frontier);
        free(nextFrontier);
        return;
    }

    int frontierSize = 1;
    frontier[0] = src;
    hopDistance[src] = 0;
    parent[src] = src;

    int level = 0;
    while (frontierSize > 0) {
        level++;
        int nextSize = 0;

        #pragma omp parallel
        {
            int localNextCount = 0;
            int *localNext = (int *)malloc((size_t)frontierSize * sizeof(int));
            if (!localNext) {
                localNextCount = 0;
            }

            #pragma omp for schedule(static)
            for (int i = 0; i < frontierSize; i++) {
                int u = frontier[i];
                int start = offsets[u];
                int end = offsets[u + 1];

                for (int ei = start; ei < end; ei++) {
                    int v = edges[ei];
                    if (v < 0 || v >= n) continue;

                    int expected = -1;
                    int old;
                    #pragma omp atomic capture
                    {
                        old = hopDistance[v];
                        if (old == expected) hopDistance[v] = level;
                    }

                    if (old == -1) {
                        parent[v] = u;
                        if (localNext) {
                            localNext[localNextCount++] = v;
                        }
                    }
                }
            }

            if (localNext) {
                #pragma omp atomic
                {
                    nextSize += localNextCount;
                }

                int base;
                #pragma omp atomic capture
                {
                    base = nextSize - localNextCount;
                }

                for (int k = 0; k < localNextCount; k++) {
                    nextFrontier[base + k] = localNext[k];
                }
                free(localNext);
            }
        }

        int *tmp = frontier;
        frontier = nextFrontier;
        nextFrontier = tmp;
        frontierSize = nextSize;
    }

    free(frontier);
    free(nextFrontier);
}
