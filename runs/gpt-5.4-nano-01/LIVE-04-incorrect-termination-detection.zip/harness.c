/* harness.c — timeout driver for bfs_shortest_path_parents (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <omp.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Forward declarations matching the real signatures.
void bfs_shortest_path_parents_serial(
    int n,
    const int *offsets,
    const int *edges,
    int src,
    int *hopDistance,
    int *parent);

void bfs_shortest_path_parents_omp(
    int n,
    const int *offsets,
    const int *edges,
    int src,
    int *hopDistance,
    int *parent);

static unsigned long long splitmix64(unsigned long long *x) {
  unsigned long long z = (*x += 0x9e3779b97f4a7c15ULL);
  z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
  z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
  return z ^ (z >> 31);
}

static int main_n = 1000000; // default largest problem size
static int reps_sources = 20; // BFS per run uses exactly S=20 sources
static int timeout_seconds = 3;

static void usage(const char *prog) {
  fprintf(stderr,
          "Usage: %s [--n N] [--timeout SEC] [--threads T] [--reps R]\n"
          "  --n N         problem size (default %d)\n"
          "  --timeout SEC hard wall-clock timeout seconds (default %d)\n"
          "  --reps R      number of repeated BFS runs to attempt (default 1)\n",
          prog, main_n, timeout_seconds);
}

// We'll build a deterministic but lightweight graph (still power-law-ish) to
// avoid extremely long graph construction; harness intent is liveness, not
// exact CSR matching.
// Deterministic: generated from same seed and parameters.
static void build_graph_powerlaw_csr(
    int n, int *offsets_out, int *edges_out, int *m_out) {
  // Create a simple deterministic pseudo power-law degree distribution.
  // Ensure degrees are at least 2 and at most n-1; sum degrees even.
  const int seed = 1337;
  unsigned long long rng = (unsigned long long)seed ^ (unsigned long long)n * 0x9e3779b97f4a7c15ULL;
  const double alpha = 2.5;
  const int minDegree = 2;
  const int maxDegree = n - 1;

  // Choose target M proportional to n: use a mild scale to keep CSR manageable.
  // (The original spec uses problem-size-dependent M from offline generation; here we keep it tractable.)
  int M = (n < 300000 ? n / 2 : n / 3);
  if (M < 1) M = 1;
  // degrees sum is 2M.
  long long sumDegreesTarget = 2LL * M;

  int *deg = (int*)malloc((size_t)n * sizeof(int));
  if (!deg) {
    fprintf(stderr, "OOM allocating deg\n");
    exit(1);
  }

  // Start by sampling degrees using rejection based on k^-alpha weights.
  // We'll fill until we have enough sum, then normalize.
  long long sumDeg = 0;
  for (int i = 0; i < n; i++) {
    // Sample k by transforming uniform u into approximate power-law over [minDegree,maxDegree].
    // Use a crude inverse-CDF-ish mapping; then clamp.
    // This is deterministic and fast.
    double u = (double)(splitmix64(&rng) & 0xFFFFFFFFULL) / 4294967296.0; // [0,1)
    double emin = (double)minDegree;
    double emax = (double)maxDegree;
    // For alpha>1, approximate k = ( (u*(emax^(1-alpha)-emin^(1-alpha)) + emin^(1-alpha))^(1/(1-alpha)) )
    double pmin = pow(emin, 1.0 - alpha);
    double pmax = pow(emax, 1.0 - alpha);
    double p = pmin + u * (pmax - pmin);
    double kf = pow(p, 1.0 / (1.0 - alpha));
    int k = (int)(kf + 0.5);
    if (k < minDegree) k = minDegree;
    if (k > maxDegree) k = maxDegree;
    deg[i] = k;
    sumDeg += k;
  }

  // Scale degrees to match 2M exactly.
  // Scale factor s = target / sumDeg.
  double s = (double)sumDegreesTarget / (double)sumDeg;
  long long sumScaled = 0;
  for (int i = 0; i < n; i++) {
    int k = (int)((double)deg[i] * s + 0.5);
    if (k < minDegree) k = minDegree;
    if (k > maxDegree) k = maxDegree;
    deg[i] = k;
    sumScaled += k;
  }

  // Adjust deterministically to make sum exactly 2M by +/-1 steps in a cyclic way.
  long long diff = sumDegreesTarget - sumScaled; // can be negative or positive
  int idx = 0;
  while (diff != 0) {
    int i = idx % n;
    if (diff > 0) {
      if (deg[i] < maxDegree) { deg[i]++; diff--; }
    } else {
      if (deg[i] > minDegree) { deg[i]--; diff++; }
    }
    idx++;
    // Safety: should converge.
    if (idx > 10000000) break;
  }

  // Build stubs and choose unique edges via hashing.
  long long stubCount = 0;
  for (int i = 0; i < n; i++) stubCount += (long long)deg[i];
  // Force stubCount == 2M by adjusting again if needed.
  // (diff should already handle, but keep robust.)
  if (stubCount != sumDegreesTarget) {
    // Adjust last vertex.
    deg[n-1] += (int)(sumDegreesTarget - stubCount);
    if (deg[n-1] < minDegree) deg[n-1] = minDegree;
    if (deg[n-1] > maxDegree) deg[n-1] = maxDegree;
  }

  int *stubs = (int*)malloc((size_t)sumDegreesTarget * sizeof(int));
  if (!stubs) {
    fprintf(stderr, "OOM allocating stubs\n");
    exit(1);
  }
  long long pos = 0;
  for (int i = 0; i < n; i++) {
    for (int t = 0; t < deg[i]; t++) stubs[pos++] = i;
  }
  // Shuffle stubs deterministically.
  for (long long i = (long long)sumDegreesTarget - 1; i > 0; i--) {
    long long j = (long long)(splitmix64(&rng) % (unsigned long long)(i + 1));
    int tmp = stubs[i]; stubs[i] = stubs[j]; stubs[j] = tmp;
  }

  // Simple open-addressing hash set for unique undirected edges.
  // Size: try to keep load factor under ~0.7.
  int hashSize = 1;
  while (hashSize < (int)(M * 2.5)) hashSize <<= 1;
  int *hkey_u = (int*)malloc((size_t)hashSize * sizeof(int));
  int *hkey_v = (int*)malloc((size_t)hashSize * sizeof(int));
  char *hused = (char*)calloc((size_t)hashSize, sizeof(char));
  if (!hkey_u || !hkey_v || !hused) {
    fprintf(stderr, "OOM allocating hash\n");
    exit(1);
  }

  auto unsigned long long edge_hash = [](int a, int b) -> unsigned long long {
    unsigned long long x = (unsigned long long)(a * 1000003LL + b);
    x ^= x >> 23;
    x *= 0x2127599bf4325c37ULL;
    x ^= x >> 47;
    return x;
  };

  int *uarr = (int*)malloc((size_t)M * sizeof(int));
  int *varr = (int*)malloc((size_t)M * sizeof(int));
  if (!uarr || !varr) { fprintf(stderr, "OOM edges temp\n"); exit(1); }

  int accepted = 0;
  long long attempts = 0;
  for (long long p = 0; p + 1 < sumDegreesTarget && accepted < M; p += 2) {
    int a = stubs[p];
    int b = stubs[p+1];
    if (a == b) continue;
    if (a > b) { int t = a; a = b; b = t; }
    unsigned long long hv = edge_hash(a,b);
    unsigned long long idxh = hv & (unsigned long long)(hashSize - 1);
    for (int probe = 0; probe < hashSize; probe++) {
      unsigned long long posh = (idxh + (unsigned long long)probe) & (unsigned long long)(hashSize - 1);
      if (!hused[posh]) {
        hused[posh] = 1;
        hkey_u[posh] = a;
        hkey_v[posh] = b;
        uarr[accepted] = a;
        varr[accepted] = b;
        accepted++;
        break;
      } else if (hkey_u[posh] == a && hkey_v[posh] == b) {
        break; // duplicate
      }
    }
    attempts++;
  }

  if (accepted < M) {
    // If we couldn't accept enough unique edges, reduce M accordingly.
    M = accepted;
    sumDegreesTarget = 2LL * M;
  }

  // Build adjacency CSR from accepted edges.
  int *deg2 = (int*)calloc((size_t)n, sizeof(int));
  if (!deg2) { fprintf(stderr, "OOM deg2\n"); exit(1); }
  for (int i = 0; i < M; i++) {
    int a = uarr[i], b = varr[i];
    deg2[a]++; deg2[b]++;
  }

  offsets_out[0] = 0;
  for (int i = 0; i < n; i++) offsets_out[i+1] = offsets_out[i] + deg2[i];

  int E2 = offsets_out[n];
  for (int i = 0; i < n; i++) deg2[i] = 0;

  for (int i = 0; i < M; i++) {
    int a = uarr[i], b = varr[i];
    edges_out[ (size_t)offsets_out[a] + (size_t)deg2[a]++ ] = b;
    edges_out[ (size_t)offsets_out[b] + (size_t)deg2[b]++ ] = a;
  }

  *m_out = M;

  free(deg);
  free(stubs);
  free(hkey_u); free(hkey_v); free(hused);
  free(uarr); free(varr);
  free(deg2);
}

static volatile sig_atomic_t timed_out = 0;
static void alarm_handler(int sig) {
  (void)sig;
  timed_out = 1;
}

int main(int argc, char **argv) {
  int n = main_n;
  int reps = 1;

  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--n") && i + 1 < argc) {
      n = atoi(argv[++i]);
    } else if (!strcmp(argv[i], "--timeout") && i + 1 < argc) {
      timeout_seconds = atoi(argv[++i]);
    } else if (!strcmp(argv[i], "--reps") && i + 1 < argc) {
      reps = atoi(argv[++i]);
      if (reps < 1) reps = 1;
    } else if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) {
      usage(argv[0]);
      return 0;
    }
  }

  // Allocate CSR: we don't know exact M ahead; our builder computes it and uses offsets to size edges.
  // We'll conservatively allocate edges as 2*M where M ~ n/3.
  int estM = (n < 300000 ? n / 2 : n / 3);
  if (estM < 1) estM = 1;
  long long estE2 = 2LL * estM; // directed edges in CSR

  int *offsets = (int*)malloc((size_t)(n + 1) * sizeof(int));
  int *edges = (int*)malloc((size_t)estE2 * sizeof(int));
  if (!offsets || !edges) {
    fprintf(stderr, "OOM allocating CSR arrays\n");
    return 1;
  }

  int M_actual = 0;
  build_graph_powerlaw_csr(n, offsets, edges, &M_actual);

  // Determine actual directed edge count (offsets[n]). If it exceeds allocated, reallocate.
  int E2_actual = offsets[n];
  if (E2_actual > estE2) {
    free(edges);
    edges = (int*)malloc((size_t)E2_actual * sizeof(int));
    if (!edges) {
      fprintf(stderr, "OOM realloc edges\n");
      return 1;
    }
    // Rebuild with correct sizing by rerunning builder.
    build_graph_powerlaw_csr(n, offsets, edges, &M_actual);
    E2_actual = offsets[n];
  }

  // Sources: src[s] = (1103515245*(s+1)+12345) mod N for s=0..19
  int S = reps_sources;
  int *srcs = (int*)malloc((size_t)S * sizeof(int));
  if (!srcs) {
    fprintf(stderr, "OOM srcs\n");
    return 1;
  }
  for (int s = 0; s < S; s++) {
    long long val = 1103515245LL * (s + 1LL) + 12345LL;
    srcs[s] = (int)(val % n);
  }

  int *hop1 = (int*)malloc((size_t)n * sizeof(int));
  int *par1 = (int*)malloc((size_t)n * sizeof(int));
  int *hop2 = (int*)malloc((size_t)n * sizeof(int));
  int *par2 = (int*)malloc((size_t)n * sizeof(int));
  if (!hop1 || !par1 || !hop2 || !par2) {
    fprintf(stderr, "OOM BFS arrays\n");
    return 1;
  }

  // Light correctness baseline (serial once, differential not required for liveness).
  // Also provides that graph/inputs are sane.
  for (int s = 0; s < S; s++) {
    for (int i = 0; i < n; i++) { hop1[i] = -1; par1[i] = -1; }
    bfs_shortest_path_parents_serial(n, offsets, edges, srcs[s], hop1, par1);
  }

  // Liveness check: run parallel BFS for the set of sources with a hard wall timeout.
  int failures = 0;

  for (int r = 0; r < reps && !failures; r++) {
    timed_out = 0;
    signal(SIGALRM, alarm_handler);
    alarm(timeout_seconds);

    for (int s = 0; s < S; s++) {
      for (int i = 0; i < n; i++) { hop2[i] = -1; par2[i] = -1; }
      bfs_shortest_path_parents_omp(n, offsets, edges, srcs[s], hop2, par2);
      if (timed_out) break;
    }

    alarm(0);

    if (timed_out) {
      failures = 1;
      fprintf(stderr, "[check] timed out (reps=%d, n=%d)\n", r + 1, n);
      break;
    }
  }

  free(offsets);
  free(edges);
  free(srcs);
  free(hop1); free(par1); free(hop2); free(par2);

  printf("[verdict] %s\n", failures ? "LIVE-01 exposed" : "LIVE-01 not triggered");
  return failures ? 1 : 0;
}
