/* harness.c — timeout driver for sensor_ingest_pipeline_summary (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#define _GNU_SOURCE
#include <omp.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>

typedef void (*kernel_fn)(uint32_t F, uint32_t R, uint32_t N, uint32_t seed,
                           double *out_total_sum,
                           double *out_total_sumsq,
                           uint64_t *out_total_count,
                           uint64_t *out_counts,
                           double *out_sums,
                           double *out_sumsq);

static uint32_t hash_u32(uint32_t a, uint32_t b, uint32_t c) {
    uint32_t x = (uint32_t)(a * 1103515245u + b * 12345u + c * 2654435761u);
    return x; // mod 2^32 via uint32 overflow
}

/* Wall-clock timeout helpers */
static volatile sig_atomic_t g_timed_out = 0;
static void alarm_handler(int sig) {
    (void)sig;
    g_timed_out = 1;
}

static int run_with_timeout(kernel_fn fn,
                             uint32_t F, uint32_t R, uint32_t N, uint32_t seed,
                             double *out_total_sum,
                             double *out_total_sumsq,
                             uint64_t *out_total_count,
                             uint64_t *out_counts,
                             double *out_sums,
                             double *out_sumsq,
                             int timeout_seconds) {
    g_timed_out = 0;

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = alarm_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;

    if (sigaction(SIGALRM, &sa, NULL) != 0) {
        perror("sigaction");
        return 0;
    }

    alarm(timeout_seconds);
    fn(F, R, N, seed, out_total_sum, out_total_sumsq, out_total_count, out_counts, out_sums, out_sumsq);
    alarm(0);

    return g_timed_out ? 0 : 1;
}

int main(int argc, char **argv) {
    int timeout_seconds = 2; // default for liveness
    int omp_threads = 0;
    int do_serial = 1;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--timeout") == 0 && i + 1 < argc) {
            timeout_seconds = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--threads") == 0 && i + 1 < argc) {
            omp_threads = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--no-serial") == 0) {
            do_serial = 0;
        } else {
            fprintf(stderr, "usage: %s [--timeout S] [--threads T] [--no-serial]\n", argv[0]);
            return 1;
        }
    }

    if (omp_threads > 0) {
        omp_set_num_threads(omp_threads);
    }

    const uint32_t F = 200;
    const uint32_t R = 23000;
    const uint32_t N = 8;
    const uint32_t seed = 123456u;

    size_t rows = (size_t)F * (size_t)N;

    double *out_total_sum = (double*)calloc(1, sizeof(double));
    double *out_total_sumsq = (double*)calloc(1, sizeof(double));
    uint64_t *out_total_count = (uint64_t*)calloc(1, sizeof(uint64_t));

    uint64_t *out_counts = (uint64_t*)calloc(rows, sizeof(uint64_t));
    double *out_sums = (double*)calloc(rows, sizeof(double));
    double *out_sumsq = (double*)calloc(rows, sizeof(double));

    if (!out_total_sum || !out_total_sumsq || !out_total_count || !out_counts || !out_sums || !out_sumsq) {
        fprintf(stderr, "allocation failed\n");
        return 1;
    }

    /* Forward declarations must match real signatures exactly */
    extern void sensor_ingest_pipeline_summary_serial(uint32_t F, uint32_t R, uint32_t N, uint32_t seed,
        double *out_total_sum,
        double *out_total_sumsq,
        uint64_t *out_total_count,
        uint64_t *out_counts,
        double *out_sums,
        double *out_sumsq);

    extern void sensor_ingest_pipeline_summary_omp(uint32_t F, uint32_t R, uint32_t N, uint32_t seed,
        double *out_total_sum,
        double *out_total_sumsq,
        uint64_t *out_total_count,
        uint64_t *out_counts,
        double *out_sums,
        double *out_sumsq);

    kernel_fn serial_fn = sensor_ingest_pipeline_summary_serial;
    kernel_fn parallel_fn = sensor_ingest_pipeline_summary_omp;

    if (do_serial) {
        memset(out_counts, 0, rows * sizeof(uint64_t));
        memset(out_sums, 0, rows * sizeof(double));
        memset(out_sumsq, 0, rows * sizeof(double));
        *out_total_sum = 0.0;
        *out_total_sumsq = 0.0;
        *out_total_count = 0;

        serial_fn(F, R, N, seed,
                  out_total_sum, out_total_sumsq, out_total_count,
                  out_counts, out_sums, out_sumsq);
    }

    /* Differential correctness is not the goal here—only whether it makes progress. */
    memset(out_counts, 0, rows * sizeof(uint64_t));
    memset(out_sums, 0, rows * sizeof(double));
    memset(out_sumsq, 0, rows * sizeof(double));
    *out_total_sum = 0.0;
    *out_total_sumsq = 0.0;
    *out_total_count = 0;

    int finished = run_with_timeout(parallel_fn,
                                   F, R, N, seed,
                                   out_total_sum, out_total_sumsq, out_total_count,
                                   out_counts, out_sums, out_sumsq,
                                   timeout_seconds);

    int failures = finished ? 0 : 1;

    printf("[verdict] %s\n", failures ? "LIVE-01 exposed" : "LIVE-01 not triggered");

    free(out_total_sum);
    free(out_total_sumsq);
    free(out_total_count);
    free(out_counts);
    free(out_sums);
    free(out_sumsq);

    return failures ? 1 : 0;
}
