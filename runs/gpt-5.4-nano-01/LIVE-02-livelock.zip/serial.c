#include <stdint.h>
#include <stddef.h>
#include <math.h>

static uint32_t hash_u32(uint32_t a, uint32_t b, uint32_t c) {
    uint64_t x = (uint64_t)a * 1103515245u + (uint64_t)b * 12345u + (uint64_t)c * 2654435761u;
    return (uint32_t)(x & 0xFFFFFFFFu);
}

void sensor_ingest_pipeline_summary_serial(
    uint32_t F,
    uint32_t R,
    uint32_t N,
    uint32_t seed,
    double *out_total_sum,
    double *out_total_sumsq,
    uint64_t *out_total_count,
    uint64_t *out_counts,
    double *out_sums,
    double *out_sumsq
) {
    if (!out_total_sum || !out_total_sumsq || !out_total_count || !out_counts || !out_sums || !out_sumsq) {
        return;
    }

    const size_t rows = (size_t)F * (size_t)N;
    for (size_t idx = 0; idx < rows; ++idx) {
        out_counts[idx] = 0;
        out_sums[idx] = 0.0;
        out_sumsq[idx] = 0.0;
    }

    uint64_t total_count = 0;
    double total_sum = 0.0;
    double total_sumsq = 0.0;

    const double inv32768 = 1.0 / 32768.0;

    for (uint32_t f = 0; f < F; ++f) {
        for (uint32_t i = 0; i < R; ++i) {
            uint32_t sid = hash_u32(seed, f, i) % N;
            uint32_t ts = hash_u32(seed + 1u, f, i) % 1000000u;
            (void)ts;

            int32_t h2 = (int32_t)hash_u32(seed + 2u, f, i);
            double val = (double)(h2 - (int32_t)0x80000000u) * inv32768;

            uint32_t q = hash_u32(seed + 3u, f, i) % 100u;
            double val_dec = (q >= 50u) ? val : (0.5 * val);

            size_t row = (size_t)f * (size_t)N + (size_t)sid;
            out_counts[row] += 1u;
            out_sums[row] += val_dec;
            out_sumsq[row] += val_dec * val_dec;

            total_count += 1u;
            total_sum += val_dec;
            total_sumsq += val_dec * val_dec;
        }
    }

    *out_total_count = total_count;
    *out_total_sum = total_sum;
    *out_total_sumsq = total_sumsq;
}
