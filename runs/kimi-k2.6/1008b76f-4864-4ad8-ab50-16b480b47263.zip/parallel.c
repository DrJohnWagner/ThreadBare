void lloyds_k_means_omp(const double points[][2], const double initial_centroids[][2], int N, int K, int labels[], double centroids[][2])
{
    int i, k;

    for (k = 0; k < K; k++) {
        centroids[k][0] = initial_centroids[k][0];
        centroids[k][1] = initial_centroids[k][1];
    }

    #pragma omp parallel for
    for (i = 0; i < N; i++) {
        labels[i] = -1;
    }

    int changed = 1;
    while (changed) {
        changed = 0;

        #pragma omp parallel for reduction(+:changed) private(k)
        for (i = 0; i < N; i++) {
            double px = points[i][0];
            double py = points[i][1];
            int best_k = 0;
            double best_dist = (px - centroids[0][0]) * (px - centroids[0][0])
                             + (py - centroids[0][1]) * (py - centroids[0][1]);
            for (k = 1; k < K; k++) {
                double dx = px - centroids[k][0];
                double dy = py - centroids[k][1];
                double dist = dx * dx + dy * dy;
                if (dist < best_dist) {
                    best_dist = dist;
                    best_k = k;
                }
            }
            if (labels[i] != best_k) {
                labels[i] = best_k;
                changed = 1;
            }
        }

        if (!changed) {
            break;
        }

        double sum[64][2];
        int count[64];
        for (k = 0; k < K; k++) {
            sum[k][0] = 0.0;
            sum[k][1] = 0.0;
            count[k] = 0;
        }

        #pragma omp parallel private(k)
        {
            double local_sum[64][2];
            int local_count[64];

            for (k = 0; k < K; k++) {
                local_sum[k][0] = 0.0;
                local_sum[k][1] = 0.0;
                local_count[k] = 0;
            }

            #pragma omp for
            for (i = 0; i < N; i++) {
                k = labels[i];
                local_sum[k][0] += points[i][0];
                local_sum[k][1] += points[i][1];
                local_count[k]++;
            }

            #pragma omp single
            {
                for (k = 0; k < K; k++) {
                    sum[k][0] += local_sum[k][0];
                    sum[k][1] += local_sum[k][1];
                    count[k] += local_count[k];
                }
            }
        }

        for (k = 0; k < K; k++) {
            if (count[k] > 0) {
                centroids[k][0] = sum[k][0] / count[k];
                centroids[k][1] = sum[k][1] / count[k];
            }
        }
    }
}