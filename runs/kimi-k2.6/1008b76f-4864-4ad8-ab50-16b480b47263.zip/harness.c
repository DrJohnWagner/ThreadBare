/* harness.c — differential driver for lloyds_k_means (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness -lm
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

/* forward declarations */
void lloyds_k_means_serial(const double (*points)[2],
                           const double (*initial_centroids)[2],
                           int N, int K,
                           int *labels,
                           double (*centroids)[2]);

void lloyds_k_means_omp(const double (*points)[2],
                        const double (*initial_centroids)[2],
                        int N, int K,
                        int *labels,
                        double (*centroids)[2]);

static uint32_t lcg_next(uint32_t *state)
{
    *state = (1103515245u * *state + 12345u) & 0x7fffffffu;
    return *state;
}

int main(int argc, char **argv)
{
    int N = 1000000;
    int K = 64;
    int reps = 20;

    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            N = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--reps") == 0 && i + 1 < argc) {
            reps = atoi(argv[++i]);
        }
    }

    double (*points)[2] = malloc(N * sizeof(double[2]));
    double (*initial_centroids)[2] = malloc(K * sizeof(double[2]));
    int *serial_labels = malloc(N * sizeof(int));
    double (*serial_centroids)[2] = malloc(K * sizeof(double[2]));
    int *parallel_labels = malloc(N * sizeof(int));
    double (*parallel_centroids)[2] = malloc(K * sizeof(double[2]));

    if (!points || !initial_centroids || !serial_labels ||
        !serial_centroids || !parallel_labels || !parallel_centroids) {
        fprintf(stderr, "out of memory\n");
        return 1;
    }

    uint32_t state = 12345u;
    for (int i = 0; i < N; ++i) {
        int c = i % 64;
        double base_x = (double)((c % 8) * 100 + 50);
        double base_y = (double)((c / 8) * 100 + 50);
        double dx = ((double)lcg_next(&state) / 2147483647.0) * 20.0 - 10.0;
        double dy = ((double)lcg_next(&state) / 2147483647.0) * 20.0 - 10.0;
        points[i][0] = base_x + dx;
        points[i][1] = base_y + dy;
    }

    for (int j = 0; j < K; ++j) {
        int idx = j * (N / K);
        initial_centroids[j][0] = points[idx][0];
        initial_centroids[j][1] = points[idx][1];
    }

    lloyds_k_means_serial(points, initial_centroids, N, K,
                          serial_labels, serial_centroids);

    int failures = 0;
    for (int r = 0; r < reps; ++r) {
        lloyds_k_means_omp(points, initial_centroids, N, K,
                           parallel_labels, parallel_centroids);

        int mismatch = 0;
        int bad_i = -1;
        int bad_j = -1;
        int bad_d = -1;

        for (int i = 0; i < N; ++i) {
            if (parallel_labels[i] != serial_labels[i]) {
                mismatch = 1;
                bad_i = i;
                break;
            }
        }

        if (!mismatch) {
            for (int j = 0; j < K; ++j) {
                for (int d = 0; d < 2; ++d) {
                    if (fabs(parallel_centroids[j][d] - serial_centroids[j][d]) > 1e-6) {
                        mismatch = 1;
                        bad_j = j;
                        bad_d = d;
                        break;
                    }
                }
                if (mismatch)
                    break;
            }
        }

        if (mismatch) {
            failures = 1;
            if (bad_i >= 0) {
                printf("[check] rep %d: labels[%d] = %d (expected %d)\n",
                       r, bad_i, parallel_labels[bad_i], serial_labels[bad_i]);
            } else {
                printf("[check] rep %d: centroids[%d][%d] = %.9g (expected %.9g, diff %.9g)\n",
                       r, bad_j, bad_d,
                       parallel_centroids[bad_j][bad_d],
                       serial_centroids[bad_j][bad_d],
                       fabs(parallel_centroids[bad_j][bad_d] - serial_centroids[bad_j][bad_d]));
            }
        }
    }

    printf("[verdict] %s\n", failures ? "SAFE-01 exposed" : "SAFE-01 not triggered");

    free(points);
    free(initial_centroids);
    free(serial_labels);
    free(serial_centroids);
    free(parallel_labels);
    free(parallel_centroids);

    return failures ? 1 : 0;
}
