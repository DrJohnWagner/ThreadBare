#include <stdlib.h>
#include <string.h>
#include <omp.h>

void lloyds_k_means_omp(const double *points, const double *initial_centroids, size_t n, double *out_centroids)
{
    double centroids[128];
    int *assignments;
    int *new_assignments;
    int *tmp;
    size_t i;
    int iter;

    memcpy(centroids, initial_centroids, 128 * sizeof(double));

    assignments = malloc(n * sizeof(int));
    new_assignments = malloc(n * sizeof(int));

    for (i = 0; i < n; i++) {
        assignments[i] = -1;
    }

    for (iter = 0; iter < 100; iter++) {
        int changed = 0;

        #pragma omp parallel for reduction(+:changed)
        for (i = 0; i < n; i++) {
            double px = points[2 * i];
            double py = points[2 * i + 1];
            int best_k = 0;
            double best_dist = (px - centroids[0]) * (px - centroids[0])
                             + (py - centroids[1]) * (py - centroids[1]);

            for (int k = 1; k < 64; k++) {
                double cx = centroids[2 * k];
                double cy = centroids[2 * k + 1];
                double dist = (px - cx) * (px - cx) + (py - cy) * (py - cy);
                if (dist < best_dist) {
                    best_dist = dist;
                    best_k = k;
                }
            }

            new_assignments[i] = best_k;
            if (best_k != assignments[i]) {
                changed++;
            }
        }

        if (changed == 0) {
            break;
        }

        {
            double sum_x[64] = {0};
            double sum_y[64] = {0};
            size_t count[64] = {0};

            #pragma omp parallel for reduction(+:sum_x[0:64], sum_y[0:64], count[0:64])
            for (i = 0; i < n; i++) {
                int cluster = new_assignments[i];
                sum_x[cluster] += points[2 * i];
                sum_y[cluster] += points[2 * i + 1];
                count[cluster]++;
            }

            for (i = 0; i < 64; i++) {
                if (count[i] > 0) {
                    centroids[2 * i] = sum_x[i] / (double)count[i];
                    centroids[2 * i + 1] = sum_y[i] / (double)count[i];
                }
            }
        }

        tmp = assignments;
        assignments = new_assignments;
        new_assignments = tmp;
    }

    memcpy(out_centroids, centroids, 128 * sizeof(double));

    free(assignments);
    free(new_assignments);
}