/* harness.c — differential driver for lloyds_k_means (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

void lloyds_k_means_serial(const double *points, const double *initial_centroids, size_t n, double *out_centroids);
void lloyds_k_means_omp(const double *points, const double *initial_centroids, size_t n, double *out_centroids);

int main(int argc, char **argv)
{
    size_t n = 1000000;
    int reps = 20;

    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            n = strtoull(argv[++i], NULL, 10);
        } else if (strcmp(argv[i], "--reps") == 0 && i + 1 < argc) {
            reps = atoi(argv[++i]);
        }
    }

    size_t num_coords = 2 * n;
    double *points = malloc(num_coords * sizeof(double));
    double *initial_centroids = malloc(128 * sizeof(double));
    double *serial_out = malloc(128 * sizeof(double));
    double *parallel_out = malloc(128 * sizeof(double));

    if (!points || !initial_centroids || !serial_out || !parallel_out) {
        fprintf(stderr, "Memory allocation failed\n");
        return 1;
    }

    uint64_t state = 42;
    for (size_t i = 0; i < num_coords; ++i) {
        state = (state * 1103515245ull + 12345ull) & 0x7fffffffull;
        points[i] = (double)state / (double)0x7fffffff * 1000.0;
    }
    for (size_t j = 0; j < 128; ++j) {
        initial_centroids[j] = points[j];
    }

    lloyds_k_means_serial(points, initial_centroids, n, serial_out);

    int failures = 0;
    for (int r = 0; r < reps; ++r) {
        lloyds_k_means_omp(points, initial_centroids, n, parallel_out);

        size_t bad_idx = 0;
        int mismatch = 0;
        for (size_t i = 0; i < 128; ++i) {
            double diff = parallel_out[i] - serial_out[i];
            if (diff > 1e-6 || diff < -1e-6) {
                bad_idx = i;
                mismatch = 1;
                break;
            }
        }

        if (mismatch) {
            printf("[check] mismatch at index %zu: ref=%.9g par=%.9g (rep %d)\n",
                   bad_idx, serial_out[bad_idx], parallel_out[bad_idx], r);
            failures = 1;
        }
    }

    printf("[verdict] %s\n", failures ? "SAFE-01 exposed" : "SAFE-01 not triggered");

    free(points);
    free(initial_centroids);
    free(serial_out);
    free(parallel_out);

    return failures ? 1 : 0;
}
