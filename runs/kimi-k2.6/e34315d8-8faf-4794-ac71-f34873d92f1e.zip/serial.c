#include <stdlib.h>
#include <string.h>

void lloyds_k_means_serial(const double *points, const double *initial_centroids, size_t n, double *out_centroids)
{
    double centroids[128];
    int *assignments;
    int *new_assignments;
    int *tmp;
    size_t i;
    int iter;
    int changed;
    int k;

    memcpy(centroids, initial_centroids, 128 * sizeof(double));

    assignments = malloc(n * sizeof(int));
    new_assignments = malloc(n * sizeof(int));

    for (i = 0; i < n; i++) {
        assignments[i] = -1;
    }

    for (iter = 0; iter < 100; iter++) {
        changed = 0;

        for (i = 0; i < n; i++) {
            double px = points[2 * i];
            double py = points[2 * i + 1];
            int best_k = 0;
            double best_dist = (px - centroids[0]) * (px - centroids[0])
                             + (py - centroids[1]) * (py - centroids[1]);

            for (k = 1; k < 64; k++) {
                double cx = centroids[2 * k];
                double cy = centroids[2 * k + 1];
                double dist = (px - cx) * (px - cx) + (py - cy) * (py - cy);
                if (dist < best_dist) {
                    best_dist = dist;
                    best_k = k;
                }
            }

            new_assignments[i] = best_k;
            if (best_k != assignments[i]) {
                changed = 1;
            }
        }

        if (!changed) {
            break;
        }

        {
            double sum_x[64] = {0};
            double sum_y[64] = {0};
            size_t count[64] = {0};

            for (i = 0; i < n; i++) {
                int cluster = new_assignments[i];
                sum_x[cluster] += points[2 * i];
                sum_y[cluster] += points[2 * i + 1];
                count[cluster]++;
            }

            for (k = 0; k < 64; k++) {
                if (count[k] > 0) {
                    centroids[2 * k] = sum_x[k] / (double)count[k];
                    centroids[2 * k + 1] = sum_y[k] / (double)count[k];
                }
            }
        }

        tmp = assignments;
        assignments = new_assignments;
        new_assignments = tmp;
    }

    memcpy(out_centroids, centroids, 128 * sizeof(double));

    free(assignments);
    free(new_assignments);
}
