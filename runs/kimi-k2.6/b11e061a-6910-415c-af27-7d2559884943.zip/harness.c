/* harness.c — differential driver for kmeans_2d (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness -lm
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

void kmeans_2d_serial(int N, int K, int *labels, double *centroids);
void kmeans_2d_omp(int N, int K, int *labels, double *centroids);

int main(int argc, char **argv)
{
    int N = 1000000;
    int reps = 20;
    const int K = 64;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            N = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--reps") == 0 && i + 1 < argc) {
            reps = atoi(argv[++i]);
        }
    }

    int *labels_ref = malloc((size_t)N * sizeof(int));
    int *labels_par = malloc((size_t)N * sizeof(int));
    double *centroids_ref = malloc((size_t)K * 2 * sizeof(double));
    double *centroids_par = malloc((size_t)K * 2 * sizeof(double));

    if (!labels_ref || !labels_par || !centroids_ref || !centroids_par) {
        fprintf(stderr, "harness: memory allocation failed\n");
        return 1;
    }

    kmeans_2d_serial(N, K, labels_ref, centroids_ref);

    int failures = 0;

    for (int r = 0; r < reps; r++) {
        kmeans_2d_omp(N, K, labels_par, centroids_par);

        int mismatch = 0;
        size_t mismatch_idx = 0;
        const char *mismatch_kind = "";

        for (int i = 0; i < N; i++) {
            if (labels_par[i] != labels_ref[i]) {
                mismatch = 1;
                mismatch_idx = (size_t)i;
                mismatch_kind = "label";
                break;
            }
        }

        if (!mismatch) {
            for (int j = 0; j < K * 2; j++) {
                if (fabs(centroids_par[j] - centroids_ref[j]) > 1e-6) {
                    mismatch = 1;
                    mismatch_idx = (size_t)j;
                    mismatch_kind = "centroid";
                    break;
                }
            }
        }

        if (mismatch) {
            failures = 1;
            if (strcmp(mismatch_kind, "label") == 0) {
                printf("[check] rep %d: first label mismatch at index %zu (parallel=%d, reference=%d)\n",
                       r, mismatch_idx, labels_par[mismatch_idx], labels_ref[mismatch_idx]);
            } else {
                printf("[check] rep %d: first centroid mismatch at index %zu (parallel=%.9f, reference=%.9f)\n",
                       r, mismatch_idx, centroids_par[mismatch_idx], centroids_ref[mismatch_idx]);
            }
        }
    }

    printf("[verdict] %s\n", failures ? "SAFE-01 exposed" : "SAFE-01 not triggered");

    free(labels_ref);
    free(labels_par);
    free(centroids_ref);
    free(centroids_par);

    return failures ? 1 : 0;
}
