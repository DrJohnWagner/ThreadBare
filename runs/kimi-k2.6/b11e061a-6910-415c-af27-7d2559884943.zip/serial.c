#include <stdlib.h>
#include <stdint.h>

void kmeans_2d_serial(int N, int K, int *labels, double *centroids)
{
    double *points = malloc(N * 2 * sizeof(double));
    uint64_t state = 42;
    for (int i = 0; i < N; i++) {
        state = (state * 1103515245ull + 12345ull) % (1ull << 31);
        uint32_t r0 = (uint32_t)state;
        state = (state * 1103515245ull + 12345ull) % (1ull << 31);
        uint32_t r1 = (uint32_t)state;
        points[2 * i] = (double)(r0 % 1000000u) / 1000.0;
        points[2 * i + 1] = (double)(r1 % 1000000u) / 1000.0;
    }

    for (int k = 0; k < K; k++) {
        centroids[2 * k] = points[2 * k];
        centroids[2 * k + 1] = points[2 * k + 1];
    }

    int *old_labels = malloc(N * sizeof(int));
    for (int i = 0; i < N; i++) {
        old_labels[i] = -1;
    }

    double *sum = malloc(K * 2 * sizeof(double));
    int *count = malloc(K * sizeof(int));
    int changed = 1;

    while (changed) {
        changed = 0;
        for (int i = 0; i < N; i++) {
            double px = points[2 * i];
            double py = points[2 * i + 1];
            int best = 0;
            double best_dist = (px - centroids[0]) * (px - centroids[0])
                             + (py - centroids[1]) * (py - centroids[1]);
            for (int k = 1; k < K; k++) {
                double dx = px - centroids[2 * k];
                double dy = py - centroids[2 * k + 1];
                double dist = dx * dx + dy * dy;
                if (dist < best_dist) {
                    best_dist = dist;
                    best = k;
                }
            }
            labels[i] = best;
            if (best != old_labels[i]) {
                changed = 1;
            }
        }

        if (!changed) {
            break;
        }

        for (int i = 0; i < N; i++) {
            old_labels[i] = labels[i];
        }

        for (int k = 0; k < K; k++) {
            sum[2 * k] = 0.0;
            sum[2 * k + 1] = 0.0;
            count[k] = 0;
        }

        for (int i = 0; i < N; i++) {
            int k = labels[i];
            sum[2 * k] += points[2 * i];
            sum[2 * k + 1] += points[2 * i + 1];
            count[k]++;
        }

        for (int k = 0; k < K; k++) {
            centroids[2 * k] = sum[2 * k] / count[k];
            centroids[2 * k + 1] = sum[2 * k + 1] / count[k];
        }
    }

    free(points);
    free(old_labels);
    free(sum);
    free(count);
}
