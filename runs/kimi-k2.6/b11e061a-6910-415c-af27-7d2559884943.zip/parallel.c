#include <stdlib.h>
#include <stdint.h>
#include <omp.h>

void kmeans_2d_omp(int N, int K, int *labels, double *centroids)
{
    double *points = malloc(N * 2 * sizeof(double));
    uint64_t state = 42;
    for (int i = 0; i < N; i++) {
        state = (state * 1103515245ull + 12345ull) % (1ull << 31);
        uint32_t r0 = (uint32_t)state;
        state = (state * 1103515245ull + 12345ull) % (1ull << 31);
        uint32_t r1 = (uint32_t)state;
        points[2 * i] = (double)(r0 % 1000000u) / 1000.0;
        points[2 * i + 1] = (double)(r1 % 1000000u) / 1000.0;
    }

    for (int k = 0; k < K; k++) {
        centroids[2 * k] = points[2 * k];
        centroids[2 * k + 1] = points[2 * k + 1];
    }

    int *old_labels = malloc(N * sizeof(int));
    #pragma omp parallel for
    for (int i = 0; i < N; i++) {
        old_labels[i] = -1;
    }

    double *sum = malloc(K * 2 * sizeof(double));
    int *count = malloc(K * sizeof(int));
    int changed = 1;

    int max_threads = omp_get_max_threads();
    double *thread_sums = calloc((size_t)max_threads * K * 2, sizeof(double));
    int *thread_counts = calloc((size_t)max_threads * K, sizeof(int));

    while (changed) {
        changed = 0;

        #pragma omp parallel for reduction(&:changed)
        for (int i = 0; i < N; i++) {
            double px = points[2 * i];
            double py = points[2 * i + 1];
            int best = 0;
            double best_dist = (px - centroids[0]) * (px - centroids[0])
                             + (py - centroids[1]) * (py - centroids[1]);
            for (int k = 1; k < K; k++) {
                double dx = px - centroids[2 * k];
                double dy = py - centroids[2 * k + 1];
                double dist = dx * dx + dy * dy;
                if (dist < best_dist) {
                    best_dist = dist;
                    best = k;
                }
            }
            labels[i] = best;
            if (best != old_labels[i]) {
                changed = 1;
            }
        }

        if (!changed) {
            break;
        }

        #pragma omp parallel for
        for (int i = 0; i < N; i++) {
            old_labels[i] = labels[i];
        }

        for (int k = 0; k < K; k++) {
            sum[2 * k] = 0.0;
            sum[2 * k + 1] = 0.0;
            count[k] = 0;
        }

        #pragma omp parallel
        {
            int tid = omp_get_thread_num();
            double *local_sum = &thread_sums[(size_t)tid * K * 2];
            int *local_count = &thread_counts[(size_t)tid * K];

            for (int k = 0; k < K; k++) {
                local_sum[2 * k] = 0.0;
                local_sum[2 * k + 1] = 0.0;
                local_count[k] = 0;
            }

            #pragma omp for
            for (int i = 0; i < N; i++) {
                int k = labels[i];
                local_sum[2 * k] += points[2 * i];
                local_sum[2 * k + 1] += points[2 * i + 1];
                local_count[k]++;
            }
        }

        for (int t = 0; t < max_threads; t++) {
            for (int k = 0; k < K; k++) {
                sum[2 * k] += thread_sums[(size_t)t * K * 2 + 2 * k];
                sum[2 * k + 1] += thread_sums[(size_t)t * K * 2 + 2 * k + 1];
                count[k] += thread_counts[(size_t)t * K + k];
            }
        }

        for (int k = 0; k < K; k++) {
            centroids[2 * k] = sum[2 * k] / count[k];
            centroids[2 * k + 1] = sum[2 * k + 1] / count[k];
        }
    }

    free(points);
    free(old_labels);
    free(sum);
    free(count);
    free(thread_sums);
    free(thread_counts);
}
