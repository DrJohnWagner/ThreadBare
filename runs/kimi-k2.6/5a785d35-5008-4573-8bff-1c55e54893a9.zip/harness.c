/* harness.c — differential driver for k_means (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#define K 64
#define DIM 2

void k_means_serial(const double *points, const double *initial_centroids, int N, unsigned int *assignments, double *final_centroids);
void k_means_omp(const double *points, const double *initial_centroids, int N, unsigned int *assignments, double *final_centroids);

int main(int argc, char **argv)
{
    int n = 1000000;
    int reps = 20;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            n = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--reps") == 0 && i + 1 < argc) {
            reps = atoi(argv[++i]);
        }
    }

    if (n <= 0) n = 1000000;
    if (reps <= 0) reps = 20;

    double *points = malloc((size_t)n * DIM * sizeof(double));
    if (!points) {
        perror("malloc");
        return 1;
    }

    uint64_t state = 42;
    for (int i = 0; i < n; i++) {
        state = (state * 1103515245ull + 12345) & 0x7fffffffull;
        double x = (double)(state % 10000) / 10.0;
        state = (state * 1103515245ull + 12345) & 0x7fffffffull;
        double y = (double)(state % 10000) / 10.0;
        points[i * DIM + 0] = x;
        points[i * DIM + 1] = y;
    }

    double *initial_centroids = malloc((size_t)K * DIM * sizeof(double));
    if (!initial_centroids) {
        perror("malloc");
        return 1;
    }
    memcpy(initial_centroids, points, (size_t)K * DIM * sizeof(double));

    unsigned int *ref_assign = malloc((size_t)n * sizeof(unsigned int));
    double *ref_centroids = malloc((size_t)K * DIM * sizeof(double));
    unsigned int *par_assign = malloc((size_t)n * sizeof(unsigned int));
    double *par_centroids = malloc((size_t)K * DIM * sizeof(double));

    if (!ref_assign || !ref_centroids || !par_assign || !par_centroids) {
        perror("malloc");
        return 1;
    }

    k_means_serial(points, initial_centroids, n, ref_assign, ref_centroids);

    int failures = 0;

    for (int r = 0; r < reps; r++) {
        k_means_omp(points, initial_centroids, n, par_assign, par_centroids);

        int diff = 0;
        for (int i = 0; i < n; i++) {
            if (par_assign[i] != ref_assign[i]) {
                printf("[check] rep %d: assignments differ at index %d (expected %u, got %u)\n",
                       r, i, ref_assign[i], par_assign[i]);
                diff = 1;
                break;
            }
        }

        if (!diff) {
            for (int i = 0; i < K * DIM; i++) {
                if (par_centroids[i] != ref_centroids[i]) {
                    printf("[check] rep %d: final_centroids differ at index %d (expected %.17g, got %.17g)\n",
                           r, i, ref_centroids[i], par_centroids[i]);
                    diff = 1;
                    break;
                }
            }
        }

        if (diff) {
            failures = 1;
        }
    }

    printf("[verdict] %s\n", failures ? "SAFE-01 exposed" : "SAFE-01 not triggered");

    free(points);
    free(initial_centroids);
    free(ref_assign);
    free(ref_centroids);
    free(par_assign);
    free(par_centroids);

    return failures ? 1 : 0;
}
