#include <stdlib.h>
#include <string.h>

void k_means_serial(const double *points, const double *initial_centroids,
                    int N, unsigned int *assignments, double *final_centroids)
{
    unsigned int *old_assignments = malloc(N * sizeof(unsigned int));
    int changed;
    int i, k;

    if (!old_assignments)
        return;

    memcpy(final_centroids, initial_centroids, 64 * 2 * sizeof(double));
    for (i = 0; i < N; i++)
        old_assignments[i] = 64;

    do {
        changed = 0;
        for (i = 0; i < N; i++) {
            double px = points[2 * i];
            double py = points[2 * i + 1];
            double dx = px - final_centroids[0];
            double dy = py - final_centroids[1];
            double min_dist = dx * dx + dy * dy;
            int best = 0;

            for (k = 1; k < 64; k++) {
                dx = px - final_centroids[2 * k];
                dy = py - final_centroids[2 * k + 1];
                double dist = dx * dx + dy * dy;
                if (dist < min_dist) {
                    min_dist = dist;
                    best = k;
                }
            }

            assignments[i] = (unsigned int)best;
            if (best != (int)old_assignments[i])
                changed = 1;
        }

        if (!changed)
            break;

        double sums[128];
        int counts[64];

        memset(sums, 0, sizeof(sums));
        memset(counts, 0, sizeof(counts));

        for (i = 0; i < N; i++) {
            k = (int)assignments[i];
            sums[2 * k] += points[2 * i];
            sums[2 * k + 1] += points[2 * i + 1];
            counts[k]++;
        }

        for (k = 0; k < 64; k++) {
            if (counts[k] > 0) {
                final_centroids[2 * k] = sums[2 * k] / counts[k];
                final_centroids[2 * k + 1] = sums[2 * k + 1] / counts[k];
            }
        }

        memcpy(old_assignments, assignments, N * sizeof(unsigned int));
    } while (changed);

    free(old_assignments);
}
