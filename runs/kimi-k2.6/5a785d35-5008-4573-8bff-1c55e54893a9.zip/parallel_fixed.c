#include <stdlib.h>
#include <string.h>
#include <omp.h>

void k_means_omp(const double *points, const double *initial_centroids,
                 int N, unsigned int *assignments, double *final_centroids)
{
    unsigned int *old_assignments = malloc(N * sizeof(unsigned int));
    int max_threads = omp_get_max_threads();
    double *thread_sums = calloc(max_threads * 128, sizeof(double));
    int *thread_counts = calloc(max_threads * 64, sizeof(int));
    int changed;

    if (!old_assignments || !thread_sums || !thread_counts) {
        free(old_assignments);
        free(thread_sums);
        free(thread_counts);
        return;
    }

    memcpy(final_centroids, initial_centroids, 64 * 2 * sizeof(double));
    for (int i = 0; i < N; i++)
        old_assignments[i] = 64;

    do {
        changed = 0;
        #pragma omp parallel for reduction(|:changed)
        for (int i = 0; i < N; i++) {
            double px = points[2 * i];
            double py = points[2 * i + 1];
            double dx = px - final_centroids[0];
            double dy = py - final_centroids[1];
            double min_dist = dx * dx + dy * dy;
            int best = 0;

            for (int k = 1; k < 64; k++) {
                dx = px - final_centroids[2 * k];
                dy = py - final_centroids[2 * k + 1];
                double dist = dx * dx + dy * dy;
                if (dist < min_dist) {
                    min_dist = dist;
                    best = k;
                }
            }

            assignments[i] = (unsigned int)best;
            if (best != (int)old_assignments[i])
                changed = 1;
        }

        if (!changed)
            break;

        double sums[128];
        int counts[64];

        memset(sums, 0, sizeof(sums));
        memset(counts, 0, sizeof(counts));
        memset(thread_sums, 0, max_threads * 128 * sizeof(double));
        memset(thread_counts, 0, max_threads * 64 * sizeof(int));

        #pragma omp parallel
        {
            int tid = omp_get_thread_num();
            double *local_sums = &thread_sums[tid * 128];
            int *local_counts = &thread_counts[tid * 64];

            #pragma omp for schedule(static)
            for (int i = 0; i < N; i++) {
                int k = (int)assignments[i];
                local_sums[2 * k] += points[2 * i];
                local_sums[2 * k + 1] += points[2 * i + 1];
                local_counts[k]++;
            }
        }

        for (int t = 0; t < max_threads; t++) {
            for (int k = 0; k < 64; k++) {
                sums[2 * k] += thread_sums[t * 128 + 2 * k];
                sums[2 * k + 1] += thread_sums[t * 128 + 2 * k + 1];
                counts[k] += thread_counts[t * 64 + k];
            }
        }

        for (int k = 0; k < 64; k++) {
            if (counts[k] > 0) {
                final_centroids[2 * k] = sums[2 * k] / counts[k];
                final_centroids[2 * k + 1] = sums[2 * k + 1] / counts[k];
            }
        }

        memcpy(old_assignments, assignments, N * sizeof(unsigned int));
    } while (changed);

    free(thread_counts);
    free(thread_sums);
    free(old_assignments);
}
