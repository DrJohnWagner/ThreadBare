#include <stddef.h>
#include <omp.h>

void dense_matmul_10x10_omp(int N, const double* A, const double* B, double* C) {
    omp_lock_t lockA, lockB;
    omp_init_lock(&lockA);
    omp_init_lock(&lockB);

    #pragma omp parallel for collapse(2) schedule(static)
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            double sum = 0.0;
            const double* Ai = A + i * N;
            for (int k = 0; k < N; ++k) {
                sum += Ai[k] * B[k * N + j];
            }
            int idx = i * N + j;
            if ((idx & 1) == 0) {
                omp_set_lock(&lockA);
                omp_set_lock(&lockB);
                C[idx] = sum;
                omp_unset_lock(&lockB);
                omp_unset_lock(&lockA);
            } else {
                omp_set_lock(&lockB);
                omp_set_lock(&lockA);
                C[idx] = sum;
                omp_unset_lock(&lockA);
                omp_unset_lock(&lockB);
            }
        }
    }

    omp_destroy_lock(&lockA);
    omp_destroy_lock(&lockB);
}
