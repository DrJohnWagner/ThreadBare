/* harness.c — timeout driver for dense_matmul_10x10 (generated)
 *
 *   build: gcc-14 -O2 -fopenmp harness.c serial.c parallel.c -o harness [-lm]
 *   run:   OMP_NUM_THREADS=<n> ./harness [--flags]
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <signal.h>
#include <unistd.h>

// Forward declarations of the user-provided functions
void dense_matmul_10x10_serial(int N, const double* A, const double* B, double* C);
void dense_matmul_10x10_omp(int N, const double* A, const double* B, double* C);

static volatile sig_atomic_t timed_out = 0;

void handle_alarm(int sig) {
    (void)sig;
    timed_out = 1;
}

static void generate_input(int N, double* A, double* B) {
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            A[i * N + j] = (i + 1) * 0.01 + (j + 1) * 0.03;
            B[i * N + j] = (i + 1) * 0.02 + (j + 1) * 0.07;
        }
    }
}

static int matrices_equal(int N, const double* X, const double* Y) {
    const double tol = 1e-9;
    for (int i = 0; i < N * N; ++i) {
        double a = X[i];
        double b = Y[i];
        double diff = fabs(a - b);
        double limit = tol * fmax(1.0, fabs(b)); // as specified: |X - Y| <= 1e-9 * max(1, |Y|)
        if (diff > limit) return 0;
    }
    return 1;
}

int main(int argc, char** argv) {
    int N = 10; // base case
    int reps = 16; // not used for timeout strategy but kept for extensibility

    // Parse simple --n and --reps flags if provided
    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            N = atoi(argv[i + 1]);
            i++;
        } else if (strcmp(argv[i], "--reps") == 0 && i + 1 < argc) {
            reps = atoi(argv[i + 1]);
            i++;
        } else if (strcmp(argv[i], "--help") == 0) {
            fprintf(stdout, "Usage: harness [--n <N>] [--reps <R>]\\n");
        }
    }

    // Allocate inputs
    int size = N * N;
    double* A = (double*)malloc(sizeof(double) * size);
    double* B = (double*)malloc(sizeof(double) * size);
    double* C_ref = (double*)malloc(sizeof(double) * size);
    double* C_par = (double*)malloc(sizeof(double) * size);
    if (!A || !B || !C_ref || !C_par) {
        fprintf(stderr, "Memory allocation failed\\n");
        return 1;
    }

    generate_input(N, A, B);

    // Compute ground truth with serial implementation
    dense_matmul_10x10_serial(N, A, B, C_ref);

    int failure = 0;

    // Run the parallel implementation with a timeout to detect liveness failures
    // Set up alarm handler
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = handle_alarm;
    sigaction(SIGALRM, &sa, NULL);

    // Configure timeout in seconds
    const unsigned int timeout_sec = 5; // 5-second wall clock timeout for this run

    timed_out = 0;
    alarm(0); // cancel any previous alarms
    alarm(timeout_sec);

    // Execute parallel function
    dense_matmul_10x10_omp(N, A, B, C_par);

    // Disable alarm after completion
    alarm(0);

    if (timed_out) {
        // Deadlock or hang detected
        failure = 1;
    } else {
        // Check correctness against reference
        if (!matrices_equal(N, C_ref, C_par)) {
            failure = 1;
        }
    }

    // Print verdict line as required
    if (failure) {
        printf("[verdict] LIVE-NN exposed\n");
    } else {
        printf("[verdict] <pass message>\n");
    }

    // Cleanup
    free(A);
    free(B);
    free(C_ref);
    free(C_par);

    return failure ? 1 : 0;
}
