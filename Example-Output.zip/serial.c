#include <stddef.h>

// Serial reference implementation for dense_matmul_10x10
// Computes C = A * B for N x N matrices stored in row-major order.
void dense_matmul_10x10_serial(int N, const double* A, const double* B, double* C) {
    for (int i = 0; i < N; ++i) {
        const double* Ai = A + i * N;
        for (int j = 0; j < N; ++j) {
            double sum = 0.0;
            for (int k = 0; k < N; ++k) {
                sum += Ai[k] * B[k * N + j];
            }
            C[i * N + j] = sum;
        }
    }
}
