#include <stddef.h>
#include <omp.h>

void dense_matmul_10x10_omp(int N, const double* A, const double* B, double* C) {
    #pragma omp parallel for collapse(2) schedule(static)
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            double sum = 0.0;
            const double* Ai = A + i * N;
            for (int k = 0; k < N; ++k) {
                sum += Ai[k] * B[k * N + j];
            }
            C[i * N + j] = sum;
        }
    }
}
